import matplotlib
import mne.filter

matplotlib.use("TkAgg")
from matplotlib import pyplot as plt
from matplotlib import gridspec
from matplotlib.widgets import Button, RadioButtons, TextBox
from matplotlib.animation import FuncAnimation
from matplotlib.collections import LineCollection
from EEGTools.Plotter.LivePlot import LivePlot
import numpy
from scipy import signal
from multiprocessing import Queue, Process
import threading
from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)


class _RemoteSwitchPlot: # TODO atexit kill für keyboard interrupts
    """
    Main GUI window class. Defines the window and initializes the graphs
    for the data from each electrode coming from the EEG headset.
    """

    def __init__(self, data_queue, info_queue, event_queue, sfreq, channel_names, channel_types, shortcuts=None):
        self.sfreq = sfreq # The sampling frequency.
        self.channel_names = channel_names
        self.channel_types = channel_types
        self.shortcuts = shortcuts
        self.data_queue = data_queue
        self.info_queue = info_queue
        self.event_queue = event_queue
        
        self.window_length = 1000  # The number of samples to consider in a plot.
        self.data = numpy.empty((len(channel_types), 0)) # The field holding data

        """GUI"""

        self.channel_padding = 200  # The padding to push the the channels sightly upward
        self.between_channel_padding = 100  # The space between channels in a plot.

        self.fig = plt.figure()

        #def onresize(event): #TODO resize correctly to handle better figure scaling
        #    pass
        #cid = self.fig.canvas.mpl_connect('resize', onresize)

        self.plot_type = None  # The type of plot currently in use. Can be PSD TIME or SUMMARY

        # start the plot.
        self.plot_time(self.fig)

        self.vertical_scale = 1  # The factor by which displayed data is scaled.

        def gui_update(frame):
            """
                This is the main GUI loop.
            """

            # If there is data in the queue
            if not self.data_queue.empty():
                # Retrieve ALL data form the queue. Necessary as really small packages can clog the pipe.
                queue_data = [self.data_queue.get() for _ in range(self.data_queue.qsize())]

                # Write incoming data to the data field.
                for data in queue_data:
                    self.data = numpy.append(self.data, data, axis=1)

                # Handle edge case that there is not enough data to display.
                if self.data.shape[1] >= self.window_length:
                    # Select the correct updating procedure
                    if self.plot_type == "TIME":
                        gui_update_time()
                    elif self.plot_type == "PSD":
                        gui_update_psd()
                    elif self.plot_type == "SUMMARY":
                        gui_update_summary()
            self.data = self.data[:, -self.window_length:]

        def gui_update_time():
            """
            Updates the Time plot
            :return:
            """
            # Crop data to correct size.
            data_to_display = self.data[:, -self.window_length:]

            # Filter for unwanted types
            if self.time_radio_selected == "name":
                try:
                    indices = [self.channel_names.index(x) for x in self.channel_names if self.time_text_box.text in x]
                except ValueError:
                    indices = [x for x in range(len(self.channel_names))]
            else:
                indices = [x for x in range(len(self.channel_types)) if
                           self.channel_types[x] == self.time_radio_selected or self.time_radio_selected == 'all']
            data_to_display = data_to_display[indices, :]
            # Needs to be reversed as matplotlib cpunts ticks from down to up
            indices.reverse()
            self.ax.set_yticklabels([self.channel_names[index] for index in indices])

            # Reset the lines in the plot
            self.ax.lines = []

            # Frequency Filtering
            if self.time_radio_filter_selected == "2-40":
                data_to_display = mne.filter.filter_data(data_to_display, h_freq=40, l_freq=2, sfreq=self.sfreq,
                                                         verbose=False)

            if self.time_radio_filter_selected == "2-NYQUIST":
                data_to_display = mne.filter.filter_data(data_to_display, l_freq=2, h_freq=int(self.sfreq/2-1), sfreq=self.sfreq,
                                                         verbose=False)

            # For each row
            for i in range(data_to_display.shape[0]):
                # Since we draw bottom up, the lowest rows needs to be drawn first
                row = data_to_display[data_to_display.shape[0] - 1 - i, :]

                row = (row - row.mean())  # Center the plot
                row = row * self.vertical_scale  # Apply vertical scaling
                row = row + self.between_channel_padding * i + self.channel_padding / 2  # Apply padding TODO this padding method is bad.
                self.ax.plot(row, 'b', linewidth=1)  # Display lines in blue in the smallest size

        def gui_update_psd():
            """
            Updates the PSD Plot
            :return:
            """

            self.ax.set_yticklabels(self.channel_names)

            # Reset the lines in the plot
            self.ax.lines = []

            try:
                self.ax.set_xlim((-10, self.window_length/2-int(self.psd_text_box_left.text)-int(self.psd_text_box_right.text)-1+10))
            except ValueError:
                self.ax.set_xlim((-10, self.window_length / 2 + 10))

            if self.psd_radio_selected == "name":
                try:
                    indices = [self.channel_names.index(x) for x in self.channel_names if self.psd_text_box.text in x]
                except ValueError:
                    indices = [x for x in range(len(self.channel_names))]
            else:
                indices = [x for x in range(len(self.channel_types)) if
                           self.channel_types[x] == self.psd_radio_selected or self.psd_radio_selected == 'all']

            # Crop data to correct size. and compute the PSD
            data_to_display = self.data[indices, -self.window_length:]

            indices.reverse()
            self.ax.set_yticklabels([self.channel_names[index] for index in indices])

            if self.psd_radio_filter_selected == "2-40":
                data_to_display = mne.filter.filter_data(data_to_display, h_freq=40, l_freq=2, sfreq=self.sfreq,
                                                         verbose=False)
            elif self.psd_radio_filter_selected == "50":
                data_to_display = mne.filter.notch_filter(data_to_display, freqs=50, Fs=self.sfreq, verbose=False)
            elif self.psd_radio_filter_selected == "2-40/50":
                data_to_display = mne.filter.notch_filter(data_to_display, freqs=50, Fs=self.sfreq, verbose=False)
                data_to_display = mne.filter.filter_data(data_to_display, h_freq=40, l_freq=2, sfreq=self.sfreq,
                                                         verbose=False)
            psd_data = signal.periodogram(data_to_display, self.sfreq)
            try :
                labels = [psd_data[0][index] for index in range(len(psd_data[0][int(self.psd_text_box_left.text): -int(self.psd_text_box_right.text)-1]))]
            except ValueError:
                labels = [psd_data[0][index] for index in range(len(psd_data[0]))]
            mod = 20
            filtered_labels = [labels[i] for i in range(len(labels)) if i % mod == 0]
            positions = [i for i in range(len(labels)) if i % mod == 0]
            self.ax.set_xticks(positions)
            self.ax.set_xticklabels(filtered_labels)


            data_to_display = psd_data[1]

            for i in range(data_to_display.shape[0]):
                try:
                    row = data_to_display[i, int(self.psd_text_box_left.text): -int(self.psd_text_box_right.text)-1]
                except ValueError:
                    row = data_to_display[i, :]

                row = row * self.vertical_scale  # Apply vertical scaling
                row = row + 100 * i + self.channel_padding / 2  # Apply padding TODO this padding method is bad.

                self.ax.plot(row, 'b')

        def gui_update_summary():
            self.summary_summary.set_text(f"The data contains {self.data.shape[0]} "
                                          f"channels with {self.data.shape[1]} samples")
            self.summary_names.set_text(f"The Channels are {self.channel_names}")
            self.summary_types.set_text(f"The Channels types are {self.channel_types}")

        self.animation = FuncAnimation(self.fig, gui_update, 1)

    def plot_time(self, fig):
        """
        Sewitches the plot to view data in time mode, where x is time and y is channels/amplitude.
        :param fig:
        :return:
        """
        # Clear the Plot
        plt.clf()

        # Set the new plot specs.
        self.plot_type = "TIME"
        spec = gridspec.GridSpec(4, 2, width_ratios=[0.95, 0.05], height_ratios=[0.1, 0.3, 0.3, 0.3])

        # Handles the Plot.
        self.ax = fig.add_subplot(spec[:,0])
        rev_chn_names = list(self.channel_names)
        rev_chn_names.reverse()
        plt.yticks([x*100+self.channel_padding/2 for x in range(len(self.channel_names))], rev_chn_names)
        plt.ylabel("EEG Channels")
        plt.xlabel(f"Samples in {self.sfreq} samples per s")
        plt.ylim((0,len(self.channel_names)*100 + self.channel_padding))

        # Radio button to filter by type
        self.time_radio_ax = fig.add_subplot(spec[1,1])
        radio_set = list(set(self.channel_types).union(['all', 'name']))
        self.time_radio = RadioButtons(self.time_radio_ax, radio_set, active= radio_set.index('all'))
        self.time_radio_selected = 'all'

        def time_time_radio_callback(label):
            self.time_radio_selected = label
            self.ax.set_ylabel(f"{label} Channels")

        self.time_radio.on_clicked(time_time_radio_callback)

        # Handle tht button
        ax_button_back = fig.add_subplot(spec[0,1])

        spec.tight_layout(self.fig)

        def callback_time(that):
            """
            Button press calback that switches back to the summary view.
            :param that: TODO apparently  mpl needs this, but I don't really know what it does.
            :return:
            """
            self.plot_summary(fig)

        self.button_back = Button(ax_button_back, "Back")
        self.button_back.on_clicked(callback_time)

        def on_press(event):
            """
            The keypress event to handle the vertical scaling.
            :param event:
            :return:
            """
            if event.key == '+':
                self.vertical_scale *= 2
            elif event.key == '-':
                self.vertical_scale /= 2

        fig.canvas.mpl_connect('key_press_event', on_press)

        # UI for the bandpass filtering.
        self.time_radio_filter_ax = fig.add_subplot(spec[2,1])
        self.time_radio_filter = RadioButtons(self.time_radio_filter_ax, ["None", "2-40", "2-NYQUIST"])
        self.time_radio_filter_selected = 'Test'

        def time_time_radio_filter_callback(label):
            """
            The callback function for the radio buttons for bandpass filtering.
            :param label:
            :return:
            """
            self.time_radio_filter_selected = label

        self.time_radio_filter.on_clicked(time_time_radio_filter_callback)

        self.time_text_box_ax = fig.add_subplot(spec[3,1])
        self.time_text_box = TextBox(self.time_text_box_ax, 'Channel name', initial="")

        self.ax.grid(True)

    def plot_psd(self, fig):
        plt.clf()
        self.plot_type = "PSD"
        spec = gridspec.GridSpec(6, 2, width_ratios=[0.9, 0.1])
        self.ax = fig.add_subplot(spec[:,0])
        rev_chn_names = list(self.channel_names)
        rev_chn_names.reverse()
        plt.yticks([x * 100 + self.channel_padding / 2 for x in range(len(self.channel_names))], rev_chn_names)
        plt.ylabel("PSD of Channels")
        plt.ylim((0, len(self.channel_names) * 100 + self.channel_padding))

        self.hlines = self.ax.hlines(
            [self.between_channel_padding * x + self.channel_padding / 2 for x in range(len(self.channel_names))],
            [0] * len(self.channel_names), [self.window_length / 2] * len(self.channel_names),
            linewidth=0.5, linestyles=['dotted'] * len(self.channel_names))

        ax_button_back = fig.add_subplot(spec[0,1])
        def callback_time(that):
            self.plot_summary(fig)
        self.button_back = Button(ax_button_back, "Back")
        self.button_back.on_clicked(callback_time)

        self.psd_radio_ax = fig.add_subplot(spec[4,1])
        radio_set = list(set(self.channel_types).union(['all', 'name']))
        self.psd_radio = RadioButtons(self.psd_radio_ax, radio_set, active=radio_set.index('all'))
        self.psd_radio_selected = 'all'

        def psd_time_radio_callback(label):
            self.psd_radio_selected = label
            self.ax.set_ylabel(f"{label} Channels")

        self.psd_radio.on_clicked(psd_time_radio_callback)

        self.psd_text_box_ax_left = fig.add_subplot(spec[1,1])
        self.psd_text_box_left = TextBox(self.psd_text_box_ax_left, 'Left', initial="0")

        self.psd_text_box_ax_right = fig.add_subplot(spec[2,1])
        self.psd_text_box_right = TextBox(self.psd_text_box_ax_right, 'Right', initial="0")

        self.psd_radio_filter_ax = fig.add_subplot(spec[3,1])
        self.psd_radio_filter = RadioButtons(self.psd_radio_filter_ax, ["None", "2-40", "50", "2-40/50"])
        self.psd_radio_filter_selected = 'None'

        self.psd_text_box_ax = fig.add_subplot(spec[5,1])
        self.psd_text_box = TextBox(self.psd_text_box_ax, 'Channel name', initial="")

        def psd_time_radio_filter_callback(label):
            """
            The callback function for the radio buttons for bandpass filtering.
            :param label:
            :return:
            """
            self.psd_radio_filter_selected = label

        self.psd_radio_filter.on_clicked(psd_time_radio_filter_callback)

        self.ax.grid(True)
        spec.tight_layout(self.fig)

    def plot_summary(self, fig):
        plt.clf()
        self.plot_type = "SUMMARY"
        # Setup Figure Structure
        spec = gridspec.GridSpec(2,2, height_ratios=[0.9,0.1])

        self.ax = fig.add_subplot(spec[0,:])
        self.ax.get_xaxis().set_visible(False)
        self.ax.get_yaxis().set_visible(False)

        ax_button_time = fig.add_subplot(spec[1,0])

        ax_button_freq = fig.add_subplot(spec[1,1])

        def callback_time(that):
            self.plot_time(fig)
        def callback_freq(that):
            self.plot_psd(fig)

        self.button_time = Button(ax_button_time, "Time Plot")
        self.button_time.on_clicked(callback_time)

        self.button_freq = Button(ax_button_freq, "Freq Plot")
        self.button_freq.on_clicked(callback_freq)

        self.summary_summary = self.ax.text(0, 0.9, "")
        self.summary_names = self.ax.text(0, 0.8, "")
        self.summary_types = self.ax.text(0, 0.7, "")

        spec.tight_layout(self.fig)

    def start(self):
        plt.show()


class SwitchPlot(LivePlot):
    """
    Main GUI window class. Defines the window and initializes the graphs
    for the data from each electrode coming from the EEG headset.
    """

    def __init__(self, sfreq, channel_names, channel_types, shortcuts=None, callback=None):
        self.sfreq = sfreq  # The sampling frequency
        self.channel_names = channel_names  # The channel names as given by the recorder class.
        self.channel_types = channel_types   # The channel types as given by the recorder class.
        self.shortcuts = {} if shortcuts is None else shortcuts  # A dict of commands that should evoke a callback
                                                                 # when executed in aplot
        if callback is None:
            def f(event):
                print(event)
            callback = f
        self.callback = callback  # The callback for when the plot sends messages to the main program..


        self.data_queue = Queue()  # The data queue to send data to the remote plot
        self.info_queue = Queue()  # TODO
        self.event_queue = Queue()  # TODO
        self.event_threads = threading.Thread(target=self._wait_for_events, name="Plotting Event Thread")
        self.plot = None
        self.event_thread_is_active = False

    @staticmethod
    def _start_plot(sfreq, channel_names, channel_types, shortcuts, data_queue, info_queue, event_queue):
        plot = _RemoteSwitchPlot(data_queue, info_queue, event_queue, sfreq, channel_names, channel_types, shortcuts)
        plot.start()

    def _wait_for_events(self):
        """
        Reteives Events from the event gueue to send to a callback.
        :return:
        """
        self.event_thread_is_active = True

        while self.event_thread_is_active:  # TODO this is slow
            if not self.event_queue.empty():
                event = self.event_queue.get()
                self.callback(event)

    def start(self):
        """
        Starts running the plot. Happens in a different process and is non blocking.
        :return:
        """
        self.plot = Process(target=self._start_plot, args=(self.sfreq, self.channel_names, self.channel_types, self.shortcuts, self.data_queue,
                                                           self.info_queue, self.event_queue))
        self.plot.start()
        self.event_threads.start()

    def stop(self):
        """
        Stops running the plot.
        :return:
        """
        self.data_queue.close()
        self.data_queue.join_thread()

        self.event_thread_is_active = False
        self.plot.kill()  # TODO this is terrible also, does it work while plot is offline?

    def update(self, data):
        """
        Updates the status of the plot
        :param data:
        :return:
        """
        self.data_queue.put(data)  # Just puts the data in the data queue for the remote to fetch.

    def sendInfo(self, info):
        """
        Sends info to the remote. TODO Wow great description myself.
        :param info:
        :return:
        """
        self.info_queue.put(info)
