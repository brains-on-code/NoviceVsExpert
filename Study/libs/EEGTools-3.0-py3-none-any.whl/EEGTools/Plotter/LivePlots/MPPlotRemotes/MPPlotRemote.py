from abc import abstractmethod


class MPPlotRemote:

    @abstractmethod
    def start(self):
        """
        Start the plot
        :return:
        """

