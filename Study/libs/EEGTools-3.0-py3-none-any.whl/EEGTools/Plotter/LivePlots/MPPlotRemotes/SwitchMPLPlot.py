import matplotlib
matplotlib.use("TkAgg")
from matplotlib import pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy
from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchWindows.SummaryWindow import SummaryWindow
from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchWindows.TimeWindow import TimeWindow
from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchWindows.PSDWindow import PSDWindow
from EEGTools.Plotter.LivePlots.MPPlotRemotes.MPPlotRemote import MPPlotRemote


class SwitchMPLPlot(MPPlotRemote):  # TODO atexit kill für keyboard interrupts
    """
    Main GUI window class. Defines the window and initializes the graphs
    for the data from each electrode coming from the EEG headset.
    """

    def __init__(self, data_queue, info_queue, plot_event_queue, rec_event_queue, sfreq, channel_names, channel_types, shortcuts=None):
        self.sfreq = sfreq  # The sampling frequency.
        self.channel_names = channel_names
        self.channel_types = channel_types
        self.shortcuts = shortcuts
        self.data_queue = data_queue
        self.info_queue = info_queue
        self.plot_event_queue = plot_event_queue
        self.rec_event_queue = rec_event_queue
        self.window_length = 1000  # The number of samples to consider in a plot.
        self.plot_info = {"sfreq": self.sfreq, "channel_names": self.channel_names, "channel_types": self.channel_types,
                          "window_length": self.window_length}

        self.data = numpy.empty((len(channel_types), 0))  # The field holding data

        """GUI"""

        self.fig = plt.figure()

        self.additional_windows = [TimeWindow, PSDWindow]

        def gui_update(frame):
            """
                This is the main GUI loop.
            """

            # If there is data in the queue
            if not self.data_queue.empty():
                # Retrieve ALL data form the queue. Necessary as really small packages can clog the pipe.
                queue_data = [self.data_queue.get() for _ in range(self.data_queue.qsize())]

                # Write incoming data to the data field.
                for data in queue_data:
                    self.data = numpy.append(self.data, data, axis=1)

                # Handle edge case that there is not enough data to display.
                if self.data.shape[1] >= self.window_length:
                    # Select the correct updating procedure
                    self.plot.update(self.data)
            self.data = self.data[:, -self.window_length:]

            if not self.info_queue.empty():
                info_queue_data = [self.info_queue.get() for _ in range(self.info_queue.qsize())]
                self.plot.update_infos(info_queue_data)

            if not self.rec_event_queue.empty():
                event_queue_data = [self.rec_event_queue.get() for _ in range(self.rec_event_queue.qsize())]
                self.plot.update_events(event_queue_data)

            if self.plot.should_window_change() is not None:
                change_to = self.plot.should_window_change()
                if change_to == "Time":
                    self.plot = TimeWindow(self.fig, self.plot_info, TimeWindow.get_default_style_dict())
                elif change_to == "PSD":
                    self.plot = PSDWindow(self.fig, self.plot_info, PSDWindow.get_default_style_dict())
                elif change_to == "summary":
                    self.plot = SummaryWindow(self.fig, self.plot_info, SummaryWindow.get_default_style_dict())
                else:
                    print(f"Got Window ID in plot that was not recognized: {change_to}")
        self.plot = SummaryWindow(self.fig, self.plot_info, SummaryWindow.get_default_style_dict())

        self.animation = FuncAnimation(self.fig, gui_update, 1)

    def start(self):
        plt.show()

