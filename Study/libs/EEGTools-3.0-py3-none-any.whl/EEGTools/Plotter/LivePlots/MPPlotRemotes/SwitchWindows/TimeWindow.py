from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchWindows.Window import Window
import mne
from matplotlib import gridspec
from matplotlib.widgets import Button, RadioButtons, TextBox
from matplotlib import pyplot as plt


class TimeWindow(Window):

    def __init__(self, fig, plot_info, style_dict):
        """
        Sewitches the plot to view data in time mode, where x is time and y is channels/amplitude.
        :param fig:
        :return:
        """
        self.fig = fig
        self.plot_info = plot_info
        self.style_dict = style_dict
        self.to_change = None


        # Clear the Plot
        plt.clf()

        # Set the new plot specs.
        spec = gridspec.GridSpec(5, 2, width_ratios=[0.95, 0.05], height_ratios=[0.1, 0.3, 0.3, 0.3, 0.3])

        # Handles the Plot.
        self.ax = fig.add_subplot(spec[:, 0])
        rev_chn_names = list(self.plot_info["channel_names"])
        rev_chn_names.reverse()
        plt.yticks([x * 100 + self.style_dict["channel_padding"] / 2 for x in range(len(self.plot_info["channel_names"]))], rev_chn_names)
        plt.ylabel("EEG Channels")
        plt.xlabel(f"Samples in {self.plot_info['sfreq']} samples per s")
        plt.ylim((0, len(self.plot_info["channel_names"]) * 100 + self.style_dict["channel_padding"]))

        # Radio button to filter by type
        self.time_radio_ax = fig.add_subplot(spec[1, 1])
        radio_set = list(set(self.plot_info["channel_types"]).union(['all', 'name']))
        self.time_radio = RadioButtons(self.time_radio_ax, radio_set, active=radio_set.index('all'))
        self.time_radio_selected = 'all'

        def time_time_radio_callback(label):
            self.time_radio_selected = label
            self.ax.set_ylabel(f"{label} Channels")

        self.time_radio.on_clicked(time_time_radio_callback)

        # Handle tht button
        ax_button_back = fig.add_subplot(spec[0, 1])

        spec.tight_layout(self.fig)

        def summary_callback(event):
            self.to_change = "summary"

        self.button_back = Button(ax_button_back, "Back")
        self.button_back.on_clicked(summary_callback)

        def on_press(event):
            """
            The keypress event to handle the vertical scaling.
            :param event:
            :return:
            """
            if event.key == '+':
                self.style_dict["vertical_scale"] *= 2
            elif event.key == '-':
                self.style_dict["vertical_scale"] /= 2

        fig.canvas.mpl_connect('key_press_event', on_press)

        # UI for the bandpass filtering.
        self.time_radio_filter_ax = fig.add_subplot(spec[2, 1])
        self.time_radio_filter = RadioButtons(self.time_radio_filter_ax, ["None", "2-40", "2-NYQUIST"])
        self.time_radio_filter_selected = 'Test'

        def time_time_radio_filter_callback(label):
            """
            The callback function for the radio buttons for bandpass filtering.
            :param label:
            :return:
            """
            self.time_radio_filter_selected = label

        self.time_radio_filter.on_clicked(time_time_radio_filter_callback)

        self.time_text_box_ax = fig.add_subplot(spec[3, 1])
        self.time_text_box = TextBox(self.time_text_box_ax, 'Channel name', initial="")

        self.time_event_text_ax = fig.add_subplot(spec[4, 1])
        self.time_event_text_ax.get_xaxis().set_visible(False)
        self.time_event_text_ax.get_yaxis().set_visible(False)
        self.time_event_text_ax.set_axis_off()
        self.time_event_text = self.time_event_text_ax.text(0, 0.5, "", wrap=True)

        self.ax.grid(True)

    def update(self, data):
        """
        Updates the Time plot
        :return:
        """
        # Crop data to correct size.
        data_to_display = data[:, -self.plot_info["window_length"]:]

        # Filter for unwanted types
        if self.time_radio_selected == "name":
            try:
                indices = [self.plot_info["channel_names"].index(x) for x in self.plot_info["channel_names"] if self.time_text_box.text in x]
            except ValueError:
                indices = [x for x in range(len(self.plot_info["channel_names"]))]
        else:
            indices = [x for x in range(len(self.plot_info["channel_types"])) if
                       self.plot_info["channel_types"][x] == self.time_radio_selected or self.time_radio_selected == 'all']
        data_to_display = data_to_display[indices, :]
        # Needs to be reversed as matplotlib counts ticks from down to up
        indices.reverse()
        self.ax.set_yticklabels([self.plot_info["channel_names"][index] for index in indices])

        # Reset the lines in the plot
        self.ax.lines = []

        # Frequency Filtering
        if self.time_radio_filter_selected == "2-40":
            data_to_display = mne.filter.filter_data(data_to_display, h_freq=40, l_freq=2, sfreq=self.plot_info["sfreq"],
                                                     verbose=False)

        if self.time_radio_filter_selected == "2-NYQUIST":
            data_to_display = mne.filter.filter_data(data_to_display, l_freq=2, h_freq=int(self.plot_info["sfreq"] / 2 - 1),
                                                     sfreq=self.plot_info["sfreq"],
                                                     verbose=False)

        # For each row
        for i in range(data_to_display.shape[0]):
            # Since we draw bottom up, the lowest rows needs to be drawn first
            row = data_to_display[data_to_display.shape[0] - 1 - i, :]

            row = (row - row.mean())  # Center the plot
            row = row * self.style_dict["vertical_scale"]  # Apply vertical scaling
            row = row + self.style_dict["between_channel_padding"] * i + self.style_dict["channel_padding"] / 2  # Apply padding TODO this padding method is bad.
            self.ax.plot(row, 'b', linewidth=1)  # Display lines in blue in the smallest size

    def update_events(self, events):
        self.time_event_text.set_text(f"{events[-1]}")

    @staticmethod
    def get_default_style_dict():
        return {"between_channel_padding": 100, "vertical_scale": 1, "window_length": 500, "channel_padding": 200}

    def should_window_change(self):
        return self.to_change
