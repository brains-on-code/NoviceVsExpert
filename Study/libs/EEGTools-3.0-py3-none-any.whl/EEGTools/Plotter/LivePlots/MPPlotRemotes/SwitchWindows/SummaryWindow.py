from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchWindows.Window import Window
from matplotlib import gridspec
from matplotlib.widgets import Button
from matplotlib import pyplot as plt


class SummaryWindow(Window):

    def __init__(self, fig, plot_info, style_dict):
        super().__init__(fig, plot_info, style_dict)
        self.fig = fig

        self.plot_info = plot_info
        self.style_dict = style_dict

        self.windows = style_dict["windows"]

        self.window_change = None

        plt.clf()

        # Setup Figure Structure
        spec = gridspec.GridSpec(2, len(self.windows), height_ratios=[0.9, 0.1])

        self.ax = fig.add_subplot(spec[0, :])
        self.ax.get_xaxis().set_visible(False)
        self.ax.get_yaxis().set_visible(False)
        self.buttons = []

        for i in range(len(self.windows)):
            window = self.windows[i]
            ax_call_button = fig.add_subplot(spec[1, i])
            call_button = Button(ax_call_button, window)
            call_button.on_clicked(self._create_window_function(window))
            self.buttons.append(call_button)

        self.summary_summary = self.ax.text(0, 0.9, "", wrap=True)
        self.summary_names = self.ax.text(0, 0.8, "", wrap=True)
        self.summary_types = self.ax.text(0, 0.7, "", wrap=True)
        self.summary_events = self.ax.text(0, 0.6, "")

        spec.tight_layout(self.fig)

    def update(self, data):
        self.summary_summary.set_text(f"The data contains {data.shape[0]} "
                                      f"channels with {data.shape[1]} samples")
        self.summary_names.set_text(f"The Channels are {self.plot_info['channel_names']}")
        self.summary_types.set_text(f"The Channels types are {self.plot_info['channel_types']}")

    def update_events(self, events):
        for event in events:
            self.update_event(event)

    def update_event(self, event):
        self.summary_events.set_text(f"Received events {event}")

    @staticmethod
    def get_default_style_dict():
        return {"windows": ["Time", "PSD"]}

    def should_window_change(self):
        return self.window_change

    def _create_window_function(self, window):
        def f(event):
            self.window_change = window
        return f



