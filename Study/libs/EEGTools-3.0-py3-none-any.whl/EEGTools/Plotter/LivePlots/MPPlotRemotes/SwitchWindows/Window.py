from abc import abstractmethod


class Window:

    @abstractmethod
    def __init__(self, fig, plot_info, style_dict):
        pass

    @abstractmethod
    def update(self, data):
        """
        Update the plot with the given data
        :param data:
        :param channel_names:
        :param channel_types:
        :return:
        """

    @staticmethod
    @abstractmethod
    def get_default_style_dict():
        pass

    def update_events(self, events):
        """
        :param events:
        :return:
        """
        print(f"Received Events in plot: {events}")

    def update_infos(self, infos):
        """
        :param infos:
        :return:
        """
        print(f"Received Infos in plot: {infos}")

    @abstractmethod
    def should_window_change(self):
        pass

