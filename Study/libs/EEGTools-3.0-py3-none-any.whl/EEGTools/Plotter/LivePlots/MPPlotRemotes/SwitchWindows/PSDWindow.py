from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchWindows.Window import Window
from matplotlib import gridspec
from matplotlib.widgets import Button, RadioButtons, TextBox
from matplotlib import pyplot as plt
import mne
from scipy import signal


class PSDWindow(Window):

    def __init__(self, fig, plot_info, style_dict):
        self.plot_info = plot_info
        self.style_dict = style_dict
        self.fig = fig
        self.vertical_scale = 1
        self.to_change = None

        plt.clf()
        self.plot_type = "PSD"
        spec = gridspec.GridSpec(7, 2, width_ratios=[0.9, 0.1])
        self.ax = fig.add_subplot(spec[:, 0])
        rev_chn_names = list(self.plot_info["channel_names"])
        rev_chn_names.reverse()
        plt.yticks([x * 100 + self.style_dict["channel_padding"] / 2 for x in range(len(self.plot_info["channel_names"]))], rev_chn_names)
        plt.ylabel("PSD of Channels")
        plt.ylim((0, len(self.plot_info["channel_names"]) * 100 + self.style_dict["channel_padding"]))

        self.hlines = self.ax.hlines(
            [self.style_dict["between_channel_padding"] * x + self.style_dict["channel_padding"] / 2 for x in range(len(self.plot_info["channel_names"]))],
            [0] * len(self.plot_info["channel_names"]), [self.plot_info["window_length"] / 2] * len(self.plot_info["channel_names"]),
            linewidth=0.5, linestyles=['dotted'] * len(self.plot_info["channel_names"]))

        ax_button_back = fig.add_subplot(spec[0, 1])

        def summary_callback(event):
            self.to_change = "summary"

        self.button_back = Button(ax_button_back, "Back")
        self.button_back.on_clicked(summary_callback)

        self.psd_radio_ax = fig.add_subplot(spec[4, 1])
        radio_set = list(set(self.plot_info["channel_types"]).union(['all', 'name']))
        self.psd_radio = RadioButtons(self.psd_radio_ax, radio_set, active=radio_set.index('all'))
        self.psd_radio_selected = 'all'

        def psd_time_radio_callback(label):
            self.psd_radio_selected = label
            self.ax.set_ylabel(f"{label} Channels")

        self.psd_radio.on_clicked(psd_time_radio_callback)

        self.psd_text_box_ax_left = fig.add_subplot(spec[1, 1])
        self.psd_text_box_left = TextBox(self.psd_text_box_ax_left, 'Left', initial="0")

        self.psd_text_box_ax_right = fig.add_subplot(spec[2, 1])
        self.psd_text_box_right = TextBox(self.psd_text_box_ax_right, 'Right', initial="0")

        self.psd_radio_filter_ax = fig.add_subplot(spec[3, 1])
        self.psd_radio_filter = RadioButtons(self.psd_radio_filter_ax, ["None", "2-40", "50", "2-40/50"])
        self.psd_radio_filter_selected = 'None'

        self.psd_text_box_ax = fig.add_subplot(spec[5, 1])
        self.psd_text_box = TextBox(self.psd_text_box_ax, 'Channel name', initial="")

        def psd_time_radio_filter_callback(label):
            """
            The callback function for the radio buttons for bandpass filtering.
            :param label:
            :return:
            """
            self.psd_radio_filter_selected = label

        self.psd_radio_filter.on_clicked(psd_time_radio_filter_callback)

        def on_press(event):
            """
            The keypress event to handle the vertical scaling.
            :param event:
            :return:
            """
            if event.key == '+':
                self.vertical_scale *= 2
            elif event.key == '-':
                self.vertical_scale /= 2

        fig.canvas.mpl_connect('key_press_event', on_press)

        self.psd_event_text_ax = fig.add_subplot(spec[6, 1])
        self.psd_event_text_ax.get_xaxis().set_visible(False)
        self.psd_event_text_ax.get_yaxis().set_visible(False)
        self.psd_event_text = self.psd_event_text_ax.text(0, 0.5, "", wrap=True)

        self.ax.grid(True)
        spec.tight_layout(self.fig)

    def update(self, data):
        """
        Updates the PSD Plot
        :return:
        """

        self.ax.set_yticklabels(self.plot_info["channel_names"])

        # Reset the lines in the plot
        self.ax.lines = []

        try:
            self.ax.set_xlim((-10, self.plot_info["window_length"] / 2 - int(self.psd_text_box_left.text) - int(
                self.psd_text_box_right.text) - 1 + 10))
        except ValueError:
            self.ax.set_xlim((-10, self.plot_info["window_length"] / 2 + 10))

        if self.psd_radio_selected == "name":
            try:
                indices = [self.plot_info["channel_names"].index(x) for x in self.plot_info["channel_names"] if self.psd_text_box.text in x]
            except ValueError:
                indices = [x for x in range(len(self.plot_info["channel_names"]))]
        else:
            indices = [x for x in range(len(self.plot_info["channel_types"])) if
                       self.plot_info["channel_types"][x] == self.psd_radio_selected or self.psd_radio_selected == 'all']

        # Crop data to correct size. and compute the PSD
        data_to_display = data[indices, -self.plot_info["window_length"]:]

        indices.reverse()
        self.ax.set_yticklabels([self.plot_info["channel_names"][index] for index in indices])

        if self.psd_radio_filter_selected == "2-40":
            data_to_display = mne.filter.filter_data(data_to_display, h_freq=40, l_freq=2, sfreq=self.plot_info["sfreq"],
                                                     verbose=False)
        elif self.psd_radio_filter_selected == "50":
            data_to_display = mne.filter.notch_filter(data_to_display, freqs=50, Fs=self.plot_info["sfreq"], verbose=False)
        elif self.psd_radio_filter_selected == "2-40/50":
            data_to_display = mne.filter.notch_filter(data_to_display, freqs=50, Fs=self.plot_info["sfreq"], verbose=False)
            data_to_display = mne.filter.filter_data(data_to_display, h_freq=40, l_freq=2, sfreq=self.plot_info["sfreq"],
                                                     verbose=False)
        psd_data = signal.periodogram(data_to_display, self.plot_info["sfreq"])
        try:
            labels = [psd_data[0][index] for index in range(
                len(psd_data[0][int(self.psd_text_box_left.text): -int(self.psd_text_box_right.text) - 1]))]
        except ValueError:
            labels = [psd_data[0][index] for index in range(len(psd_data[0]))]
        mod = 20
        filtered_labels = [labels[i] for i in range(len(labels)) if i % mod == 0]
        positions = [i for i in range(len(labels)) if i % mod == 0]
        self.ax.set_xticks(positions)
        self.ax.set_xticklabels(filtered_labels)

        data_to_display = psd_data[1]

        for i in range(data_to_display.shape[0]):
            try:
                row = data_to_display[i, int(self.psd_text_box_left.text): -int(self.psd_text_box_right.text) - 1]
            except ValueError:
                row = data_to_display[i, :]

            row = row * self.vertical_scale  # Apply vertical scaling
            row = row + 100 * i + self.style_dict["channel_padding"] / 2  # Apply padding TODO this padding method is bad.

            self.ax.plot(row, 'b')

    def update_events(self, events):
        self.psd_event_text.set_text(f"{events[-1]}")

    @staticmethod
    def get_default_style_dict():
        return {"between_channel_padding": 100, "vertical_scale": 1, "window_length": 500, "channel_padding": 500}

    def should_window_change(self):
        return self.to_change
