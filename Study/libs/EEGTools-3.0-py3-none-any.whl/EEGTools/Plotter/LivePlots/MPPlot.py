from EEGTools.Plotter.LivePlot import LivePlot
from multiprocessing import Queue, Process
import threading
from EEGTools.Plotter.LivePlots.MPPlotRemotes.SwitchMPLPlot import SwitchMPLPlot


class MPPlot(LivePlot):
    """
    Main GUI window class. Defines the window and initializes the graphs
    for the data from each electrode coming from the EEG headset.
    """

    def __init__(self, sfreq, channel_names, channel_types, shortcuts=None, callback=None, remote=None):
        self.sfreq = sfreq  # The sampling frequency
        self.channel_names = channel_names  # The channel names as given by the recorder class.
        self.channel_types = channel_types   # The channel types as given by the recorder class.
        self.shortcuts = {} if shortcuts is None else shortcuts  # A dict of commands that should evoke a callback
                                                                 # when executed in aplot
        self.remote = remote if remote is not None else SwitchMPLPlot
        if callback is None:
            def f(event):
                print(event)
            callback = f
        self.callback = callback  # The callback for when the plot sends messages to the main program..

        self.data_queue = Queue()  # The data queue to send data to the remote plot
        self.info_queue = Queue()  # TODO
        self.rec_event_queue = Queue()
        self.plot_event_queue = Queue()  # TODO
        self.event_threads = threading.Thread(target=self._wait_for_events, name="Plotting Event Thread")
        self.plot = None
        self.event_thread_is_active = False

    @staticmethod
    def _start_plot(sfreq, channel_names, channel_types, shortcuts, data_queue, info_queue, event_queue, remote,
                    rec_event_queue):
        plot = remote(data_queue, info_queue, event_queue, rec_event_queue, sfreq, channel_names, channel_types,
                      shortcuts)
        plot.start()

    def _wait_for_events(self):
        """
        Reteives Events from the event gueue to send to a callback.
        :return:
        """
        self.event_thread_is_active = True

        while self.event_thread_is_active:  # TODO this is slow
            if not self.plot_event_queue.empty():
                event = self.plot_event_queue.get()
                self.callback(event)

    def start(self):
        """
        Starts running the plot. Happens in a different process and is non blocking.
        :return:
        """
        self.plot = Process(target=self._start_plot, args=(self.sfreq, self.channel_names, self.channel_types,
                                                           self.shortcuts, self.data_queue,self.info_queue,
                                                           self.plot_event_queue, self.remote, self.rec_event_queue))
        self.plot.start()
        self.event_threads.start()

    def stop(self):
        """
        Stops running the plot.
        :return:
        """
        self.data_queue.close()
        self.data_queue.join_thread()

        self.event_thread_is_active = False
        self.plot.kill()  # TODO this is terrible also, does it work while plot is offline?

    def update(self, data):
        """
        Updates the status of the plot
        :param data:
        :return:
        """
        self.data_queue.put(data)  # Just puts the data in the data queue for the remote to fetch.

    def update_event(self, event):
        """
        Updates the status of the plot
        :param event:
        :return:
        """
        self.rec_event_queue.put(event)

    def sendInfo(self, info):
        """
        Sends info to the remote. TODO Wow great description myself.
        :param info:
        :return:
        """
        self.info_queue.put(info)
