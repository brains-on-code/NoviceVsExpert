import matplotlib
from matplotlib import pyplot as plt
from matplotlib.widgets import Button
from matplotlib import gridspec
from scipy import signal
matplotlib.use("Qt5Agg")
import mne


class AwesomePlot:
    """
    A class to output EEG data in a graph using interactive matplotlib
    """

    def plot(self, file_name):
        """
        """
        # Load mne file and extract data
        raw = mne.io.read_raw_fif(file_name)

        # Create figure to work on
        fig = plt.figure()
        #self.plot_time(fig, raw)
        self.plot_summary(fig, raw)

        plt.show()

    def plot_time(self, fig, raw):
        spec = gridspec.GridSpec(1, 2, width_ratios=[0.9, 0.1])
        ax = fig.add_subplot(spec[:,0])
        data = raw.get_data().transpose()
        ax.plot(data)
        ax.set_aspect('auto')

        ax_button_back = fig.add_subplot(spec[0,1])
        def callback_time(that):
            plt.clf()
            self.plot_summary(fig, raw)
        self.button_back = Button(ax_button_back, "Back")
        self.button_back.on_clicked(callback_time)

    def plot_psd(self, fig, raw):
        spec = gridspec.GridSpec(1, 2, width_ratios=[0.9, 0.1])
        ax = fig.add_subplot(spec[:,0])
        data = raw.get_data()
        sfreq = raw.info["sfreq"]
        data = signal.periodogram(data, sfreq)
        ax.plot(data[1].transpose())

        ax_button_back = fig.add_subplot(spec[0,1])
        def callback_time(that):
            plt.clf()
            self.plot_summary(fig, raw)
        self.button_back = Button(ax_button_back, "Back")
        self.button_back.on_clicked(callback_time)

    def plot_summary(self, fig, raw):
        # Setup Figure Structure
        spec = gridspec.GridSpec(2,2, height_ratios=[0.9,0.1])

        ax = fig.add_subplot(spec[0,:])
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)

        ax_button_time = fig.add_subplot(spec[1,0])

        ax_button_freq = fig.add_subplot(spec[1,1])

        def callback_time(that):
            plt.clf()
            self.plot_time(fig, raw)
        def callback_freq(that):
            plt.clf()
            self.plot_psd(fig, raw)

        self.button_time = Button(ax_button_time, "Time Plot")
        self.button_time.on_clicked(callback_time)

        self.button_freq = Button(ax_button_freq, "Freq Plot")
        self.button_freq.on_clicked(callback_freq)

        # Process data from file
        data = raw.get_data()
        sfreq = raw.info["sfreq"]
        channels = raw.info["chs"]
        names = [channel["ch_name"] for channel in channels]
        events = [list(event["list"]) for event in raw.info["events"]]
        event_count = len(events)

        # Write data to figure
        ax.text(0, 0.9, f"The data contains {data.shape[0]} channels with {data.shape[1]} samples and sampling frequency {sfreq}Hz")
        ax.text(0, 0.8, f"The Channels are {names}")
        ax.text(0, 0.7, f"There are {event_count} events")


if __name__ == "__main__":
    import sys
    print(sys.path)
    plot = AwesomePlot()
    plot.plot("foobar_2021-02-11_3.fif")
