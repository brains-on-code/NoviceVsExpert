import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib import pyplot
from matplotlib import image
from matplotlib import colors
from Unicorn_Tools.Unicorn_Recorder.Filtering import Filtering
import  mne
from scipy import signal
from scipy.fftpack import fft
import numpy
from enum import Enum

from Unicorn_Tools.Plotter.OfflinePlot import OfflinePlot


class ActivationPlot(OfflinePlot):
    """
    A class to output EEG data in a graph using interactive matplotlib
    """

    def __init__(self, sfreq: int):
        OfflinePlot.__init__(self, sfreq)
        self.positions = {
            1: (288, 120),
            2: (200, 100),
            3: (288, 200),
            4: (360, 120),
            5: (288, 250),
            6: (200, 280),
            7: (288, 300),
            8: (360, 280)
        }

    def plot(self, data, b=2):
        """
        Plots EEG data to a graph
        :param data: The EEG data given as a numpy matrix of shape(channels, samples)
        :param zero_mean: Whether to subtract the mean from the time signal. (Useless when bandpass filtering)
        :param car: Whether to apply common average referencing
        :param bandpass: when set to none no filter is applied. When seet to (x,y) sets a bandpass filter between xHz and YHz
        :param cutoff: To cutoff data in the beginning of the signal
        :param mode: The domain to display the data in
        :return: None
        """
        img = image.imread(r"..\..\..\Resources\head.png")
        print(img.shape)
        self.axe.imshow(img)
        avgs = []
        for i in range(8):
            avgs.append(numpy.average(data[i,:]))
        maximum = max(avgs)
        minimum = min(avgs)
        cmap = pyplot.cm.copper
        norm = matplotlib.colors.Normalize(vmin=0, vmax=1)
        for i in range(8):
            print((avgs[i]-minimum)/(maximum-minimum))
            self.axe.scatter(self.positions[i+1][0], self.positions[i+1][1], c=[(avgs[i]-minimum)/(maximum-minimum)], cmap=cmap, norm=norm, s=40)
