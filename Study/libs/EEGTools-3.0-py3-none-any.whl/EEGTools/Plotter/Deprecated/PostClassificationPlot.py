import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib import pyplot
from Unicorn_Tools.Unicorn_Recorder.Filtering import Filtering
import mne, numpy
from Unicorn_Tools.Classifiers.SSVEP_Classifier.SSVEPClassifier import SSVEPClassifier
from Unicorn_Tools.Classifiers.PostClassifiers.PostClassifier import PostClassifier
from Unicorn_Tools.Classifiers.roc import ROC
from Unicorn_Tools.Plotter.OfflinePlot import OfflinePlot
from collections import defaultdict


class PostClassificationPlot(OfflinePlot):
    """A plot across time for classification correlations"""

    def __init__(self, classifier: SSVEPClassifier, post_classifier: PostClassifier=None, sfreq: int=250):
        OfflinePlot.__init__(self, sfreq)
        self.classifier = classifier
        self.post_classifier = post_classifier

    def plot(self, data, zero_mean=False, car=False, bandpass=None, cutoff=(0, -1), label_detail=100,
             label_freq_detail=2, channels=None, title="", movAvgFilter=0, clamp=True, overlap=0, baselines=None, events=None,
             data_size=250, expected_classes=None):
        self.axe.set_title(title)
        self.post_classifier.reset()
        channels = [] if channels is None else channels
        events = [] if events is None else events
        expected_classes = {} if expected_classes is None else expected_classes # dict(Event:class)
        classification_numbers = {}
        for key in expected_classes.keys():
            classification_numbers[expected_classes[key]] = {expected_classes[k]: 0 for k in expected_classes}

        data = data[channels, cutoff[0]:cutoff[1] if cutoff[1] > -1 else data.shape[1]]

        if car:
            data = Filtering.car(data)

        if zero_mean:
            data = Filtering.zero_mean(data)

        #if bandpass is not None:
        #    data = mne.filter.filter_data(data, sfreq=self.sfreq, l_freq=bandpass[0], h_freq=bandpass[1])

        if movAvgFilter > 0:
            data = Filtering.movAvg(data, filter_size=20)

        classifications = []
        active_event_id = -1
        active_event_sample = -1
        no_useful_classifications = 0

        for x in range(int(data.shape[1] / (data_size - overlap))):
            if (data_size - overlap)*x > active_event_sample:
                searched_id = active_event_id
                while searched_id < len(events)-1:
                    searched_id += 1
                    if events[searched_id][0] in list(expected_classes.keys()):
                        if active_event_sample < events[searched_id][2] < (data_size - overlap)*x:
                            active_event_id = searched_id
                            active_event_sample = events[active_event_id][0]
                        else:
                            break
            to_classify = mne.filter.filter_data(data[:, (data_size - overlap)*x:
                                  (data_size-overlap)*x+data_size], self.sfreq,
                                                 l_freq=bandpass[0], h_freq=bandpass[1])
            diff = data_size - self.classifier.data_size
            if diff > 0:
                to_classify = to_classify[:, int(diff/2):-int(diff/2)]
            if data.shape[1] < data_size:
                continue
            classification = self.classifier.classify(to_classify)
            if not active_event_id == -1:
                classification_numbers[expected_classes[events[active_event_id][0]]][self.post_classifier.append_predictions(classification)] += 1
                no_useful_classifications += 1
            classifications.append(classification)

        confusion_matrix = ROC.compute_confusion_matrix(classification_numbers)
        for key in confusion_matrix.keys():
            cm = confusion_matrix[key]
            print("Balanced Accuracy", key, ROC.balanced_accuracy(cm[0, 0], cm[1, 0], cm[0, 1], cm[1, 1]))
            print("TPR", key, ROC.true_positive_rate(cm[0,0], cm[0,1]))
            print("TNR", key, ROC.true_negative_rate(cm[1,1], cm[1,0]))
        self.post_classifier.reset()

        positions = []
        labels = []
        for j in range(int(data.shape[1]/(data_size-overlap))):
            if j % label_detail == 0:
                positions.append(j)
                labels.append(f"{j*(data_size-overlap)/self.sfreq:.{label_freq_detail}f}")
        self.axe.set_xticks(positions)
        self.axe.set_xticklabels(labels)

        for event in events:
            pyplot.axvline(int(event[2]/(data_size-overlap)), label=f"Event: {event[0]}", c="r")
            self.axe.annotate(f"Event: {event[0]}", xy=(int(event[2]/(data_size-overlap)), 10))

        print(classifications)
        post_classifications = self.post_classifier.append_multiple_predictions(classifications)
        self.axe.plot(post_classifications, "bo")
        self.axe.legend([f"{self.classifier.frequencies_to_detect}"])

        #pyplot.title(f"{type(self.classifier)} {type(self.post_classifier)}")
        pyplot.xlabel("Time in seconds")
        pyplot.ylabel("Classified Frequency")

        if clamp:
            pyplot.ylim((0, 1))

    def show(self):
        pyplot.show(self.axe)
        self.axe.clear()
        self.fig, self.axe = pyplot.subplots(1, 1)
