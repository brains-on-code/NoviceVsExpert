if __name__ == "__main__":
    from Unicorn_Recorder.EEGTools import PostClassificationPlot
    from Unicorn_Recorder.EEGTools.Unicorn_Recorder.Dummies import RealData
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.FilterBankCanCorrClassifier import FilterBankCanCorrClassifier as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.cca_classifier import CCA_Classfier as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.CanCorr_Classifiers.ExplicitHarmonics import ExplicitHarmonics as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.WeightedHarmonics import WeightedHarmonics as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.Psd_Classifiers.psd_classifer import PSD_Classfier as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.Psd_Classifiers.psd_snr_classifer import PSD_SNR_Classfier as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.CanCorr_Classifiers.ExpectedDavidPainter import ExpectedDavidPainter as Classifier
    from Unicorn_Recorder.EEGTools import PreDavidPainter as Classifier
    #from Unicorn_Recorder.Classifiers.SignalQualityClassifier import SignalQualityClassifier as Classifier
    from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.HighestConfidence import HighestConfidence as PostClassifier
    #from Unicorn_Recorder.Classifiers.PostClassifiers.ConsecutiveConsent import ConsecutiveConsent as PostClassifier
    #from Unicorn_Recorder.Classifiers.PostClassifiers.MajorityVote import MajorityVote as PostClassifier
    #from Unicorn_Recorder.Classifiers.PostClassifiers.WeightedMajorityVote import WeightedMajorityVote as PostClassifier
    import mne, os
    from Unicorn_Recorder.EEGTools import Utils

    PATH = os.path.join(os.path.join(os.environ['USERPROFILE']), "Desktop\\DFKI Recordings\\A\\")
    sfreq = 250

    classifier = Classifier(sfreq, frequencies_to_detect=[10,12], harmonics_depth=3, data_size=500)
    post_classifier = PostClassifier(magic =0.2)
    #post_classifier = PostClassifier(magic=0.2, n_predictions=3, class_ids=[10,12])
    printer = PostClassificationPlot(classifier, sfreq=sfreq, post_classifier=post_classifier)

    files = os.listdir(PATH)
    while True:
        print("Type a command: <plot>, <show>, <exit>")
        command = input()
        if command == "plot":
            selection = Utils.file_slection(PATH)
            raw = mne.io.read_raw_fif(PATH + files[selection], preload=True)
            events = raw.info["events"]
            events = [event["list"] for event in events]
            data = raw.get_data(RealData.UNICORN_ELECTRODES)
            printer.plot(data, bandpass=(2, 40), car=False, cutoff=(250, -1), label_detail=2, label_freq_detail=0,
                         channels=list(range(8)), movAvgFilter=-1, clamp=False, overlap=125, events=events, data_size=500,
                         expected_classes={64:12, 66:-1, 0:10})
        elif command == "show":
            printer.show()
        elif command == "exit":
            break
