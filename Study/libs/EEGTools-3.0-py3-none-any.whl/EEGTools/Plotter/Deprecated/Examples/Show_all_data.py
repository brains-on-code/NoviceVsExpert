if __name__ == "__main__":
    from EEGTools.Plotter.OfflinePlots.MPLPrinter import MPLPrinter
    from EEGTools.Plotter.OfflinePlots.MPLPrinter import DetectionMode
   # from Unicorn_Recorder.EEGTools.Unicorn_Recorder.Dummies import RealData
    import mne
    import os
    from EEGTools.Utils import Utils
    PATH = os.path.join(os.path.join(os.environ['USERPROFILE']), "Desktop\\test\\")

    printer = MPLPrinter(250)

    files = os.listdir(PATH)
    while True:
        print("Type a command: <plot>, <show>, <exit>")
        command = input()
        if command == "plot":
            selection = int(Utils.file_slection(PATH))
            raw = mne.io.read_raw_fif(PATH + files[selection], preload=True)
            events = raw.info["events"]
            events = [event["list"] for event in events]
            print("Events", events)
            data = raw.get_data()[:8, :]
            print(data.shape)
            printer.plot(data, vertical_offset=100, cutoff=(1000,-1),
                         label_freq_detail=0, label_detail=100, events=events,
                         mode=DetectionMode.TIME)
        elif command == "show":
            printer.show()
        elif command == "exit":
            break
