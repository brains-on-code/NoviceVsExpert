if __name__ == "__main__":
    from Unicorn_Recorder.EEGTools import MPLPrinter
    import mne
    import os
    from Unicorn_Recorder.EEGTools import Utils
    import numpy
    PATH = os.path.join(os.path.join(os.environ['USERPROFILE']), "Desktop\\DFKI Recordings\\27.8\\")

    printer = MPLPrinter(250)

    files = os.listdir(PATH)
    while True:
        print("Type a command: <plot>, <exit>")
        command = input()
        if command == "plot":
            selection = int(Utils.file_slection(PATH))
            raw = mne.io.read_raw_fif(PATH + files[selection], preload=True)
            events = numpy.array([[x["list"][2],x["list"][1],x["list"][0]] for x in raw.info["events"]])
            epochs = mne.Epochs(raw, events)
            def f(array):
                return array * 1e-7
            raw.apply_function(f)
            raw.plot(show=True, block=True, events=events)
        elif command == "exit":
            break
