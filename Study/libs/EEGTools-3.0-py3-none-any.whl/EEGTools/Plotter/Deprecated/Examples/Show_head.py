if __name__ == "__main__":
    from Unicorn_Recorder.EEGTools import ActivationPlot
    from Unicorn_Recorder.EEGTools.Unicorn_Recorder.Dummies import RealData
    from Unicorn_Recorder.EEGTools import FilterBankCanCorrClassifier as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.cca_classifier import CCA_Classfier as Classifier
    #from Unicorn_Recorder.Classifiers.SSVEP_Classifier.psd_classifer import PSD_Clasplotsfier as Classifier
    #from Unicorn_Recorder.Classifiers.SignalQualityClassifier import SignalQualityClassifier as Classifier
    from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.HighestConfidence import HighestConfidence as PostClassifier
    #from Unicorn_Recorder.Classifiers.PostClassifiers.ConsecutiveConsent import ConsecutiveConsent as PostClassifier
    #from Unicorn_Recorder.Classifiers.PostClassifiers.MajorityVote import MajorityVote as PostClassifier
    #from Unicorn_Recorder.Classifiers.PostClassifiers.WeightedMajorityVote import WeightedMajorityVote as PostClassifier
    import mne, os
    from Unicorn_Recorder.EEGTools import Utils
    PATH = os.path.join(os.path.join(os.environ['USERPROFILE']), "Desktop\\DFKI Recordings\14.8\\")
    sfreq = 250

    classifier = Classifier(sfreq, frequencies_to_detect=[10, 15], harmonics_depth=2)
    post_classifier = PostClassifier(0)
    printer = ActivationPlot(classifier)

    files = os.listdir(PATH)
    while True:
        print("Type a command: <plot>, <show>, <exit>")
        command = input()
        if command == "plot":
            selection = Utils.file_slection(PATH)
            raw = mne.io.read_raw_fif(PATH + files[selection], preload=True)
            events = raw.info["events"]
            events = [event["list"] for event in events]
            data = raw.get_data(RealData.UNICORN_ELECTRODES)
            print(data.shape)
            printer.plot(data)
        elif command == "show":
            printer.show()
        elif command == "exit":
            break
