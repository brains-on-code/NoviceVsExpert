"""
This is meant to be pyinstalled.
Activate your venv and then call pyinstall mne_plot.py and it will automatically compile the plotter for you.
Useful to check fif files quickly.
"""
import time

import mne
import matplotlib
matplotlib.use("TkAgg")
import sys
import numpy

if __name__ == "__main__":
    scaling_factor = 1  # The factor to scale data by.

    print("Welcome to the MNE Plotter")
    print("The purpose of this program is to offer a quick way of looking at EEG data stored in .fif files")
    print("Drag and drop files onto the .exe to view them")
    while True:
        print("Select a recording by typing its designated number, scale to set a scaling factor, or quit to leave:")
        for i in range(1, len(sys.argv)):
            print(f"[{i}] {sys.argv[i]}")
        user_input = input()
        if user_input == "quit":
            break
        elif user_input.isnumeric():
            number = int(user_input)
            if 0 < number < len(sys.argv):
                try:
                    raw = mne.io.read_raw_fif(sys.argv[number], preload=True)

                    def scaling(arr):
                        return arr * float(scaling_factor)
                    raw.apply_function(scaling)
                    events = numpy.array([event["list"] for event in raw.info["events"]])

                    print(f"Events: {list(events)}")
                    print(f"Events Shape: {events.shape}")
                    print(f"Data Shape: {raw.get_data().shape}")

                    raw.plot(show=True, block=True, events=events)
                except Exception as error:
                    print(f"An error has occurred! Grab Tobi to help: {error}")
            else:
                print(f"The number you entered {user_input} can not be matched to a recording")
        elif user_input == "scale":
            scaling_factor = input("Choose a scaling factor:")
        else:
            print("You made an illegal command. Try again.")
    print("Thank you for using mne_plot")
    time.sleep(1)

