from abc import abstractmethod
from numpy import ndarray
from typing import List
from collections.abc import Callable


class LivePlot:
    """
        This class provides the general structure a plotting class must have to work with the  unicorn_recorder.
    """

    @abstractmethod
    def __init__(self, sfreq: int, channel_names: List[str], channel_types: List[str], shortcuts: dict=None,
                 callback: Callable=None):
        """
        """

    @abstractmethod
    def start(self):
        """
        The method to start the GUI
        """

    @abstractmethod
    def stop(self):
        """
        The method to stop the GUI
        :return:
        """

    @abstractmethod
    def update(self, data: ndarray):
        """
        Updates the plot with the data.
        The data is seen as a continuation of the data already received
        :param data:
        :return:
        """

    @abstractmethod
    def update_event(self, event):
        """
        Sends events to the live plot
        :param event:
        :return:
        """

    @abstractmethod
    def sendInfo(self, info):
        """
        Sends additional information to the plot.
        :param info:
        :return:
        """
