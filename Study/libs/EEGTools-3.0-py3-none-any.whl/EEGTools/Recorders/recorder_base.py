"""
The Recorder Interface
Author: Tobias Jungbluth
Email: toju01@dfki.de
This is a meta class that can be used to quickly implement new recorders.
It already comes with the majority of recording functionality implemented
and only leaves the bare minimum recording functions to the user to implement.
Note that for compatibility it is only necessary to adhere to the Recorder specification not the Recorder_Base.
"""
from abc import abstractmethod
import mne, json, logging, time, os, datetime, numpy
from typing import List
from dateutil import tz

from matplotlib import pyplot as plt
from matplotlib import gridspec
from matplotlib.widgets import TextBox, Button, RadioButtons

from EEGTools.Plotter.LivePlots.MPPlot import MPPlot
from EEGTools.Recorders.recorder import Recorder


class Recorder_Base(Recorder):

    DEFAULT_PATH = os.path.join(os.path.join(os.environ['USERPROFILE']), "Desktop\\")

    def __init__(self, path: str=None, backend=None, montage_file: str=None):
        """
        :param path: The path the recorder should save recordings to.
        :param backend: The backend to use, for the recorder. (I.e. the dummy to use). If left to None selects default.
        """
        super().__init__(path, backend, montage_file)

        self.path = path
        self.backend = backend
        self.montage_file = montage_file

        """Event variables"""
        self._events = []
        self.context_events = []
        self.event_dict = {}

        """Data Variables"""
        self._data = None
        self.sfreq = None
        self.refresh_index = 0

        """Channel variables"""
        self.channelNames = []
        self.channelTypes = []
        self.channelCount = None
        self.montage = None

        """Variables for the sfreq diagnostic"""
        self.last_start = 0
        self.last_clear = 0
        self.last_stop = 0
        self.last_start_sample = 0

        """The variable the Plot is stored in"""
        self.plot = None

    """Static Functions"""

    @staticmethod
    def get_next_filename(path, prefix):
        """
        Determines the next free file name and additional file name to save to.
        :param path:
        :param prefix:
        :return:
        """
        number = 0
        while True:
            file_name = f"{path}{prefix}_{datetime.date.today()}_{number}"

            files_in_dir = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

            contains_file_name = False
            for file in files_in_dir:
                if file_name in file:
                    contains_file_name = True
                    break

            if contains_file_name:
                number += 1

            break
        return file_name

    """Implemented Functions"""

    ### Events ###

    def set_event(self, event_id: int, caller_offset: int=0) -> None:
        """
        Sets an event at the current data point after the last refresh.
        :param event_id: A number indicating the id of the event.
        :param caller_offset: Offsets the data point the event points to.
        """
        event = [self._data.shape[1] - 1 + caller_offset, 0, event_id]
        self._events.append(event)
        if self.plot is not None:
            self.plot.update_event(event)

    def get_events(self) -> numpy.ndarray:
        """
        Returns a list of all the events
        :return: [(), (), ...] TODO
        """
        return self._events

    def get_new_data(self) -> numpy.ndarray:
        """
        Returns new data recorded in the last refresh.
        :return:
        """
        return self._data[:, self.refresh_index:]

    def get_data(self, cutoff: int=0) -> numpy.ndarray:
        """
        Returns all data.
        Data is stores as a numpy array of shape (channels, samples)
        :param cutoff: TODO
        :return:
        """
        return self._data

    def get_sfreq(self) -> float:
        """
        Returns the sampling frequency of the device
        :return:
        """
        return self.sfreq

    def save(self, file_prefix="", path=None, description=None, montage=None, save_additional=False,
             subject_info: dict = None) -> None:
        """
        Saves the current data to a file called "<file_prefix>_<date>_<number>.fif",
        where number is incremented if multiple files are created on the same day.
        Additional data that can not be saved within the fif format is saved to
        "<file_prefix>_<date>_<number>_additional.json".
        If a path was specified in __init__ it will save it there unless <path> was specified in the parameters.
        If both are unspecified the file is saved to the users Desktop.
        :param file_prefix:
        :param path:
        :param description: A description of the recording to go along with it.
        :param montage: Montage File to use.
        :param save_additional: Wether to save addtional JSON data with the fif Recording.
        :return:
        """
        if path is None:
            path = self.path
            if path is None:
                logging.warning("Function did not specify path to save to, neither did the class."
                                f"Attempting to save to {self.DEFAULT_PATH}")
                path = self.DEFAULT_PATH

        if description is None:
            description = "An EEG recording"

        info = mne.create_info(self.channelNames, self.get_sfreq(), self.channelTypes)
        info["description"] = description
        info['events'] = [{'list': event} for event in self._events]
        info["subject_info"] = {} if subject_info is None else subject_info

        data = self.get_data()

        raw = mne.io.RawArray(data, info)  # TODO Beleg

        raw.set_montage(self.montage)

        date = datetime.datetime.now().replace(tzinfo=tz.gettz("UTC")).astimezone(tz.tzlocal()).timestamp()
        raw.set_meas_date(date)

        # Determine an unused filename to save to.
        filename = self.get_next_filename(path, file_prefix)
        raw.save(filename + ".fif")
        logging.info("File saved successfully")

        if save_additional:
            with open(filename + "_additional.json", "w") as file:
                json.dump({"Context_Events": self.context_events, "Event_Dictionary": self.event_dict}, file)
                logging.info("Additional File saved successfully")

    def clear(self) -> None:
        """
        Deletes the currently recoded events and data, since the last call to refresh.
        :return:
        """
        self._data = numpy.empty((self.channelCount, 0))
        self._events = []
        self.context_events = []

        self.refresh_index = 0  # Needs to be reset as old data is gone now.

        self.last_clear = time.time()
        self.last_start_sample = self._data.shape[1]

    def get_names(self) -> List[str]:
        """
        Returns a list with the name of every channel.
        Note that these names are unique.
        :return: [str, str, ...]
        """
        return self.channelNames

    def get_channels_from_names(self, names: List[str]) -> dict:
        """
        Returns a dict of channels that have the names specified in <names>.
        :param names: The names to search for
        :return: {channelName: channel, ...}
        """
        channels = {}
        for i in range(self.channelCount):
            for name in names:
                if self.channelNames[i] == name:
                    channels[name] = i
        return channels

    def get_channel_types(self) -> List[str]:
        """
        Returns a list of channel types corresponding to the channels of the recorded data.
        :return: [ChannelType, ChannelType, ...]
        """
        return self.channelTypes

    def get_range_of_type(self, c_type: str) -> List[int]:
        """
        Returns a list of indices designating which channels are of <c_type> type.
        :param c_type: The ChannelType to search for.
        :return: [uint, uint, ...]
        """
        channel_range = []
        for i in range(len(self.channelTypes)):
            if self.channelTypes[i] == c_type:
                channel_range.append(i)
        return channel_range

    def get_channel_from_name(self, name: str) -> int:
        """
        Returns the first index of the channel with name <name>.
        :param name: The name to look for.
        :return: uint
        """
        for i in range(self.channelCount):
            if self.channelNames[i] == name:
                return i
        return None

    def set_timestamp(self, event_id=0, caller_offset=0, timestamp=None) -> None:
        """
        Sets a timestamp at the current sample index with the given time.
        If time is None time is set to the current time given by python inbuilt time.time()
        :param caller_offset: Offsets the sample that the timestamp is saved at.
        :param time: the timestamp to save. If None is time.time()
        :return:
        """
        if timestamp is None:
            timestamp = time.time()

        event_sample = self._data.shape[1] - 1 + caller_offset

        self.context_events.append([event_sample, 0, event_id, {"type": "timestamp", "timestamp": timestamp}])

    def sfreq_diagnostic(self) -> float:
        """ TODO Should maybe also output the specific number of samples. Can be ambiguous for longer recordings.
        A simple tool that computes the number of samples that should have been recorded from the last
        start_recording/clear to stop_recording/now.
        :WARNING: The function might throw a value error if the amount of recorder samples is zero.
        :return: A float that acts as a quality control. If ==1 perfect, <1 Less samples in recorder then expected
                 >1 More samples then expected.
        """
        start = self.last_clear if self.last_clear > self.last_start else self.last_start
        stop = self.last_stop if self.last_stop > self.last_start else time.time()

        recording_duration = stop - start

        expected_samples = self.get_sfreq() * recording_duration
        actual_samples = self._data.shape[1] - self.last_start_sample

        return actual_samples / expected_samples

    def subject_info_ui(self) -> dict:
        """
        Starts a UI for subject info which is then returned as a dict.
        :return:
        """
        fig = plt.figure()
        spec = gridspec.GridSpec(8, 3)

        ax_last_name = fig.add_subplot(spec[0, :])
        box_last_name = TextBox(ax_last_name, 'Last name')

        ax_first_name = fig.add_subplot(spec[1, :])
        box_first_name = TextBox(ax_first_name, 'First name')

        ax_id = fig.add_subplot(spec[2, :])
        box_id = TextBox(ax_id, 'ID')

        ax_handedness = fig.add_subplot(spec[3, :])
        radio_handedness = RadioButtons(ax_handedness, ["left", "right", "ambidextrous"], active=1)

        ax_sex = fig.add_subplot(spec[4, :])
        radio_sex = RadioButtons(ax_sex, ["male", "female", "unknown"], active=0)

        ax_birthday_day = fig.add_subplot(spec[5, 0])
        box_birthday_day = TextBox(ax_birthday_day, 'Day')

        ax_birthday_month = fig.add_subplot(spec[5, 1])
        box_birthday_month = TextBox(ax_birthday_month, 'Month')

        ax_birthday_year = fig.add_subplot(spec[5, 2])
        box_birthday_year = TextBox(ax_birthday_year, 'Year')

        ax_done = fig.add_subplot(spec[6, :])
        button_done = Button(ax_done, 'Done')

        ax_msg = fig.add_subplot(spec[7, :])
        box_msg = ax_msg.text(0, 0.5, 'Messages')

        def button_done_callback(label):
            try:
                id = int(box_id.text)
                if id < 0:
                    box_msg.set_text(f"Got a negative ID. Only positive IDs are allowed!")
                    return
            except Exception as error:
                print(f"An error occurred while parsing the ID: {error}")
                box_msg.set_text(f"An error occurred while parsing the ID: {error}")
                return

            active = radio_sex.value_selected
            if active not in ["male", "female", "unknown"]:
                box_msg.set_text("Nothing or an unknown option was selected in sex.")
                return

            active = radio_handedness.value_selected
            if active not in ["left", "right", "ambidextrous"]:
                box_msg.set_text("Nothing or an unknown option was selected in handedness.")
                return

            day, month, year = 0, 0, 0
            try:
                year = int(box_birthday_year.text)
                month = int(box_birthday_month.text)
                day = int(box_birthday_day.text)
            except Exception as error:
                box_msg.set_text(f"Encountered an error while parsing birthdate: {error}")
                return

            try:
                datetime.datetime(year=year, month=month, day=day)
            except Exception as error:
                box_msg.set_text(f"Encountered an error while parsing birthdate: {error}")
                return

            plt.close()

        button_done.on_clicked(button_done_callback)

        plt.show()

        id = int(box_id.text)

        handedness = -1
        if radio_handedness.value_selected == "left":  # For assignments see mne Info docs
            handedness = 2
        elif radio_handedness.value_selected == "right":
            handedness = 1
        elif radio_handedness.value_selected == "ambidextrous":
            handedness = 3

        sex = -1
        if radio_sex.value_selected == "male":  # For assignments see mne Info docs.
            sex = 1
        elif radio_sex.value_selected == "female":
            sex = 2
        elif radio_sex.value_selected == "unknown":
            sex = 0

        return {"last_name": box_last_name.text, "first_name": box_first_name.text, "id": id,
                "hand": handedness, "sex": sex,
                "birthday": (int(box_birthday_year.text), int(box_birthday_month.text), int(box_birthday_day.text))}

    def connect_plot(self, plot=None) -> None:  # TODO return handle?
        """
        Connects a plot from the plotting class to the recorder.
        If left to None will open a default plot to look at data.
        :param plot:
        :return:
        """
        if plot is None:
            self.plot = MPPlot(self.sfreq, self.channelNames, self.channelTypes)
        else:
            self.plot = plot
        self.plot.start()

    def disconnect_plot(self) -> None:
        """
        Closes a plot if one is opened
        :return:
        """
        if self.plot is not None:
            self.plot.stop()
            self.plot = None

    def set_event_dict(self, event_dict: dict):
        """
        Sets an event dictionary that parses event ID ints to strings.
        :param event_dict:
        :return:
        """
        self.event_dict = event_dict

    def set_classification(self, classification, event_id=0, confidence_levels=None):
        self.context_events.append([self._data.shape[1], 0, event_id, {"type": "classification",
                                                                       "classification": classification,
                                                                       "confidence_levels": confidence_levels}])

    def set_context_event(self, content, event_id=0, caller_offset=0):
        """
        Set a custom context event with anything that you like.
        :param content:
        :return:
        """
        self.context_events.append([self._data.shape[1] + caller_offset, 0, event_id,
                                    {"type": "custom", "content": content}])

    """Abstract Methods"""

    @abstractmethod
    def refresh(self) -> None:
        """
        Refreshes the data. If new data has been recorded, it is now accessible.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def start_recording(self) -> None:
        """
        Starts recording data from the eeg.
        Can only be called after the eeg was connected.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def stop_recording(self) -> None:
        """
        Stops recording from the eeg.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def connect(self) -> None:
        """Connects to te device. Necessary to call before recording"""
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def disconnect(self) -> None:
        """Disconnects from the device."""
        raise NotImplementedError("This method was not yet implemented")

