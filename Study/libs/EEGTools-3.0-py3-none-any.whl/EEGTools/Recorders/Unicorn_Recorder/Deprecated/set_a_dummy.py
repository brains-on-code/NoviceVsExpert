from EEGTools.Recorders.Unicorn_Recorder.unicorn_recorder import Unicorn_recorder
from EEGTools.Recorders.Unicorn_Recorder.Dummies import SawTooth
# Dummies that are available
# from Unicorn_Recorder.Unicorn_Tools.Unicorn_Recorder.Dummies import SawTooth

#from Unicorn_Recorder.EEGTools.Unicorn_Recorder.Dummies import RealData
#path = "C:\\Users\\Tobias\\Desktop\\unicorn test data\\Freq10.fif"
#electrodes = RealData.UNICORN_ELECTRODES


if __name__ == "__main__":
    backend = SawTooth.get_backend()
    rec = Unicorn_recorder(backend=backend, montage_file="../locs_electrode_placement_gtec_unicorn_standard.locs")
    rec.connect()
    rec.start_recording(test_signal_mode=True)
    rec.connect_plot()
    while True:
        pass
