if __name__ == "__main__":
    from Unicorn_Recorder.EEGTools import Unicorn_Recorder
    from Unicorn_Recorder.EEGTools.Unicorn_Recorder.Dummies import SawTooth
    from Unicorn_Recorder.EEGTools import SwitchPlot as Plotclass
    Unicorn_Recorder.set_backend(SawTooth)

    from Unicorn_Recorder.EEGTools import Unicorn_recorder
    import time

    rec = Unicorn_recorder()
    rec.connect()
    rec.start_recording()
    rec.open_plot(1, Plotclass)
    rec.set_event(0)
    time.sleep(20)
    rec.refresh()
    rec.set_event(1)
    rec.stop_recording(wait=True)                  # Set this to wait until the recording was actually stopped
    rec.close_plot()
    rec.refresh()                                  # the save function only considers values that were refreshed
    rec.save("test.fif", overwrite=True)           # Saves to desktop per default.
    rec.disconnect()
    rec.close_remote()
