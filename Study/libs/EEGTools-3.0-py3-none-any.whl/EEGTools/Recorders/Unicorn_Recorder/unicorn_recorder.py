"""
The Unicorn Recorder
Author: Tobias Jungbluth
Email: toju01@dfki.de
This class is supposed to help with recording with the gtec Unicorn device.
The manual mentioned throughout the documentation is the "User Manual for Unicorn Brain Interface Hybrid Black".
Manual Version Number: 1.18.00
"""
import numpy, struct, threading, mne, time, logging
from scipy import signal, fftpack
from multiprocessing import Queue, Process, Pipe
from matplotlib import pyplot as plt
from matplotlib.widgets import Button
from matplotlib import gridspec
from matplotlib.animation import FuncAnimation
from EEGTools.Recorders.recorder_base import Recorder_Base


class _RecorderRemote:  # TODO atexit kill für keyboard interrupts.

    __BYTES_PER_CHANNEL = 4

    def __init__(self, pipe, backend_call, backend_args):
        self.__eeg = None

        self.is_running = True

        self.pipe = pipe

        self.backend = backend_call(backend_args)

        self.__unpacked_data = []
        self.__unpacked_data_lock = threading.Lock()
        self.__recording_thread = None

    def listen(self):
        while self.is_running:
            action = self.pipe.recv()
            for key in action.keys():
                getattr(self, key)(*action[key])

    def terminate(self):
        self.is_running = False

    def forward_eeg_call(self, *actions):
        for action in actions:
            for key in action.keys():
                result = getattr(self.__eeg, key)(*action[key])
                self.pipe.send(result)

    def connect(self, device_id=0, paired=True):
        """
        Connects to the specified device.
        Throws an IndexError if specified device was not found
        :param device_id: Can either be string, to connect to a device with a specific name or int specifying an index
                          of all available devices
        :param paired: Whether to check for paired or unpaired devices.
                       If you have knowledge on Bluetooth feel free to experiment with this.
                       If not, then pair the device via the Unicorn Suite first and leave it True.
                       See manual 15.6.4.2
        :return: None
        """
        if isinstance(device_id, int):
            devices = self.backend.GetAvailableDevices(paired)
            if len(devices) <= device_id >= 0:
                raise IndexError(f"ID: {device_id} is not valid. "
                                 f"ID is either wrong or device was not found."
                                 f"Number of available devices: {devices}")
            else:
                self.__eeg = self.backend.Unicorn(devices[0])
                print(f"Successfully connected device {device_id}")
        elif isinstance(device_id, str):
            self.__eeg = self.backend.Unicorn(device_id)  # TODO Can I be sure that it exists?
            print(f"Successfully connected device {device_id}")
        else:
            print(f"device_id needs to be either int or string, got {type(device_id)}")

    def start_recording(self, frame_length=10, test_signal_mode=False):
        """ TODO frame_length default value
            Starts a recording.
            Note, that the Unicorn is continuously capturing data.
        :return:
        """
        if test_signal_mode:
            logging.warning("TEST SIGNAL MODE IS ENABLED, YOU WILL NOT RECORD REAL EEG DATA!")
        self.__eeg.StartAcquisition(test_signal_mode)
        self.__recording_thread = threading.Thread(name="RecordingThread", target=self.__recording_loop,
                                                   args=(frame_length,))
        self.__recording_thread.start()

    def stop_recording(self, wait=True):
        """
        Stops the recording. Waits for it to end if wait is set to true.
        :return:None
        """
        self.__recording_thread.is_running = False
        if wait:
            self.__recording_thread.join()

    def __recording_loop(self, frame_length=1):
        """
        Starts a continuous recording.
        See manual 15.5.4 and 15.6.5.2.3
        :return:None
        """
        current_thread = threading.currentThread()

        buffer_length = frame_length * self.__eeg.GetNumberOfAcquiredChannels() * self.__BYTES_PER_CHANNEL
        while getattr(current_thread, "is_running", True):
            buffer = bytearray(buffer_length)
            self.__eeg.GetData(frame_length, buffer, buffer_length)
            with self.__unpacked_data_lock:
                self.__unpacked_data.append(buffer)

    def refresh(self):
        """
        Get the data that was recorded since the last call to refresh.
        If there was no previous call to refresh, since the last call to start_recording
        !WARNING! THIS FUNCTION WILL NOT WORK IF NO EEG IS CONNECTED
        :return: None
        """
        with self.__unpacked_data_lock:
            self.pipe.send(self.__unpacked_data)
            self.__unpacked_data = []

    def disconnect(self):
        """
        Disconnects the currently connected device.
        It is not necessary to call this function explicitly.
        The garbage collector will disconnect it automatically.
        Use only, if you need to connect to it repeatedly.
        See manual 15.5.5 and 15.5.6
        :return: None
        """
        del self.__eeg


class Unicorn_recorder(Recorder_Base):

    # The space needed to store a single value from any channel
    # See manual 16.6.5.2.3
    __BANDWITH = 4 #TODO find good bandwith

    # Path to save to if None is given

    def __init__(self, path=None, backend=None, montage_file=None):
        super().__init__(path, backend)

        # The recorded EEG data and events.
        self.__data_lock = threading.Lock()
        self.__event_lock = threading.Lock()

        self.__plotting_thread = None

        # Length of the data since last get_new_data call
        self.__new_data_index = 0

        # The path to save eeg data and events to.
        # If set to none will attempt to save at default path.
        self.path = path
        self.__plot_queue = Queue()

        self.parent_conn, self.child_conn = Pipe()

        # The backend to use. This is what defines the Dummy.
        if backend is None:
            backend = (self.default_backend, {})
        self.backend_call = backend[0]
        self.backend_args = backend[1]

        self.backend = self.backend_call(self.backend_args)

        # The sampling frequency of the EEG
        # See manual 15.6.1, 2.1
        # This should always be 250
        self.sfreq = self.backend.SamplingRate

        # The montage of the EEG.
        if montage_file is not None:
            #ch_names_in_order = list(numpy.genfromtxt(montage_file, usecols=[3], dtype=str))
            self.montage = mne.channels.read_custom_montage(montage_file)
            self.montage_file = montage_file

        self.channelNames = ["Fz", "C3", "Cz", "C4", "Pz", "PO7", "Oz", "PO8"] +\
                            ["ACC_X", "ACC_Y", "ACC_Z", "GYRO_X", "GYRO_Y", "GYRO_Z", "BATTERY", "COUNTER", "VALID"]
        # The types for each channel.
        self.channelTypes = ['eeg'] * 8 + ['misc'] * 9

        self.channelCount = 17

        self.process = None

    @staticmethod
    def default_backend(args):
        import UnicornPy
        return UnicornPy

    @staticmethod
    def connect_remote(pipe, backend_call, backend_args):
        print("starting remote")
        remote = _RecorderRemote(pipe, backend_call, backend_args)
        remote.listen()
        print("closing remote")

    def close_remote(self):
        print("Killing remote")
        self.process.terminate()

    # --- Forwarded Functions ---

    def send_to_remote(self, info: dict):
        """
        To manually send instructions to the EEG Remote.
        The recorder expects a dict of form {function_name_1:[arg1, arg2, ...], function_name_2: ...}
        The order of function calls being executed is considered non-deterministic.
        It is advised to just use the methods already provided, using this function will have the same effect though.
        :param info:
        :return:
        """
        self.parent_conn.send(info)

    def connect(self, device_id: int=0, paired: bool=True):
        """
        Connects to the specified device.
        Throws an IndexError if specified device was not found
        :param device_id: Can either be string, to connect to a device with a specific name or int specifying an index
                          of all available devices
        :param paired: Whether to check for paired or unpaired devices.
                       If you have knowledge on Bluetooth feel free to experiment with this.
                       If not, then pair the device via the Unicorn Suite first and leave it True.
                       See manual 15.6.4.2
        :return: None
        """
        self.process = Process(name="EEGRemote", target=self.connect_remote, args=(self.child_conn, self.backend_call, self.backend_args))
        self.process.start()

        self.parent_conn.send({"connect": [device_id, paired]})
        self.parent_conn.send({"forward_eeg_call": [{"GetNumberOfAcquiredChannels": []}]})
        res = self.parent_conn.recv()
        self._data = numpy.zeros((res, 1))

    def disconnect(self):
        """
        Disconnects the currently connected device.
        It is not necessary to call this function explicitly.
        The garbage collector will disconnect it automatically.
        Use only, if you need to connect to it repeatedly.
        See manual 15.5.5 and 15.5.6
        :return: None
        """
        self.parent_conn.send({"disconnect": []})
        self.parent_conn.send({"terminate": []})

    def start_recording(self, frame_length: int=10, test_signal_mode: bool=False):
        """ TODO frame_length default value
            Starts a recording.
            Note, that the Unicorn is continuously capturing data.
        :return:
        """
        self.parent_conn.send({"start_recording": [frame_length, test_signal_mode]})

        self.last_start_sample = self._data.shape[1]
        self.last_start = time.time()

    def stop_recording(self, wait: bool=True):
        """
        Stops the recording. Waits for it to end if wait is set to true.
        :return:None
        """
        self.parent_conn.send({"stop_recording": [wait]})

        self.last_stop = time.time()

    # TODO this is deprecated
    def get_Configuration(self):
        """
        Returns the Configuration so that easy changes can be made to it.
        :return: the eeg channels, the accelarator channels, the gyroscope hannels, battery, counter and val ind. #TODO Beleg
        """
        configuration = self.backend.AmplifierConfiguration()
        channels = configuration.Channels
        eeg_channels = channels[:8]
        acc_channels = channels[8:11]
        gyro_channels = channels[11:14]
        battery_channel = channels[14]
        counter_channel = channels[15]
        val_ind_channel = channels[16]
        return eeg_channels, acc_channels, gyro_channels, battery_channel, counter_channel, val_ind_channel

    def refresh(self):
        self.__new_data_index = self._data.shape[1]

        """
        Get the data that was recorded since the last call to refresh.
        If there was no previous call to refresh, since the last call to start_recording
        !WARNING! THIS FUNCTION WILL NOT WORK IF NO EEG IS CONNECTED
        :return: None
        """
        self.parent_conn.send({"refresh": []})
        unpacked_data = self.parent_conn.recv()

        """
        Unpack the data and write it to the data matrix.
        The unpacking is specified in manual 16.6.5.2.3
        Note, that the accuracy of the sample is 24 bit. The 32 bit float values are generated because python expects 
        that size in the struct library.
        The whole packed data consists of a number of (channels * bytes per channel * number of samples) bytes.
        """
        self.parent_conn.send({"forward_eeg_call": [{"GetNumberOfAcquiredChannels": []}]})
        res = self.parent_conn.recv()
        eff = struct.Struct("f" * res)
        samples = []
        for buffer in unpacked_data: # TODO Is this safe?
            for sample in eff.iter_unpack(buffer):
                samples.append(sample)
            del buffer
        if len(samples) > 0:
            with self.__data_lock:
                self._data = numpy.append(self._data, numpy.matrix(samples).transpose(), axis=1).getA()

        if self.plot is not None:
            self.plot.update(self.get_new_data())

    def quality_check(self):
        """
        A Unicorn specific Function similar to an impedance check.
        Is blocking!
        TODO Maybe find a way to have quality in the Meta class.
        :return:
        """
        """Set up plot"""
        fig = plt.figure()
        spec = gridspec.GridSpec(1, 2, width_ratios=[0.9, 0.1])

        # Handles the bar Plot.
        ax = fig.add_subplot(spec[:, 0])
        ax.set_yticklabels(["", "", "BAD", "", "POOR", "", "GREAT"])  # TODO These ticks are on 0.5 intervals for some reason.
                                                                      # TODO Would be more intuitive with ints
        plt.ylim((0,3))
        text = ax.bar(list(range(len(self.get_range_of_type("eeg")))), [0]*len(self.get_range_of_type("eeg")))

        # The axe and button widget of the plot
        ax_button = fig.add_subplot(spec[:, 1])
        button = Button(ax_button, "Finish")

        def callback(this):
            """
            The callback for the Finish button
            :param this:
            :return:
            """
            # Tell the qualit checker to stop and then close the figure.
            plt.close(fig)
        button.on_clicked(func=callback)
        sleep_time = 1  # Set so that there is overlap in the data, and not to large.
        window_length = 3200

        def update(frame):

            sfreq = self.get_sfreq()
            time.sleep(sleep_time)

            self.refresh()

            # Check the signal qualites of the last 250 samples.
            data = self.get_data()[self.get_range_of_type("eeg"), int(-window_length):]
            data = mne.filter.filter_data(data, sfreq=sfreq, l_freq=2, h_freq=90, verbose=False)
            data = mne.filter.notch_filter(data, Fs=sfreq, freqs=50, verbose=False)

            # Do the actual checks
            qualities = self.check_signal_quality(data, sfreq)
            #qualities = [random.randint(0,2) for _ in range(len(self.get_range_of_type("eeg")))] #Quick test function!

            for rect, h in zip(text, qualities):
                # For each bar in the plot and computed quality, set bar to quality level
                rect.set_height(h+1)
                if h == 0:
                    color = "red"
                elif h == 1:
                    color = "yellow"
                elif h == 2:
                    color = "green"
                else:
                    color = "purple"
                rect.set_color(color)
        # Start the gui loop to update the plot.
        animation = FuncAnimation(fig, update, 200)
        plt.show()

    @staticmethod
    def check_signal_quality(data, sfreq):
        """
        The quality check described in 18.8.2 in the manual
        :param data: the data matrix. Tobe in accordance with the manual, input exactly 2 seconds of material
        :return: The signal quality in BAD=0 POOR=1 and GOOD=2
        """
        std_checks = Unicorn_recorder.check_std(data)
        bpmd_checks = Unicorn_recorder.check_bpmd(data, sfreq)
        return [2 if std_checks[i] and bpmd_checks[i] else
                (1 if std_checks[i] or bpmd_checks[i] else 0)
                for i in range(len(data))]

    @staticmethod
    def check_std(data):
        """
        The standard deviation check as described in 18.8.2 in the manual.
        :param data: the data matrix
        :return: a boolean array indicating good(True) and bad(False) signal quality for each channel
        """
        if data.shape[0] < 2:  # STDV is not defined for 1 value. Thus the quality is just False
            return [False] * data.shape[1]
        data_std = numpy.asarray(numpy.std(data, axis=1)).reshape(data.shape[0])
        return [7 < data_std[x] < 50 for x in range(data_std.shape[0])]

    @staticmethod
    def check_bpmd(data, sfreq):
        """
        The standard bandpass median difference check as described in 18.8.2 in the manual.
        Should only be called on 1s of material TODO manual?
        :param data: the data matrix
        :return: a boolean array indicating good(True) and bad(False) signal quality for each channel
        """

        # Note, that if there are less than 60 data points, there are not enough values to actually compute the check.
        # Thus, False is returned.
        if data.shape[1] >= 60:
            data = numpy.asarray(data)
            # Apply Notch filters
            fif_num, fif_dem = signal.iirnotch(50, 50 / Unicorn_recorder.__BANDWITH, fs=sfreq)
            six_num, six_dem = signal.iirnotch(60, 60 / Unicorn_recorder.__BANDWITH, fs=sfreq)#TODO This is a problem. The filter will just look weird
            notch_data = [signal.lfilter(six_num, six_dem, signal.lfilter(fif_num, fif_dem, row)) for row in data]
            notch_freqs = [fftpack.rfft(row) for row in notch_data]
            notch_mean = [sum(row[51 - 2:51 + 2]) / len(row[51 - 2:51 + 2]) +
                          sum(row[61 - 2:61 + 2]) / len(row[61 - 2:61 + 2])
                          for row in notch_freqs]
            notch_mean = [val / 2 for val in notch_mean]

            # Apply Band Pass
            band_num, band_dem = signal.butter(2, [0.1 / (sfreq / 2), 30 / (sfreq / 2)], output='ba', btype="bandpass") # TODO WHat is a good filter here?
            band_data = [signal.lfilter(band_num, band_dem, signal.lfilter(band_num, band_dem, row)) for row in data]
            band_freqs = [fftpack.rfft(row) for row in band_data]
            band_mean = [sum(row[1:30]) / len(row[1:30])
                         for row in band_freqs]

            return [band_mean[i] - notch_mean[i] > 0.1 for i in range(len(band_mean))]
        else:
            return [False] * data.shape[0]