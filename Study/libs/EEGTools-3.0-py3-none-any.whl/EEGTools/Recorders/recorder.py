"""
The Recorder Interface
Author: Tobias Jungbluth
Email: toju01@dfki.de
This class is the specification all other Recorders need to adhere to.
"""
from abc import abstractmethod
import numpy
from typing import List


class Recorder:

    @abstractmethod
    def __init__(self, path: str=None, backend=None, montage_file: str=None):
        """
        :param path:
        :param backend:
        :param montage_file:
        """

    """Abstract Functions"""

    ### Events ###

    @abstractmethod
    def set_event(self, event_id: int, caller_offset: int=0) -> None:
        """
        Sets an event at the current data point after the last refresh.
        :param event_id: A number indicating the id of the event.
        :param caller_offset: Offsets the data point the event points to.
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_events(self) -> numpy.ndarray:
        """
        Returns a list of all the events
        :return: [(), (), ...] TODO
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def set_timestamp(self, event_id=0, caller_offset=0, timestamp=None) -> None:
        """
        Sets a timestamp at the current sample index with the given time.
        If time is None time is set to the current time given by python inbuilt time.time()
        :param caller_offset: Offsets the sample that the timestamp is saved at.
        :param timestamp: the timestamp to save. If None is time.time()
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def set_event_dict(self, event_dict: dict):
        """
        Sets an event dictionary that parses event ID ints to strings.
        :param event_dict:
        :return:
        """

    @abstractmethod
    def set_context_event(self, content, event_id=0, caller_offset=0):
        """
        Set a custom context event with anything that you like.
        :param content:
        :return:
        """

    @abstractmethod
    def set_classification(self, classification, event_id=0, confidence_levels=None):
        """
        A dictionary containing all the names of the classes being classified.
        :param classes:
        :return:
        """

    @abstractmethod
    def refresh(self) -> None:
        """
        Refreshes the data. If new data has been recorded, it is now accessible.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_new_data(self) -> numpy.ndarray:
        """
        Returns new data recorded in the last refresh.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_data(self, cutoff: int=0) -> numpy.ndarray:
        """
        Returns all data.
        Data is stores as a numpy array of shape (channels, samples)
        :param cutoff: TODO
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_sfreq(self) -> float:
        """
        Returns te sampling frequency of the device
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def save(self, file_prefix: str = "", path: str = None, description: str = None, save_additional: bool = False,
             subject_info: dict = None) -> None:
        """
        Saves the current data to a file called "<file_prefix>_<date>_<number>.fif",
        where number is incremented if multiple files are created on the same day.
        Additional data that can not be saved within the fif format is saved to
        "<file_prefix>_<date>_<number>_additional.json".
        If a path was specified in __init__ it will save it there unless <path> was specified in the parameters.
        If both are unspecified the file is saved to the users Desktop.
        :param file_prefix:
        :param path:
        :param description: A description of the recording to go along with it.
        :param montage: Montage File to use.
        :param save_additional: Wether to save addtional JSON data with the fif Recording.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def start_recording(self) -> None:
        """
        Starts recording data from the eeg.
        Can only be called after the eeg was connected.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def stop_recording(self) -> None:
        """
        Stops recording from the eeg.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def connect(self) -> None:
        """Connects to te device. Necessary to call before recording"""
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def disconnect(self) -> None:
        """Disconnects from the device."""
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def clear(self) -> None:
        """
        Deletes the currently recoded events and data, since the last call to refresh.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def connect_plot(self, plot=None) -> None:  # TODO return handle?
        """
        Connects a plot from the plotting class to the recorder.
        If left to None will open a default plot to look at data.
        :param plot:
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def disconnect_plot(self) -> None:
        """
        Closes a plot if one is opened
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_names(self) -> List[str]:
        """
        Returns a list with the name of every channel.
        Note that these names are unique.
        :return: [str, str, ...]
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_channels_from_names(self, names: List[str]) -> dict:
        """
        Returns a dict of channels that have the names specified in <names>.
        :param names: The names to search for
        :return: {channelName: channel, ...}
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_channel_types(self) -> List[str]:
        """
        Returns a list of channel types corresponding to the channels of the recorded data.
        :return: [ChannelType, ChannelType, ...]
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_range_of_type(self, c_type: str) -> List[int]:
        """
        Returns a list of indices designating which channels are of <c_type> type.
        :param c_type: The ChannelType to search for.
        :return: [uint, uint, ...]
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def get_channel_from_name(self, name: str) -> int:
        """
        Returns the first index of the channel with name <name>.
        :param name: The name to look for.
        :return: uint
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def sfreq_diagnostic(self) -> float:
        """ TODO Should maybe also output the specific number of samples. Can be ambiguous for longer recordings.
        A simple tool that computes the number of samples that should have been recorded from the last
        start_recording/clear to stop_recording/now.
        :WARNING: The function might throw a value error if the amount of recorder samples is zero.
        :return: A float that acts as a quality control. If ==1 perfect, <1 Less samples in recorder then expected
                 >1 More samples then expected.
        """
        raise NotImplementedError("This method was not yet implemented")

    @abstractmethod
    def subject_info_ui(self) -> dict:
        """
        Starts a UI for subject info which is then returned as a dict.
        :return:
        """
        raise NotImplementedError("This method was not yet implemented")

    @staticmethod
    @abstractmethod
    def get_next_filename(path, prefix):
        """
        Determines the next free file namespace to save to.
        Will match all filenames in path to "<prefix>_<date>_<number>".
        If any files contains the pattern it is considered set even if the file ending is different
        So filenames are considered as:
            <before_pattern><prefix>_<date>_<number><after_pattern>
        :param path: The Path to the file
        :param prefix: The prefix of the pattern
        :return:
        """