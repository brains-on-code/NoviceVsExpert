from EEGTools.Recorders.LiveAmpRecorder.Backends import LiveBackend
from EEGTools.Recorders.recorder_base import Recorder_Base
import numpy, threading, logging, time, mne


class LiveAmpRecorder(Recorder_Base):
    """
    The Unicorn Recorder
    Author: Tobias Jungbluth
    Email: toju01@dfki.de
    This class is supposed to help with recording with the gtec Unicorn device.
    The manual mentioned throughout the documentation is the "User Manual for Unicorn Brain Interface Hybrid Black".
    Manual Version Number: 1.18.00
    """

    def __init__(self, path=None, backend=None, montage_file=None):
        super().__init__(path, backend)

        if self.backend is None:
            self.backend = LiveBackend.get_backend()

        self.data_lock = threading.Lock()
        self.backlog = None

        self.is_recording = False
        self.is_connected = False

        self.montage_file = montage_file
        if self.montage_file is not None:
            self.montage = mne.channels.read_custom_montage(montage_file)

        self.recording_thread = threading.Thread(target=self._recording_loop, name="Recording Thread")

    def refresh(self) -> None: # TODO this is slow
        self.refresh_index = self._data.shape[1]
        if len(self.backlog) == 0:
            stack = numpy.empty((self.channelCount, 0))
            self.backlog = []
        else:
            backlog_copy = self.backlog
            self.backlog = []
            stack = numpy.hstack(backlog_copy)
        self._data = numpy.hstack((self._data, stack))

        if self.plot is not None:
            self.plot.update(self.get_new_data())

    def start_recording(self):
        self.is_recording = True

        self.last_start = time.time()
        self.last_start_sample = self._data.shape[1]

    def stop_recording(self):
        self.is_recording = False

        self.last_stop = time.time()

    def _recording_loop(self):
        current_thread = threading.currentThread()

        while getattr(current_thread, "is_running", True):
            (msgtype, data) = self.backend.get_msg()

            if msgtype == 1:
                (channelCount, samplingInterval, channelNames) = self.backend.get_properties(data)

                self.sfreq = samplingInterval/4

                self.channelCount = channelCount
                self._data = numpy.empty((self.channelCount,0))
                self.channelTypes = ["eeg"] * (self.channelCount-3) + ["misc"] * 3
                self.channelNames = channelNames

                self._data = numpy.empty((channelCount, 0))
                self.backlog = []

                self.is_connected = True
            elif msgtype == 4:
                data = self.backend.get_data(data)

                if self.is_recording:
                    self.backlog.append(data)
            else:
                pass

    def connect(self):
        self.backend.connect()
        self.recording_thread.start()
        tic = time.time()
        while not self.is_connected:
            if time.time() - 30 > tic:
                logging.warning("Couldn't connect for 10s. Is something broken?")

    def disconnect(self):
        self.recording_thread.is_running = False
        self.recording_thread.join()
        self.backend.disconnect()
        self.is_connected = False
