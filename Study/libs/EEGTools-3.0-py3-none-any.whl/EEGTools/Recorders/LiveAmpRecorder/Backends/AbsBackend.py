from abc import abstractmethod
from numpy import ndarray


class AbsBackend:

    @abstractmethod
    def get_msg(self):
        pass

    @abstractmethod
    def get_properties(self, msg_data):
        pass

    @abstractmethod
    def get_data(self, msg_data) -> ndarray:
        pass

    @abstractmethod
    def connect(self):
        pass

    @abstractmethod
    def disconnect(self):
        pass
