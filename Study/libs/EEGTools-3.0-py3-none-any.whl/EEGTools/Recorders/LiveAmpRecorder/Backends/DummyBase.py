import time
from EEGTools.Recorders.LiveAmpRecorder.Backends.AbsBackend import AbsBackend
from abc import abstractmethod


class Marker:
    def __init__(self):
        self.position = 0
        self.points = 0
        self.channel = -1
        self.type = ""
        self.description = ""


class DummyBase(AbsBackend):

    MSG_SIZE = 10
    SFREQ = 500

    def __init__(self, channelCount):
        self.channel_count = channelCount
        self.msg_index = 0
        self.timestamp = 0
        self.sample_outputted = 0

    def get_data(self, msg_data):
        time.sleep(1/(self.SFREQ*2))
        delta = (time.time() - self.timestamp)
        samples_to_output = int(delta * self.SFREQ) - self.sample_outputted
        self.sample_outputted += samples_to_output
        data = self.produce_data(samples_to_output)
        return data

    def get_msg(self):
        msg_type = 1 if self.msg_index == 0 else 4

        self.msg_index += 1
        return msg_type, None

    def get_properties(self, msg_data):
        return self.channel_count, self.SFREQ*4, [str(x) for x in range(self.channel_count)]

    def connect(self):
        self.timestamp = time.time()
        self.sample_outputted = 0

    def disconnect(self):
        pass

    @abstractmethod
    def produce_data(self, samples_to_output):
        pass

