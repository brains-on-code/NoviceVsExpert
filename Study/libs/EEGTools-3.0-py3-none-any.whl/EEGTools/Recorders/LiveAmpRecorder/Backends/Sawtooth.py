import numpy
from EEGTools.Recorders.LiveAmpRecorder.Backends.DummyBase import DummyBase


def get_backend(channelCount=67):
    return Dummy(channelCount)


class Dummy(DummyBase):

    MSG_SIZE = 10
    SFREQ = 500

    def __init__(self, channelCount):
        super().__init__(channelCount)

    def produce_data(self, samples_to_output):
        if samples_to_output > 0:
            data = numpy.array([[i * ((self.sample_outputted+i*10) % (self.SFREQ/8)) for i in range(self.channel_count)]]*samples_to_output).transpose()
        else:
            data = numpy.empty((self.channel_count,0))
        return data