from socket import socket
from struct import unpack
from socket import AF_INET, SOCK_STREAM
import numpy
from EEGTools.Recorders.LiveAmpRecorder.Backends.AbsBackend import AbsBackend


def get_backend():
    return Backend()


class Marker:
    def __init__(self):
        self.position = 0
        self.points = 0
        self.channel = -1
        self.type = ""
        self.description = ""


class Backend(AbsBackend):
    """
    Most of this backend is directly taken from the example software provided by the EEG
    and is thus not well documented.
    """

    def __init__(self):
        self.connection = None
        self.lastBlock = -1
        self.channelCount = None

    def connect(self):
        self.connection = socket(AF_INET, SOCK_STREAM)  # TODO doc
        # Connect to recorder host via 32Bit RDA-port
        # adapt to your host, if recorder is not running on local machine
        # change port to 51234 to connect to 16Bit RDA-port
        self.connection.connect(("localhost", 51244)) # TODO this seems to be causing problems in some applications where sockets are used!

    def disconnect(self):
        self.connection.close()

    def get_msg(self):
        rawhdr = self.RecvData(self.connection, 24)

        # Split array into usefull information id1 to id4 are constants
        (id1, id2, id3, id4, msgsize, msgtype) = unpack('<llllLL', rawhdr)

        # Get data part of message, which is of variable size
        rawdata = self.RecvData(self.connection, msgsize - 24)
        return msgtype, (msgsize, rawdata)

    def get_data(self, msg_data):
        # Data message, extract data and markers
        (block, points, markerCount, data, markers) = self.GetData(msg_data[1], self.channelCount)

        # Check for overflow
        if self.lastBlock != -1 and block > self.lastBlock + 1:
            print("*** Overflow with " + str(block - self.lastBlock) + " datablocks ***")
        if block <= self.lastBlock:
            print("*** Got block from the past somehow!? ***")
        self.lastBlock = block

        # Print markers, if there are some in actual block
        if markerCount > 0:
            for m in range(markerCount):
                print("Marker " + markers[m].description + " of type " + markers[m].type)

        return numpy.array(data)

    def get_properties(self, msg_data):
        self.lastBlock = -1
        properties = self.GetProperties(msg_data[1])
        self.channelCount = properties[0]
        return properties

    def get_header(self):
        rawhdr = self.RecvData(self.connection, 24)

        # Split array into useful information id1 to id4 are constants
        (id1, id2, id3, id4, msgsize, msgtype) = unpack('<llllLL', rawhdr)
        return id1, id2, id3, id4, msgsize, msgtype

    # Helper function for receiving whole message
    @staticmethod
    def RecvData(socket, requestedSize):
        returnStream = bytes()
        while len(returnStream) < requestedSize:
            databytes = socket.recv(requestedSize - len(returnStream))
            if databytes == '':
                raise RuntimeError("connection broken")
            returnStream += databytes
        return returnStream

    # Helper function for splitting a raw array of
    # zero terminated strings (C) into an array of python strings
    @staticmethod
    def __SplitString(raw):
        stringlist = []
        s = ""
        for i in range(len(raw)):
            if raw[i] != 0x00:
                s = s + chr(raw[i])
            else:
                stringlist.append(s)
                s = ""

        return stringlist

    # Helper function for extracting eeg properties from a raw data array
    # read from tcpip socket
    @staticmethod
    def GetProperties(rawdata):
        # Extract numerical data
        (channelCount, samplingInterval) = unpack('<Ld', rawdata[:12])
        # Extract resolutions
        resolutions = []
        for c in range(channelCount):
            index = 12 + c * 8
            restuple = unpack('<d', rawdata[index:index + 8])
            resolutions.append(restuple[0])

        # Extract channel names
        channelNames = Backend.__SplitString(rawdata[12 + 8 * channelCount:])

        return channelCount, samplingInterval, channelNames

    # Helper function for extracting eeg and marker data from a raw data array
    # read from tcpip socket
    @staticmethod
    def GetData(rawdata, channelCount):  # TODO incoming triggers.
        # Extract numerical data
        (block, points, markerCount) = unpack('<LLL', rawdata[:12])

        # Extract eeg data as array of floats
        data_vector = []
        data_matrix = numpy.empty((channelCount, 0))
        for i in range(points):
            for j in range(channelCount):
                index = 12 + 4 * (j + channelCount * i)
                value = unpack('<f', rawdata[index:index + 4])
                data_vector.append(value[0])
            data_matrix = numpy.append(data_matrix, numpy.array([data_vector]).transpose(), axis=1)

            data_vector = []

        # Extract markers
        markers = []
        index = 12 + 4 * points * channelCount
        for m in range(markerCount):
            markersize = unpack('<L', rawdata[index:index + 4])

            ma = Marker()
            (ma.position, ma.points, ma.channel) = unpack('<LLl', rawdata[index + 4:index + 16])
            typedesc = Backend.__SplitString(rawdata[index + 16:index + markersize[0]])
            ma.type = typedesc[0]
            ma.description = typedesc[1]

            markers.append(ma)
            index = index + markersize[0]

        return block, points, markerCount, data_matrix, markers
