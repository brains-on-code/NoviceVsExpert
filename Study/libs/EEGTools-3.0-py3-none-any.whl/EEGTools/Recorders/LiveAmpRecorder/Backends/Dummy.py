import numpy
from EEGTools.Recorders.LiveAmpRecorder.Backends.AbsBackend import AbsBackend



def get_backend():
    return Dummy()


class Marker:
    def __init__(self):
        self.position = 0
        self.points = 0
        self.channel = -1
        self.type = ""
        self.description = ""


class Dummy(AbsBackend):

    MSG_SIZE = 10
    SFREQ = 500
    CHANNEL_COUNT = 35

    def __init__(self):
        self.msg_index = 0

    def get_data(self, msg_data): #TODO this is bugged and doesn't work
        data = numpy.array([range(self.CHANNEL_COUNT)]).transpose()
        return data

    def get_msg(self):
        msg_type = 1 if self.msg_index == 0 else 4

        self.msg_index += 1
        return msg_type, None

    def get_properties(self, msg_data):
        return self.CHANNEL_COUNT, self.SFREQ*4, [str(x) for x in range(self.CHANNEL_COUNT)]

    def connect(self):
        pass

    def disconnect(self):
        pass

