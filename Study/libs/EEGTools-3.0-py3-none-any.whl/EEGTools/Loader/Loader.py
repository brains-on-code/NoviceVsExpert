import os
import json


class Loader:
    """
        The Loader is the starting line for any EEG recording analysis.
        It simply loads your data for you in a convenient way.
    """

    @staticmethod
    def parse_subdirectories(path):
        """
        Return a list of tuples with fif json filename pair of all recordings and additional files that belong together.
        :param path:
        :return:
        """
        files = []
        for (dirpath, dirnames, filenames) in os.walk(path):
            files += [dirpath + filename for filename in filenames]
        return Loader.parse_files(files)

    @staticmethod
    def parse_files(files):
        """
        Returns a list of tuples (file, additional_file/None)
        :param files:
        :return:
        """
        mains = []
        additionals = []

        misc = []
        pairs = []

        for arg in files:
            valid, data = Loader.analyze_name(arg)
            if valid:
                if data["additional"]:
                    additionals.append(data)
                else:
                    mains.append(data)
            else:
                misc.append((arg,None))

        for main in mains:
            paired = False
            for additional in additionals:
                if main["prefix"] == additional["prefix"] and main["date"] == additional["date"] and main["number"] == additional["number"]:
                    pairs.append((main["original"], additional["original"]))
                    paired = True
            if not paired:
                misc.append((main["original"], None))

        return pairs, misc

    @staticmethod
    def analyze_name(filename):
        """
        Returns a dictionary with information about the filename.
        :param filename:
        :return:
        """
        filename_dot_split = filename.split(".")
        if len(filename_dot_split) != 2:
            return False, None
        name = filename_dot_split[0]
        name_underscore_split = name.split("_")
        ending = filename_dot_split[1]

        if len(name_underscore_split) < 3:
            return False, None

        additional_file = name_underscore_split[-1] == "additional"
        additional_inc = 1 if additional_file else 0

        if not name_underscore_split[-1-additional_inc].isdigit():
            return False, None

        number = int(name_underscore_split[-1-additional_inc])

        date = name_underscore_split[-2-additional_inc]

        prefix = "_".join(name_underscore_split[:-2-additional_inc])

        return True, {"ending": ending, "additional": additional_file, "number": number, "date": date,
                      "original": filename, "prefix": prefix}

    @staticmethod
    def load_additional(file_additional):
        """
            Parses the additional file of a fif recording.
        """
        with open(file_additional) as file_json:
            additional_data = json.loads("".join(file_json.readlines()))
            if "Event_Dictionary" in additional_data.keys():
                additional_data["Event_Dictionary"] = dict((k, int(v)) for k, v in
                                                        zip(additional_data["Event_Dictionary"].keys(),
                                                            additional_data["Event_Dictionary"].values()))
            return additional_data
