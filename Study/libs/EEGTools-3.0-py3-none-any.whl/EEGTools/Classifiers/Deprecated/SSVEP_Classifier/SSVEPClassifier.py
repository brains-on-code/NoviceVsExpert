from abc import abstractmethod
import numpy, math


class SSVEPClassifier:
    """The class other classifiers should all inherit from"""

    def __init__(self, sfreq, frequencies_to_detect=None, harmonics_depth=2, data_size=500, baselines=None):
        """
        :param sfreq: The sampling frequency
        :param frequencies_to_detect:  The frequencies the classifier should detect for.
        :param harmonics_depth: How many harmonics the classifier should use in its detection
        :param data_size: The number of samples to expect in classify
        """
        self.sfreq = sfreq

        if frequencies_to_detect is None:
            self.frequencies_to_detect = []
        else:
            self.frequencies_to_detect = frequencies_to_detect

        self.harmonics_depth = harmonics_depth
        self.data_size = data_size
        self.baselines = baselines

    @abstractmethod
    def set_frequencies_to_detect(self, frequencies):
        """
        Sets the frequencies to detect for
        :param frequencies:
        :return: None
        """
        pass

    @abstractmethod
    def classify(self, data: numpy.ndarray, optional_freqs: list=None) -> dict:
        """
        Returns confidence level for each frequency as to whether it is SSVEP in a list.
        :param data: a numpy matrix of shape (x, self.data_size)
        :param optional_freqs: Additional frequencies to classify for.
        :return: {f1: c1, f2: c2, ...} where fi is a frequency and ci is the corresponding confidence
        """
        pass

    def classify_all(self, data_set):
        output = []
        for data in data_set:
            classification = self.classify(data)
            output.append(classification)
        return output

    def set_baselines(self, baselines):
        """
        Sets the baselines for the classifier.
        Baselines are a measurements where the classifier can assume that a certain frequency is present in the
        recording.
        :param baselines:
        :return:
        """
        self.baselines = baselines

    def _freq_to_time(self, freq):
        """
        Creates a sin and cosine signals in frequency freq of length data_size
        :param freq:
        :return: [sin, cos]
        """

        res = numpy.array([numpy.sin(numpy.array(list(range(self.data_size))) / self.sfreq * 2 * math.pi * freq),
               numpy.cos(numpy.array(list(range(self.data_size))) / self.sfreq * 2 * math.pi * freq)])
        return res

    def _get_freq_templates(self):
        """
        Creates time signals of frequencies and their harmonics.
        :return: []
        """
        signals = {}
        for frequency in self.frequencies_to_detect:
            for harmonic in range(self.harmonics_depth):
                signals[frequency*harmonic] = self._freq_to_time(frequency*harmonic)
        return signals
