from Unicorn_Recorder.EEGTools import SSVEPClassifier
from Unicorn_Recorder.EEGTools import Utils
import numpy


class PSD_Classfier(SSVEPClassifier):
    """
    An SSVEP Classfier based on PSD
    """

    def __init__(self, sfreq: int, frequencies_to_detect: list=None, harmonics_depth: int=2, data_size: int=250, number_of_electrodes=8, oz_index=7):
        SSVEPClassifier.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)
        self.detection_range = 1
        self.number_of_electrodes = number_of_electrodes
        self.oz_index = oz_index

    def set_frequencies_to_detect(self, frequencies: list):
        self.frequencies_to_detect = frequencies

    def classify(self, data: numpy.ndarray, optional_freqs: list=None) -> dict:
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        if optional_freqs is None:
            optional_freqs = []

        from scipy import signal
        psd = signal.periodogram(data[self.oz_index, :], self.sfreq)

        confidence = {}
        for freq in optional_freqs + self.frequencies_to_detect:
            freq_peak = -1
            for i in range(1, self.harmonics_depth+1):
                min_index, max_index = Utils.get_range_indeces(psd[0], freq*i-1, freq*i+1)
                harmonic_peak = max(psd[1][min_index:max_index])
                freq_peak = max(harmonic_peak, freq_peak)
            confidence[freq] = freq_peak

        return confidence
