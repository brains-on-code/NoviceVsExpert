from Unicorn_Recorder.EEGTools import SSVEPClassifier
from Unicorn_Recorder.EEGTools import Utils
import numpy


class PSD_SNR_Classfier(SSVEPClassifier):
    """
    An SSVEP Classfier based on PSD from the Paper:
    BibTex
    @article{article,
        author = {Kuś, Rafał and Duszyk, Anna and Milanowski, Piotr and Labęcki, Maciej and Bierzyńska, Maria and Radzikowska, Zofia and Michalska, Magdalena and Żygierewicz, Jaroslaw and Suffczynski, Piotr and Durka, Piotr},
        year = {2013},
        month = {10},
        pages = {e77536},
        title = {On the quantification of SSVEP frequency responses in human EEG in realistic BCI conditions},
        volume = {8},
        journal = {PloS one},
        doi = {10.1371/journal.pone.0077536}
    }
    """

    def __init__(self, sfreq: int, frequencies_to_detect: list=None, harmonics_depth: int=2, data_size: int=250, number_of_electrodes=8, oz_index=7):
        SSVEPClassifier.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)
        self.detection_range = 1
        self.number_of_electrodes = number_of_electrodes
        self.oz_index = oz_index

    def set_frequencies_to_detect(self, frequencies: list):
        self.frequencies_to_detect = frequencies

    def classify(self, data: numpy.ndarray, optional_freqs: list=None) -> dict:
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        if optional_freqs is None:
            optional_freqs = []

        from scipy import signal
        psd = signal.periodogram(data[self.oz_index, :], self.sfreq)

        confidence = {}
        for freq in optional_freqs + self.frequencies_to_detect:
            freq_peak = -1
            for i in range(1, self.harmonics_depth+1):
                snr = self.snr(psd, freq*i, 6, 1)
                freq_peak = max(snr, freq_peak)
            confidence[freq] = freq_peak

        return confidence

    def snr(self, psd, frequency, n, delta):
        """
        The described SNR method.
        n needs to be even.
        Delta needs to be a natural number.
        :param psd:
        :param frequency:
        :param n:
        :param delta:
        :return:
        """
        min_index, max_index = Utils.get_range_indeces(psd[0], frequency - 1, frequency + 1)
        signal = max(psd[1][min_index:max_index])
        index_frequency = Utils.get_index_of_value(psd[0], frequency)
        noise = sum([psd[1][index_frequency+i*delta]+psd[1][index_frequency-i*delta] for i in range(1, int(n/2)+1)])
        snr = signal / noise
        return snr
