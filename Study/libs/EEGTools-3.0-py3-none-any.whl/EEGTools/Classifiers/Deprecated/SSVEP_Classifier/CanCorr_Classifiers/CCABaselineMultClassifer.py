import numpy
import math
from Unicorn_Recorder.EEGTools import CCATemplate


class CCABaselineClassifier(CCATemplate):
    """
    An SSVEP Classfier based on CCA
    """

    def __init__(self, sfreq, frequencies_to_detect=None, harmonics_depth=2, data_size=500):
        CCATemplate.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)

        self.freq_time_signals = {}
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = numpy.array(self.__freq_to_time(freq))

    def __freq_to_time(self, freq):
        """
        Creates a sin and cosine signals in frequency freq of length data_size and with harmonics_depth-1
        amount of harmonics.
        :param freq:
        :return:
        """
        res = []
        for i in range(1, self.harmonics_depth + 1):
            res.append(numpy.sin(numpy.array(list(range(self.data_size))) / self.sfreq * i * 2 * math.pi * freq))
            res.append(numpy.cos(numpy.array(list(range(self.data_size))) / self.sfreq * i * 2 * math.pi * freq))
        return res

    def set_baselines(self, baselines: dict):
        avg_baseline = {}
        for key in baselines.keys():
            avg_baseline[key] = (numpy.average(numpy.array(baselines[key]), axis=0))
        self.baselines = avg_baseline

    def classify(self, data: numpy.ndarray, optional_freqs: list=None):
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        Longer data sets produce less correlation and vice versa. #TODO Proof
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        if optional_freqs is None:
            optional_freqs = []

        confidence = {}
        for index in range(len(self.frequencies_to_detect)):
            signal_data = self.freq_time_signals[self.frequencies_to_detect[index]] \
                                                 if self.baselines is None else \
                                                    self.baselines[self.frequencies_to_detect[index]][:, :self.data_size]
            X, Y = self._can_corr(data, signal_data=signal_data)
            corr_matrix = self._corr_matrix(X.transpose(), Y.transpose())
            confidence[self.frequencies_to_detect[index]] = corr_matrix[0, 1]

        for index in optional_freqs:
            signal_data = self.freq_time_signals[self.frequencies_to_detect[index]] \
                                                 if self.baselines is None else \
                                                    self.baselines[self.frequencies_to_detect[index]][:, :self.data_size]
            X, Y = self._can_corr(data, signal_data=signal_data)
            corr_matrix = self._corr_matrix(X.transpose(), Y.transpose())
            confidence[self.frequencies_to_detect[index]] = corr_matrix[0, 1]

        return confidence

    def set_frequencies_to_detect(self, frequencies):
        """
        Sets the frequencies to detect for
        :param frequencies:
        :return: None
        """
        self.frequencies_to_detect = frequencies
        self.freq_time_signals = {}
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = numpy.array(self.__freq_to_time(freq))
