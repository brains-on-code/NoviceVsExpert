from Unicorn_Recorder.EEGTools import SSVEPClassifier
import numpy
from sklearn.cross_decomposition import CCA
from abc import abstractmethod


class CCATemplate(SSVEPClassifier):

    def __init__(self, sfreq, frequencies_to_detect=None, harmonics_depth=2, data_size=500, baselines=None, oz_index=7):
        SSVEPClassifier.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size, baselines)
        self.oz_index = oz_index

    @abstractmethod
    def set_frequencies_to_detect(self, frequencies):
        """
        Sets the frequencies to detect for
        :param frequencies:
        :return: None
        """
        pass

    @abstractmethod
    def classify(self, data: numpy.ndarray, optional_freqs: list=None) -> dict:
        """
        Returns confidence level for each frequency as to whether it is SSVEP in a list.
        :param data: a numpy matrix of shape (x, self.data_size)
        :param optional_freqs: Additional frequencies to classify for.
        :return: {f1: c1, f2: c2, ...} where fi is a frequency and ci is the corresponding confidence
        """
        pass

    def _can_corr(self, data: numpy.ndarray, signal_data):
        """
        Computes the CCA vectors X and Y of data and signal data.
        data is the eeg data as an ndarray with shape (channels, samples).
        Exp Signal data are the time domain signals of the frequencies.
        :param data:
        :param signal_data:
        :return:
        """
        X = numpy.array([data[self.oz_index, :]])
        Y = signal_data

        Y = numpy.array(Y)
        analyzer = CCA(n_components=1)
        X, Y = X.transpose(), Y.transpose()
        analyzer.fit(X, Y)
        X_res, Y_res = analyzer.transform(X, Y)
        return X_res, Y_res

    @staticmethod
    def _corr_matrix(X, Y):
        """Computes the correlation matrix between X and Y"""
        data = numpy.append(X, Y, axis=0)
        matrix = numpy.corrcoef(data)
        return matrix
