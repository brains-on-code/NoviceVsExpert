from sklearn.cross_decomposition import CCA
import numpy
import math
from Unicorn_Recorder.EEGTools import CCATemplate


class WeightedHarmonics(CCATemplate):
    """
    An SSVEP Classfier based on CCA correlating with harmonics explicitly
    """

    def __init__(self, sfreq, frequencies_to_detect=None, harmonics_depth=2, data_size=500):
        CCATemplate.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)

        self.freq_time_signals = {}
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = self.__freq_to_time(freq)

    def __freq_to_time(self, freq):
        """
        Creates a sin and cosine signals in frequency freq of length data_size and with harmonics_depth-1
        amount of harmonics.
        :param freq:
        :return:
        """
        res = []
        for i in range(1, self.harmonics_depth + 1):
            res.append([numpy.sin(numpy.array(list(range(self.data_size))) / self.sfreq * i * 2 * math.pi * freq),
                        numpy.cos(numpy.array(list(range(self.data_size))) / self.sfreq * i * 2 * math.pi * freq)])
        return numpy.array(res)

    def classify(self, data, optional_freqs=None):
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        Longer data sets produce less correlation and vice versa. #TODO Proof
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """  # TODO support optional freqs
        confidence = {}
        for index in range(len(self.frequencies_to_detect)):
            corr = 0
            for harmonic_index in range(self.harmonics_depth):
                signal_data = self.freq_time_signals[self.frequencies_to_detect[index]][harmonic_index]
                X, Y = self._can_corr(data, signal_data=signal_data)
                corr_matrix = self._corr_matrix(X.transpose(), Y.transpose())
                corr += corr_matrix[0, 1]**2 / (harmonic_index+1)
            confidence[self.frequencies_to_detect[index]] = corr

        return confidence
