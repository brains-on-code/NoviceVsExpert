from sklearn.cross_decomposition import CCA
import numpy
import math
from Unicorn_Recorder.EEGTools import SSVEPClassifier
import mne
from scipy.signal import butter, lfilter


class ExpectedDavidPainter(SSVEPClassifier):
    """
        An SSVEP Classfier based on Filter Bank CanCorr described in
        "Filter bank canonical correlation analysis for
        implementing a high-speed SSVEP-based
        brain–computer interface"
    """

    def __init__(self, sfreq: int, frequencies_to_detect: list=None, harmonics_depth: int=2, data_size: int=500, number_of_electrodes=8, oz_index=7, width =2):
        """
        :param sfreq: The sampling frequency
        :param frequencies_to_detect: The frequencies the classifier should detect for
        :param harmonics_depth: How many harmonics the classifier should consider.
                                1 -> just the fundamental, 2 -> with the frist harmonic ...
        :param data_size: The data size the classifier can expect to classify give in amount of samples.
        """
        SSVEPClassifier.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)

        self.freq_time_signals = {}
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = numpy.array(self.__freq_to_time(freq))
            print(self.freq_time_signals[freq].shape)

        self.number_of_electrodes = number_of_electrodes
        self.oz_index = oz_index

        # Get the frequencies to create subands
        self.no_subbands = 5
        self.subband_frequencies = []
        self.bandpasses = []
        self.width = width
        if len(self.frequencies_to_detect) > 0:
            self.set_frequencies_to_detect(self.frequencies_to_detect)

    def __freq_to_time(self, freq):
        """
        Creates sine and cosine signals in frequency freq of length data_size and with harmonics_depth-1
        amount of harmonics.
        :param freq:
        :return:
        """
        res = []
        for i in range(1, self.harmonics_depth + 1):
            res.append(numpy.sin(numpy.array(list(range(self.data_size))) / self.sfreq * i * 2 * math.pi * freq))
            res.append(numpy.cos(numpy.array(list(range(self.data_size))) / self.sfreq * i * 2 * math.pi * freq))
        return res

    def set_frequencies_to_detect(self, frequencies):
        self.frequencies_to_detect = frequencies
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = numpy.array(self.__freq_to_time(freq))
        for frequency in self.frequencies_to_detect:
            self.bandpasses = self.bandpasses + self.get_bandpass_for_frequency(frequency)

    def get_bandpass_for_frequency(self, frequency):
        output = []
        for harmonic in range(1,self.harmonics_depth+1):
            output.append(self.butter_bandpass(frequency*harmonic - self.width, frequency*harmonic + self.width, fs=self.sfreq))
        return output

    def classify(self, data, optional_freqs=None):
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        Longer data sets produce less correlation and vice versa. #TODO Proof
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        if optional_freqs is None:
            optional_freqs = []

        data = data[:, :]

        # Create subbands shape (subbands, channels, samples)
        X_SB = numpy.array([self.butter_bandpass_filter(data, bandpass[0], bandpass[1]) for bandpass in self.bandpasses])
        confidence = {}
        for i in range(len(self.frequencies_to_detect)):
            confidence[self.frequencies_to_detect[i]] = self.get_rho_tilde_k(X_SB[i:i+self.harmonics_depth], self.freq_time_signals[self.frequencies_to_detect[i]])

        return confidence

    def get_rho_tilde_k(self, X_SB, Y):
        rho = self.get_rho_k(X_SB, Y)
        return sum([rho[i]*self.weight(i+1,1,0) for i in range(len(rho))])

    def weight(self, n,a,b):
        return (1/(n ** a)) + b

    def get_rho_k(self, X_SB, Y):
        rho = []
        for i in range(X_SB.shape[0]):
            rho.append(self.get_rho_k_n(X_SB[i], Y))
        return rho

    def get_rho_k_n(self, X_SB_n: numpy.ndarray, Y: numpy.ndarray):
        X_res, Y_res = self.get_subband_cca(X_SB_n, Y)
        print("Shape", X_res.shape, Y_res.shape)
        X_SB_res = X_SB_n.dot(X_res)
        Y_Y_res = Y.dot(Y_res)
        return self.__corcoef(X_res.transpose(), Y_res.transpose())[0,1]#"Each row is one variable"

    def get_subband_cca(self, X_SB_n: numpy.ndarray, Y: numpy.ndarray):
        return self.__cca(X_SB_n.transpose(), Y.transpose())

    def __cca(self, data, signal_data):
        """
        data is the eeg data. Signal data are the time domain signals of the frequencies.
        Input needs to be (samples, x) (samples, y)
        :param data:
        :param signal_data:
        :return:
        """
        X = data
        Y = signal_data

        analyzer = CCA(n_components=1)
        analyzer.fit(X, Y)
        X_res, Y_res = analyzer.transform(X, Y)
        return X_res, Y_res

    def __corcoef(self, X, Y):
        data = numpy.append(X, Y, axis=0)
        matrix = numpy.corrcoef(data)
        return matrix

    def butter_bandpass(self, lowcut, highcut, fs, order=5):
        nyq = 0.5 * fs
        low = lowcut / nyq
        high = highcut / nyq
        print(lowcut, highcut)
        b, a = butter(order, [low, high], btype='band')
        return b, a

    def butter_bandpass_filter(self, data, b, a):
        y = lfilter(b, a, data)
        return y
