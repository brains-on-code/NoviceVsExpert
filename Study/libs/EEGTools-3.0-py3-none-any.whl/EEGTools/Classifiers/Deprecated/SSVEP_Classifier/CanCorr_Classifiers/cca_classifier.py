from sklearn.cross_decomposition import CCA
import numpy
import math
from Unicorn_Recorder.EEGTools import SSVEPClassifier


class CCA_Classfier(SSVEPClassifier):
    """
    An SSVEP Classfier based on CCA
    """

    def __init__(self, sfreq: int, frequencies_to_detect: list=None, harmonics_depth: int=2, data_size: int=500, number_of_electrodes=8, oz_index=7):
        """
        :param sfreq: The sampling frequency
        :param frequencies_to_detect: The frequencies the classifier should detect for
        :param harmonics_depth: How many harmonics the classifier should consider.
                                1 -> just the fundamental, 2 -> with the frist harmonic ...
        :param data_size: The data size the classifier can expect to classify give in amount of samples.
        """
        SSVEPClassifier.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)

        self.freq_time_signals = {}
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = numpy.array(self._freq_to_time(freq))

        self.number_of_electrodes = number_of_electrodes
        self.oz_index = oz_index

    def set_frequencies_to_detect(self, frequencies):
        self.frequencies_to_detect = frequencies
        self.freq_time_signals = {}
        for freq in self.frequencies_to_detect:
            self.freq_time_signals[freq] = numpy.array(self._freq_to_time(freq))

    def classify(self, data, optional_freqs=None):
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        Longer data sets produce less correlation and vice versa. #TODO Proof
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        if optional_freqs is None:
            optional_freqs = []

        confidence = {}
        for frequency in self.frequencies_to_detect:
            X, Y = self.__cca(data, signal_data=self.freq_time_signals[frequency])
            corr_matrix = self.__corcoef(X.transpose(), Y.transpose())
            confidence[frequency] = corr_matrix[0, 1]

        for frequency in optional_freqs:
            time_signal = self.__freq_to_time(frequency)
            X, Y = self.__cca(data, signal_data=time_signal)
            corr_matrix = self.__corcoef(X.transpose(), Y.transpose())
            confidence[frequency] = corr_matrix[0, 1]

        return confidence

    def __cca(self, data, signal_data):
        """
        data is the eeg data. Signal data are the time doain signals of the frequencies
        :param data:
        :param signal_data:
        :return:
        """
        X = numpy.array([data[self.oz_index, :]])
        Y = signal_data

        Y = numpy.array(Y)
        analyzer = CCA(n_components=1)
        X, Y = X.transpose(), Y.transpose()
        analyzer.fit(X, Y)
        X_res, Y_res = analyzer.transform(X, Y)
        return X_res, Y_res

    def __corcoef(self, X, Y):
        data = numpy.append(X, Y, axis=0)
        matrix = numpy.corrcoef(data)
        return matrix
