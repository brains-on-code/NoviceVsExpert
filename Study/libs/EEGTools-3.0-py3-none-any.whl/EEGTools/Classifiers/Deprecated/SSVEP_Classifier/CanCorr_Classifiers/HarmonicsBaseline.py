from Unicorn_Recorder.EEGTools import ExplicitHarmonics
from Unicorn_Recorder.EEGTools import CCABaselineClassifier
from Unicorn_Recorder.EEGTools import SSVEPClassifier


class HarmonicsBaseline(SSVEPClassifier):
    """
    An SSVEP Classfier based on CCA correlating with harmonics explicitly
    """

    def __init__(self, sfreq, frequencies_to_detect=None, harmonics_depth=2, data_size=500):
        SSVEPClassifier.__init__(sfreq, frequencies_to_detect, harmonics_depth, data_size)
        self.baseline_classifier = CCABaselineClassifier(sfreq, frequencies_to_detect, harmonics_depth, data_size)
        self.harmonic_classifier = ExplicitHarmonics(sfreq, frequencies_to_detect, harmonics_depth, data_size)

    def classify(self, data, optional_freqs=None):
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        Longer data sets produce less correlation and vice versa. #TODO Proof
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        confidence = {}
        confidence_a = self.baseline_classifier.classify(data, optional_freqs)
        confidence_b = self.harmonic_classifier.classify(data, optional_freqs)

        for freq in self.frequencies_to_detect:
            confidence[freq] = max(confidence_a[freq], confidence_b[freq])

        return confidence
