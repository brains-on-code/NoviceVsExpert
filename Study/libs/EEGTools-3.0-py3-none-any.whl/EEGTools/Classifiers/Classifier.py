from abc import abstractmethod
import numpy
from typing import List, Dict


class Classifier:

    @abstractmethod
    def classify(self, data: numpy.ndarray) -> Dict[str, float]:
        """
        Classifies the data
        :param data: a numpy array of shape (channel, samples)
        :return: A dictionary of id -> confidence
        """

    def train(self, training_data) -> None:
        """
        Trains the classifier with the given data if applicable
        :param training_data:
        :return:
        """
        pass

    @abstractmethod
    def get_classes(self) -> List[str]:
        """
        Returns the classes the classifier will output
        :return:
        """
