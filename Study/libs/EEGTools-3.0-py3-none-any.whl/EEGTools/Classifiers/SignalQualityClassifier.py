from Unicorn_Recorder.EEGTools import Classifier
from Unicorn_Recorder.EEGTools import Utils
from Unicorn_Recorder.EEGTools import SignalQuality, Unicorn_recorder
import numpy


class SignalQualityClassifier(Classifier):
    """
    An SSVEP Classfier based on CCA
    """

    def __init__(self, sfreq: int, frequencies_to_detect: list=None, harmonics_depth: int=2, data_size: int=250):
        Classifier.__init__(self, sfreq, frequencies_to_detect, harmonics_depth, data_size)
        self.verbose = True

    def set_frequencies_to_detect(self, frequencies: list):
        self.frequencies_to_detect = frequencies

    def classify(self, data: numpy.ndarray, optional_freqs: list=None) -> list:
        """
        Returns confidence level for each frequency as to whether it is SSVEP.
        Note, that all data sets should be of the same length to get an accurate reading.
        :param data:
        :param optional_freqs: Additional frequencies to classify for. Use if detected frequencies are rapidly changing.
        :return:
        """
        if optional_freqs is None:
            optional_freqs = []

        if self.verbose:
            quality_bpmd = Unicorn_recorder.check_bpmd(data, self.sfreq)[1]
            quality_std = Unicorn_recorder.check_std(data)[1]
            if quality_bpmd:
                if quality_std:
                    quality = SignalQuality.GOOD
                else:
                    quality = SignalQuality.STD_FAILED
            else:
                if quality_std:
                    quality = SignalQuality.BPMD_FAILED
                else:
                    quality = SignalQuality.BAD
        else:
            quality = Unicorn_recorder.check_signal_quality(data, self.sfreq)[1]
        print(quality)

        confidence = []
        for _ in self.frequencies_to_detect:
            num = 0
            if quality.value == SignalQuality.BAD.value:
                num = 0
            elif quality.value == SignalQuality.GOOD.value:
                num = 1
            elif quality.value == SignalQuality.BPMD_FAILED.value:
                num = 2/3
            elif quality.value == SignalQuality.STD_FAILED.value:
                num = 1/3
            confidence.append((quality.value, num))
        return confidence
