from EEGTools.Classifiers.PostClassifiers.PostClassifier import PostClassifier


class HighestConfidence(PostClassifier):

    def __init__(self, magic=0):
        PostClassifier.__init__(self, magic)

    def append_predictions(self, confidence_levels):
        """
        Takes the confidence dictionary as input and outputs the classified key, or the -1 if no classification was made.
        :param confidence_levels:
        :return:
        """
        largest_key = max(confidence_levels, key=lambda k: confidence_levels[k])
        for key in [key for key in confidence_levels.keys() if not key == largest_key]:
            if confidence_levels[largest_key] - confidence_levels[key] < self.magic:
                return -1
        return largest_key

    def reset(self):
        pass
