import numpy as np
from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.PostClassifier import PostClassifier
from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.HighestConfidence import HighestConfidence

class MajorityVote(PostClassifier):

    def __init__(self, n_predictions, class_ids, magic=0):
        PostClassifier.__init__(self, magic)
        # class_ids = [0, 1, 2, 3]
        self.n_predictions = n_predictions
        self.class_ids = class_ids
        self.predictions = []
        self.highest_con = HighestConfidence(self.magic)

    def append_predictions(self, confidence_levels):
        """
        :param confidence_levels:
        :return:
        """
        key = self.highest_con.append_predictions(confidence_levels)
        self.predictions.append(key)
        self.predictions = self.predictions[-self.n_predictions:]

        bins = np.arange(np.max(self.class_ids))
        most_frequent = self.bincount_neg(self.predictions)
        index_bin_most_frequent = most_frequent[0]

        print(index_bin_most_frequent)
        """if index_bin_most_frequent < len(bins):
            majority_vote = bins[index_bin_most_frequent]
        else:
            print('PostClassifierMajorityVote got unknown candidate from majority vote (case 1). '+
                  'Returning idle state.')
            majority_vote = -1                                   #Deprecated: np.random.choice(self.class_ids)

        if majority_vote not in self.class_ids:
            print('PostClassifierMajorityVote got unknown candidate from majority vote (case 2). '+
                  'Returning idle state.')
            majority_vote = -1    """                                           #np.random.choice(self.class_ids)

        return index_bin_most_frequent

    def reset(self):
        self.predictions = []


    def bincount_neg(self, data):
        counter = dict()
        currenthighest = 0
        highest_key = None
        for item in data:
            if item in counter.keys():
                value = counter[item]
                value += 1
                counter[item] = value
                if value > currenthighest:
                    currenthighest = value
                    highest_key = item
            else:
                counter[item] = 1
                if currenthighest == 0:
                    currenthighest = 1
                    highest_key = item


        return (highest_key, currenthighest)



