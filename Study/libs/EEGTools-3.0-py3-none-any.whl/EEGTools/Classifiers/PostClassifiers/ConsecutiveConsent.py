import numpy as np
from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.HighestConfidence import HighestConfidence
from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.PostClassifier import PostClassifier


class ConsecutiveConsent(PostClassifier):

    def __init__(self, n_predictions, class_id_default, magic=0):
        PostClassifier.__init__(self, magic)
        self.n_predictions = n_predictions
        self.predictions = []
        self.class_id_default = class_id_default
        self.highest_con = HighestConfidence(self.magic)

    def append_predictions(self, confidence_levels):
        key = self.highest_con.append_predictions(confidence_levels)
        self.predictions.append(key)
        self.predictions = self.predictions[-self.n_predictions:]

        # Assemble array of all different kinds of predictions that are currently present
        # [1,1,1,] --> [1]
        # [1,2,1,] --> [1, 2]
        # [1,1,2,1,1,] --> [1, 2]
        class_ids_current = np.unique(self.predictions)

        # Update the sequential consent only if all current predictions are the same
        if len(class_ids_current) == 1:
            self.class_id_default = class_ids_current[0]

        return self.class_id_default

    def reset(self):
        self.predictions = []
