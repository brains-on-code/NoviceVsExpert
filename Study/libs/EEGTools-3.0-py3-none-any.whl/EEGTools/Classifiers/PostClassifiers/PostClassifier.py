from abc import abstractmethod
from typing import Dict


class PostClassifier:
    """
    Template Class for post Classifiers, that should all inherit from this.
    Post classifiers are to be used in conjunction with classifiers returning confidences ffor classes.
    They look at the multiple classifications as a data stream and can correct outliers and such.
    """

    def __init__(self, magic=0):
        self.magic = magic

    @abstractmethod
    def append_predictions(self, confidence_levels: Dict[str, float]):
        """
        Takes the confidence levels from a Classifier and outputs a classification.
        :param confidence_levels: A dictionary{id: confidence, ...}
        :return:
        """
        pass

    def append_multiple_predictions(self, multiple_confidence_levels: list):
        return [self.append_predictions(confidence_levels) for confidence_levels in multiple_confidence_levels]

    @abstractmethod
    def reset(self):
        """
        Resets the classifiers, i.e. deletes previous information collected about other classifications.
        :return:
        """
        pass

    def set_magic(self, magic):
        """
        Sets the threshold for Idle State Classification
        :param magic:
        :return:
        """
        self.magic = magic
