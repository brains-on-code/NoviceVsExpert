from collections import defaultdict
from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.PostClassifier import PostClassifier
from Unicorn_Recorder.EEGTools.Classifiers.PostClassifiers.HighestConfidence import HighestConfidence


class WeightedMajorityVote(PostClassifier):
    """
    The rational is that classifications further in the past are less important than classifications closer to the present
    """

    def __init__(self, n_predictions, fun=lambda i: 1/i, magic=0):
        PostClassifier.__init__(self, magic)
        self.n_predictions = n_predictions
        self.predictions = []
        self.highest_con = HighestConfidence(self.magic)
        self.fun = fun

    def append_predictions(self, confidence_levels):
        """
        :param confidence_levels:
        :return:
        """
        key = self.highest_con.append_predictions(confidence_levels)
        self.predictions.append(key)
        self.predictions = self.predictions[-self.n_predictions:]

        bins = defaultdict(lambda: 0, {})
        for i in range(len(self.predictions)):
            bins[self.predictions[i]] += self.predictions[i] * self.fun(i+1)

        majority_vote = max(bins, key=lambda k: bins[k])

        return majority_vote

    def reset(self):
        self.predictions = []

