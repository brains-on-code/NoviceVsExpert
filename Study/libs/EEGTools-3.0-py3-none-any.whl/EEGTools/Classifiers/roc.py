import math
import numpy

class ROC:
    """
    The central class for statistics concerning binary classifications
    """

    @staticmethod
    def true_positive_rate(TP, FN):
        """
        Comoputes the true positive rate. Also called (Sensitivity, Recall, Hitrate)
        :param TP:
        :param FN:
        :return:
        """
        return TP / (TP + FN)

    @staticmethod
    def false_negative_rate(TP, FN):
        return 1 - ROC.true_positive_rate(TP, FN)

    @staticmethod
    def true_negative_rate(TN, FP):
        """
        Returns the true negative rate. Also called Specificity, Selectivity
        :param TN: Number of true negatives
        :param FP: Number of false positives
        :return:
        """
        return TN / (TN+FP)

    @staticmethod
    def accuracy(TP, FP, FN, TN):
        """
        Computes the Accuracy.
        :param TP:
        :param TN:
        :param FP:
        :param FN:
        :return:
        """
        return (TP + TN) / (TP+TN+FP+FN)

    @staticmethod
    def youdens_statistic(TP, TN, FP, FN):
        """
        Computes Youdens statistic. For any point on a ROC curve this statistic returns the distance between the point and the diagonal.
        """
        return ROC.true_positive_rate(TP, FN) + ROC.true_negative_rate(TN, FP) - 1

    @staticmethod
    def precision(TP, FP):
        return TP/(TP+FP)

    @staticmethod
    def negative_predictive_value(TN, FN):
        return TN/(TN+FN)

    @staticmethod
    def fallout(FP, TN):
        return 1-ROC.true_negative_rate(TN, FP)

    @staticmethod
    def false_discovery_rate (TP, FP):
        return 1 - ROC.precision(TP, FP)

    @staticmethod
    def false_omission_rate(FN, TN):
        return 1 - ROC.negative_predictive_value(TN, FN)

    @staticmethod
    def prevalence_threshhold(FN, FP, TN, TP):

        TPR = ROC.true_positive_rate(TP, FN)
        TNR = ROC.true_negative_rate(TN, FP)
        return (math.sqrt(TPR * (-1*TNR+1))+TNR-1)/(TPR+TNR-1)


    @staticmethod
    def critical_success_index(FN, FP, TP):
        return TP/(TP+FN+FP)

    @staticmethod
    def balanced_accuracy (TP, FP, FN, TN):
        """
        Computes the balance accuracy
        :param TP:
        :param FP:
        :param FN:
        :param TN:
        :return:
        """
        tnr = ROC.true_negative_rate(TN, FP)
        tpr = ROC.true_positive_rate(TP, FN)

        return (tpr + tnr)/2

    @staticmethod
    def f1_score(FN, FP, TP):
        return (2*TP)/(2*TP +FP +FN)

    @staticmethod
    def mathews_correlation_coefficient(FN, FP, TN, TP):

        divident = TP * TN - FP * FN
        divisor = math.sqrt((TP+FP) * (TP + FN) * (TN + FP) * (TN + FN))

        return divident / divisor

    @staticmethod
    def fowlkes_mallows_index(FN, FP, TP):

        first = TP / (TP + FP)
        second = TP / (TP + FN)

        return math.sqrt(first * second)

    @staticmethod
    def informedness (FN, FP, TN,  TP):
        return ROC.true_positive_rate(TP, FN) + ROC.true_negative_rate(TN, FP) -1

    @staticmethod
    def markedness(FN, FP, TN, TP):
        return ROC.precision(TP, FP) + ROC.false_omission_rate(FN, TN) - 1

    @staticmethod
    def compute_confusion_matrix(data: dict):
        """
        For a dict {Class1 : {Class1 : X, Class2: Y ...}, Class2: {Class1: Z, Class2: A}, ...}
        computes a confusion matrix for each class.
        Returns a dict: {Class1 : numpy.ndarray [[TP,FP],[FN,TN]], Class2 : ...}
        :param data:
        :return:
        """
        confusion_matrices = {}
        for key in data.keys():
            confusion_matrix = numpy.zeros((2,2))
            confusion_matrices[key] = confusion_matrix

        for outer_key in data.keys():
            for inner_key in data.keys():
                if outer_key == inner_key:
                    confusion_matrices[outer_key][0, 0] += data[outer_key][inner_key]
                else:
                    confusion_matrices[outer_key][0, 1] += data[outer_key][inner_key]
                    confusion_matrices[inner_key][1, 0] += data[outer_key][inner_key]
                for others in data.keys():
                    if others != outer_key and others != inner_key:
                        confusion_matrices[others][1, 1] += data[outer_key][inner_key]

        return confusion_matrices

    @staticmethod
    def format_data(classifications, labels, possible_labels):
        output = dict()
        for label in possible_labels:
            output[label] = dict()
            for inner_label in possible_labels:
                output[label][inner_label] = 0
        for item in range(len(classifications)):
            container = output[labels[item]]
            container[classifications[item]] += 1
        return output
