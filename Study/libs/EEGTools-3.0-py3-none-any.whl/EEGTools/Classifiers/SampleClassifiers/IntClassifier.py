import numpy
from typing import List, Dict
from EEGTools.Classifiers.Classifier import Classifier


class RandomClassifier(Classifier):

    def __init__(self, classes, to_output):
        self.classes = classes
        self.to_output = to_output

    def classify(self, data: numpy.ndarray) -> Dict[str, float]:
        """
        Classifies the data
        :param data: a numpy array of shape (channel, samples)
        :return: A dictionary of id -> confidence
        """
        classification = {_class: self.to_output for _class in self.classes}
        return classification
        
    def get_classes(self) -> List[str]:
        """
        Returns the classes the classifier will output
        :return:
        """
        return self.classes
