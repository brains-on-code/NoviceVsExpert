from multisensor_pipeline import BaseSink


class OutputSink(BaseSink):

    def __init__(self):
        super().__init__()
        self.__buffer = []

    def _update_loop(self):
        while self._active:
            dtype, payload = self.get()

            if dtype== b"fixation":
                tmp = payload["data"]
                msg_list = tmp.split(":")
                tmp_list = []
                for strin in msg_list:
                    tmp_list.append(float(strin))
                self.__buffer.append(tmp_list)

    def get_buffer(self):
        tmp = self.__buffer
        self.__buffer = []
        return tmp