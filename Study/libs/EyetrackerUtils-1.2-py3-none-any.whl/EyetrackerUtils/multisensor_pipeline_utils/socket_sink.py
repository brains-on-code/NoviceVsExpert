from multisensor_pipeline import BaseSink
import socket
from threading import Thread, Condition


class SocketSink(BaseSink):
    """
        This class is intended to be used with the multisensor pipeline and intended as a sink. It acts as a serverside
        TCP-Socket and sends out String Fixations to a Receiver
    """
    def __init__(self, ip = 'localhost', port : int = 5666):
        """
        Creates an instance of this class and instializes the super class
        :param ip: The IP the socket should work on, defaults to localhost
        :param port: The port the socket should work on, defaults to 5666
        """
        super().__init__()

        # initialize socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind((ip, port))
        self.sock.listen(1)

        # Conditon that tracks if there is new data
        self.condition = Condition()

        # Data is stored here
        self.sendbuffer = []

        # Do we already have a connection?
        accepted = False

        print(f'Waiting (blockingly) for Socket connection on IP: {ip} and Port: {port}')

        # init client variable so Pycharm is not annoying me
        client = None

        # While we don't have a connection, wait for it. NOTE: THIS IS BLOCKING
        while not accepted:
            (client, addr) = self.sock.accept()
            print(f"Connected to Client on IP {addr}")
            accepted = True

        # start server
        server_thread = Thread(target= self.sender, args=[ client], name='Server_Thread')
        server_thread.start()


    def sender(self, client_sock) -> None:
        """
        Thread method to send out data
        :param client_sock: The Socket connection to send it to
        :return: None
        """
        # as long as we have the condition
        with self.condition:
            # we permanently send new data
            while True:

                tmp = self.sendbuffer
                self.sendbuffer = []
                # print(f'Tmp: ', tmp)
                for item in tmp:
                    #print('Sending')
                    client_sock.send(item.encode('utf-8'))
                    #print('sent')
                self.condition.wait()

    def _update_loop(self):


        while self._active:
            dtype, payload = self.get()
            if dtype == b'fixation':
                #print('Got Fixations')
                data = payload['data']
                self.sendbuffer.append(data)
                with self.condition:
                    self.condition.notifyAll()


if __name__ == "__main__":
    from EyetrackerUtils.multisensor_pipeline_utils import mouse_mask_processor
    from multisensor_pipeline.pipeline import GraphPipeline
    from EyetrackerUtils.multisensor_pipeline_utils.Mouse import Mouse

    pipeline = GraphPipeline()
    src = Mouse(scroll=False, click=False)
    prc = mouse_mask_processor.MouseMaskProcessor(1920, 1080)
    sink = SocketSink()

    pipeline.add_source(src)
    pipeline.add_processor(prc)
    pipeline.add_sink(sink)

    pipeline.connect(src, sink)
    pipeline.connect(src, prc)
    pipeline.connect(prc, sink)

    pipeline.start()

