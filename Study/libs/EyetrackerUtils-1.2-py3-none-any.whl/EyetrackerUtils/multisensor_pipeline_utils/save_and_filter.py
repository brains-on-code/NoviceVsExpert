from multisensor_pipeline import GraphPipeline
#from EyetrackerUtils.multisensor_pipeline_utils.Mouse import Mouse
from EyetrackerUtils.multisensor_pipeline_utils.fusion_source import FusionSource
#from EyetrackerUtils.multisensor_pipeline_utils.mouse_mask_processor import MouseMaskProcessor
from multisensor_pipeline.modules.network import ZmqPublisher
from EyetrackerUtils.multisensor_pipeline_utils.ivt_processor import IVTProcessor
from EyetrackerUtils.multisensor_pipeline_utils.csv_sink import CSVSink
import warnings, time


if __name__ == "__main__":
    pipeline = GraphPipeline()

    src = FusionSource()
    pipeline.add_source(src)


    warnings.warn("WARNING; IVT WINDOW LENGTH SET TO DUMMY VALUE; CHANGE TO SOMETHING SENSIBLE")
    prc = IVTProcessor(42)
    pipeline.add_processor(prc)

    sink = CSVSink("C:\\Users\\mash02-admin\\Desktop\\test.csv", verbose=True)
    pipeline.add_sink(sink)

    sink2 = ZmqPublisher(port=5556)
    pipeline.add_sink(sink2)

    pipeline.connect(src, prc)
    pipeline.connect(prc, sink2)
    pipeline.connect(src, sink2)
    pipeline.connect(prc, sink)
    pipeline.connect(src, sink)
    pipeline.start()

    while True:
        time.sleep(1)