from EyetrackerUtils.multisensor_pipeline_utils.ivt_processor import IVTProcessor
from multisensor_pipeline.pipeline import GraphPipeline
from multisensor_pipeline.modules.network import ZmqPublisher
from EyetrackerUtils.multisensor_pipeline_utils.fusion_source import FusionSource
#from scibot_study_01.demo import MyAppli
from time import sleep
#from kivy.config import Config
"""
Main class to start the application
"""
if __name__ == "__main__":

    pipeline = GraphPipeline()

    src = FusionSource()
    pipeline.add_source(src)

    prc = IVTProcessor(42)
    pipeline.add_processor(prc)

    sink = ZmqPublisher(port=5556)
    pipeline.add_sink(sink)

    pipeline.connect(src, prc)
    pipeline.connect(prc, sink)
    pipeline.connect(src, sink)


    pipeline.start()
   # while True:
      #  continue

    """ def fun():
            app = MyAppli('scibot_study_01\\config.json')
            # replay_manager = ReplayManager("/Users/max/Desktop/Arbeit/gui_prototype_01/test_folder/User_01")
    
            # print(replay_manager.get_replay_data(0))
            # print(replay_manager.get_replay_data(0, reading=False))
            Config.set('input', 'mouse', 'mouse, multitouch_on_demand')
            app.run()
    
        trd = Thread(target=fun, name="Schwurbel")
        trd.start()"""

    sleep(15)
    #pipeline.stop()
