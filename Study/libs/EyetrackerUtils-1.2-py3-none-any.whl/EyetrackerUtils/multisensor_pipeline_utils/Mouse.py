import collections
from pynput import mouse
from multisensor_pipeline.modules.base import BaseSource
from multisensor_pipeline.utils.dataframe import MSPEventFrame, MSPDataFrame
from typing import Optional
import tobii_research as tr
import logging

logger = logging.getLogger(__name__)


class Mouse(BaseSource):
    """
    Source for mouse input. Can observe mouse movement, scroll and clicks.
    Sends MSPEventFrame when mouse changes are detected
    """

    def _update_loop(self):
        i=0
        while self._active:
            while not self.queue:
                i+=1

            value = self.queue.pop()
            self._notify_all(value[0], value[1])

    def __init__(self, move=True, click=False, scroll=False):
        super().__init__()
        self.move = move
        self.click = click
        self.scroll = scroll
        self.stop_listener = False
        self.listener = None
        self.queue = []


    def _start(self):
        args = {}
        if self.move:
            args["on_move"] = self.on_move
        if self.click:
            args["on_click"] = self.on_click
        if self.scroll:
            args["on_scroll"] = self.on_scroll

        self.listener = mouse.Listener(**args)
        self.listener.start()

    def on_move(self, x, y):
        frame = MSPEventFrame(init_dict={"x": x, "y": y}, timestamp= tr.get_system_time_stamp())

        self.queue.append(("mouse.coordinates", frame))

    def on_click(self, x, y, button, pressed):
        frame = MSPEventFrame(topic=self._generate_topic(name="mouse.click", dtype=float),
                              chunk={"x": x, "y": y, "button": button, "pressed": pressed})
        self.queue.append(frame)

    def on_scroll(self, x, y, dx, dy):
        frame = MSPEventFrame(topic=self._generate_topic(name="mouse.scroll", dtype=float),
                              chunk={"x": x, "y": y, "scroll_x": dx, "scroll_y": dy})
        self.queue.append(frame)

    def on_update(self) -> Optional[MSPDataFrame]:
        while not self.queue:
            if self.stop_listener:
                return
        #return self.queue.popleft()

    def on_stop(self):
        self.stop_listener = True
        self.listener.stop()