from multisensor_pipeline import BaseSink
from threading import Thread, Condition
import csv, time

class CSVSink  (BaseSink):

    def __init__(self, save_path, verbose=False, update_interval=0):
        super().__init__()
        self.__save_path = save_path
        self.verbose = verbose

        self._update_interval = update_interval
        self.log_list = []
        self.log_thread = Thread(target=self.logger, name='logging_thread')
        self.log_thread.start()
        self.log_list.append(['Display_x', 'Display_y', '3D_x', '3D_y', '3D_z', 'duration', 'timestamp_at_beginning'])

    def logger(self):
        with open(self.__save_path, 'w', newline='') as csvfile:
            logger = csv.writer(csvfile, delimiter=';')
            i =0
            while True:
                time.sleep(self._update_interval)
                tmp = self.log_list
                self.log_list = []
                for element in tmp:
                    item = element
                    logger.writerow(item)
                    if self.verbose:
                        print(item)

    def _update_loop(self):
        while self._active:
            # Gets gaze data dict
            dtype, data = self.get()

            if dtype == b'fixation':
                payload = data["data"]
                entries =payload.split(":")
                to_log = []
                for entry in entries:
                    to_log.append(float(entry))
                self.log_list.append(to_log)



