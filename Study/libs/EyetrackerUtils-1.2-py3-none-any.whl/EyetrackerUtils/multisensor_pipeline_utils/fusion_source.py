from multisensor_pipeline import BaseSource
from multisensor_pipeline.utils.eyetracking import MSPGazeFrame
from multisensor_pipeline.utils.dataframe import MSPDataFrame
from EyetrackerUtils.base_functionalities.fusion_base import EyetrackerInterface
import time
from EyetrackerUtils.i_vt_filter.gap_fill_in import gapfiller



"""
This class is to be used with the multisensor pipeline and enables basic interaction with eyetrackers
that are able to use Tobii Pro SDK. It extends the multisensor pipeline's base source class. 
For more information on the multisensor pipeline see  
https://github.com/DFKI-Interactive-Machine-Learning/multisensor-pipeline
"""
class FusionSource(BaseSource):

    # eyetracker object
    __eyetracker  = None

    # list to save gaze data
    __stream_to = []

    # deprecated
    __magic = 5

    # eyetracker sampling frequency
    __sfreq = 250

    # also deprecated
    __process = False

    """
        Creates a fusion source Class
        :param stream_to: an object to save gazedata in, must implement an append method
        :param magic: deprecated, might return in a future version, ignore for now
        :param average_eyes: how to treat data from left eye and right eye,
                    if True eyedata will be averaged,
                    if false rawgaze will be sent in addition to the averaged Gaze data
                    #TODO change variable name
        :eyetracker_sampling_frequency: The eyetracker's sampling frequency
        :proccess_gaze: unused for now. It'll be used in a future version
    """
    def __init__(self, stream_to=[], magic = 5, average_eyes = False, eyetracker_sampling_frequency = 250, process_gaze = False):
        super().__init__()
        self.__stream_to = stream_to
        self.__magic = magic
        self.average_eyes = average_eyes
        self.__sfreq = eyetracker_sampling_frequency
        self.__process = process_gaze

    """
    Implements the start method defined by the multisensor-pipeline module. Starts  the _update loop function
    """
    def _start(self):
        # initialize eyetracker
        self.__eyetracker = EyetrackerInterface()

        # save gazedata in self.stream_to
        def callback(gazedata):
            self.__stream_to.append(gazedata)

        # start collecting gazedata
        self.__eyetracker.get_gaze_data(callback)

        # Raise Errors that occur during the recording
        self.__eyetracker.subscribe_to_errors()



    """
    This is called in regular time intervals. Also just an implementation of a multisensor-pipeline abstract
    Gets data from self.streamto and forwards it to self._continue loop for further processing
    """
    def _update_loop(self):

        while True:
            # if no data available
            while len(self.__stream_to) == 0:
                # wait one sampling period and try again
                time.sleep(1/self.__sfreq)

            # get first gazedata object
            gazedata = self.__stream_to.pop()

            # repeat until valid (see gapfiller for this definition)
            while not gapfiller.is_valid(gazedata):

                while len(self.__stream_to) == 0:
                    time.sleep(1/self.__sfreq)

                gazedata = self.__stream_to.pop()

            self.__continue_loop(gazedata)

    def __continue_loop(self, gazedata):
        """
            does the data processing for this class After successfully processing the data, it is forwarded to the next
            pipeline instance
            :param gazedata: A gazedata object to be proessed in dict format
        """
        # get timestamp
        time = gazedata['system_time_stamp']

        if self.average_eyes:
            # average eye_data
            x, y = self.__average_2d(gazedata)

            # and send it out
            gframe = MSPGazeFrame((x, y), timestamp=time, normalized=True, origin=MSPGazeFrame.ORIGIN_TOP_LEFT)
            self._notify_all("eyetracking.gaze", gframe)

        else:

            # initialize MSPDataframe according to definition in pipeline
            helper = dict()
            helper["data"] = gazedata
            dataframe = MSPDataFrame(init_dict=helper)

            # send raw gaze data out
            self._notify_all("eyetracking.rawgaze", dataframe)

            # additionally send string with processed eyedata,
            # needed to be string due to limitations from the scibot project
            x, y = self.__average_2d(gazedata)
            gframe = str(x) + ':' + str(y)+ ':' + str(time)

            #deprecated: MSPGazeFrame((x, y), timestamp=time, normalized=True, origin=MSPGazeFrame.ORIGIN_TOP_LEFT)
            #change back should scibot no longer support this

            #forward to next pipeline instance
            self._notify_all("eyetracking.gaze", gframe)

    """
        Creates the average for the left and right eye in a tobii gazedata dict
        :param gazedata: a gazedata object, expected as dict
        :return: the averaged values as a Tuple
    """
    @staticmethod
    def __average_2d(gazedata):
        left = gazedata['left_gaze_point_on_display_area']
        right = gazedata['right_gaze_point_on_display_area']

        return (left[0] + right[0]) / 2, (left[1] + right[1]) / 2

    """
        Implements the abstract stop method. Stops the recording and deactivates the eyetracker.
    """
    def _stop(self):

        def callback(gazedata):
            self.__stream_to.append(gazedata)

        self.__eyetracker.stop_recording(callback)




if __name__ == "__main__":
    fs= FusionSource()
    fs._start()
    while True:
        time.sleep(1)
    fs._stop()
