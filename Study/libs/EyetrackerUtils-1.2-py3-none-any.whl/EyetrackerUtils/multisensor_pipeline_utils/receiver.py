import socket
import threading

class Receiver:

    def __init__(self, ip = 'localhost', port= 5666):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.ip = ip
        self.port = port
        self.__buffer = []


    def start(self):
        self.sock.connect((self.ip , self.port))

        def receiver():
            while True:
                chunk = self.sock.recv(1337)
                msg_string = chunk.decode('utf-8')
                str_list = msg_string.split(':')
                tmp = []
                for item in str_list:
                    tmp.append(float(item))
                self.__buffer.append(tmp)

        self.recv_thread = threading.Thread(target=receiver, name='receiver_thread')
        self.recv_thread.start()

    def get_buffer(self):
        tmp = self.__buffer
        self.__buffer = []
        return tmp

