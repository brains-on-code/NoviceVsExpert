from EyetrackerUtils.multisensor_pipeline_utils import mouse_mask_processor
from multisensor_pipeline.pipeline import GraphPipeline
from EyetrackerUtils.multisensor_pipeline_utils.Mouse import Mouse
from EyetrackerUtils.multisensor_pipeline_utils.socket_sink import SocketSink
#from multisensor_pipeline.modules.network import ZmqPublisher

#from scibot_study_01.demo import MyAppli


"""
    Simulates Eyetracker input without eyetracker presence, by substituting mouse data
"""
if __name__ == "__main__":
    pipeline = GraphPipeline()
    src = Mouse(scroll=False, click=False)
    prc = mouse_mask_processor.MouseMaskProcessor(1920, 1080)
    sink = SocketSink() #ZmqPublisher(port=5556)

    pipeline.add_source(src)
    pipeline.add_processor(prc)
    pipeline.add_sink(sink)

    pipeline.connect(src, sink)
    pipeline.connect(src, prc)
    pipeline.connect(prc, sink)

    pipeline.start()



