from multisensor_pipeline.modules.base import BaseProcessor
import tobii_research as tr


class MouseMaskProcessor(BaseProcessor):

    """
        Creates an instance of this class
        :param w: Screen width
        :param h: Screen height
    """
    def __init__(self, w, h):

        super().__init__()


        self.screen_w = w
        self.screen_h = h

    """
        Masks incoming mouse data to look like eyetracking data
    """
    def _update_loop(self):

        # while pipeline is active
        while self._active:
            # get new data
            dtype, data = self.get()

            # if it fits the masked type:
            if dtype == b"mouse.coordinates":

                # extract relevant data
                x = data["x"]
                y = data["y"]
                timestamp = data["timestamp"]

                # normalize inputs to imitate eyetracking data
                x = x/self.screen_w
                y = y/self.screen_h


                #send out "eyetracking" data
                #rint("Forwarding")
                fframe = str(x) + ':' + str(y) + ':'+ str(x) + ':' + str(y) + ':'+ str(x)+':'+ str(x)+ ':'+ str(timestamp)
                self._notify_all("fixation", fframe)

                gframe = str(x) + ':' + str(y) + ':' + str(timestamp)
                self._notify_all("eyetracking.gaze", gframe)

                """
                w= 1920
                ", "
                y
                ": "
                1080
                """