from multisensor_pipeline.modules.base import BaseProcessor
from EyetrackerUtils.i_vt_filter.ivt_filter import IVTFilter
# import time as thyme #lol


class IVTProcessor(BaseProcessor):

    """
        This class implements the Processor class for the multiprocessor pipeline
        and is intended for use with that library. It provides fixation filtering given input gaze data.
    """

    # list for saving gaze data
    __gazes = []

    # current length of data in time
    __duration = 0

    # window size
    __window = 0

    # time_stamp of first element in window
    __first_time_stamp = 0

    # filter object
    __filter = None

    # amount of fixations count WARNING: currently unused
    __fixation_count = 0


    """
        Initializes this processor object
        :param windowlength: How long the window for fixation computation should be in ms
    """
    def __init__(self, window_length):
        super().__init__()

        # transform to microseconds, as this is what Tobii uses for their IVT filter
        self.__window = window_length*1000

        #initialize IVTFilter
        self.__filter = IVTFilter()

    """
        Update the __gazes list and if the resulting duration >  window length: 
            compute fixations
            reset __gazes
    """
    def _update_loop(self):
        while self._active:
            # Gets gaze data dict
            dtype, data = self.get()

            # we need raw gaze data
            if dtype == b'eyetracking.rawgaze':

                # get data and add it to the list
                payload = data["data"]
                self.__gazes.append(payload)

                # get new timestamp
                time = payload['system_time_stamp']

                # if we are the first recording in this window, initialize list
                if self.__first_time_stamp == 0 and self.__duration == 0:
                    self.__first_time_stamp = payload['system_time_stamp']

                # if we are the second recording compute initial duration
                elif self.__duration == 0:
                    self.__duration = abs(time-self.__first_time_stamp)

                # if we are still shorter than the window now
                elif abs(time - self.__first_time_stamp) < self.__window:
                    # update duration
                    self.__duration = abs(time - self.__first_time_stamp)

                # if duration > window
                elif (abs(time - self.__first_time_stamp) > self.__window > self.__duration) or abs(time - self.__first_time_stamp) >= self.__window:
                    #  compute fixations
                    res = self.__filter.filter_data(dataset=self.__gazes)

                    # update duration
                    self.__duration = abs(time - self.__first_time_stamp)

                    # forward to next instance
                    self.__notify_for_fixations(res, self.__first_time_stamp)

                    # reset for next window
                    self.__gazes = []
                    self.__duration = 0
                    self.__first_time_stamp = 0
                """
                deprecated
                else:
                    while self.__duration > self.__window:
                        self.__gazes.pop()
                        while len(self.__gazes) == 0:
                            thyme.sleep(1)
                        real_first = self.__gazes[0]
                        self.__first_time_stamp = real_first['system_time_stamp']
                        self.__duration = abs(time - self.__first_time_stamp)

                    res  = self.__filter.filter_data(dataset=self.__gazes)

                    self.__notify_for_fixations(res, time)
                """
            else:
                pass

    """
        This method sets up fixation data to a fitting format and forwards it to the next instance
        :param events: A list of Events, that should be either Saccade, Fixation or Gap
        :param time: The timestamp of the event
    """
    def __notify_for_fixations(self, events, time):
        # for every event
        for event in events:

            # check its type
            if event.get_type()=='fixation':
                # we only need fixations
                # get positions
                pos = event.get_position_on_display()
                x = pos[0]
                y = pos[1]

                dx, dy,dz = event.get_position()

                # send out string; is string because of scibot limitations, decomment the fixation frame if needed
                # timestamp is time of fixation begin
                fframe = str(x)+ ':' + str(y) + ':'+ str(dx)+ ':'+ str(dy)+ ':'+ str(dz) + ':' +str(event.get_duration())+':'+str(time)
                #fframe = "0:0:0"
                # MSPFixationFrame(fixation_position=gframe, label=self.__fixation_count)

                # forward fixations to sink
                self._notify_all("fixation", fframe)

                # update fixation count
                self.__fixation_count+=1




