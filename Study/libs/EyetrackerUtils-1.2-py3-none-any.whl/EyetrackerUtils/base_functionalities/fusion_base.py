
import tobii_research as tr

"""
Class for interaction with the eyetracker.
A lot of functionality comes from the tobii_research package, this class just simplifies the interaction
For tobii_research documentation see http://developer.tobiipro.com/
"""
class EyetrackerInterface:
    # eyetracker object that this class uses
    __eyetracker = None
    # calibrator object to do claibration yourself
    __calibrator = None
    """
        Creates an EyetrackerInterface Objects. Initializes the eyetracker and calibrator variables
        Note that for now only the option for a single eyetracker is supported. Functionality for multiple will be added in the future
        
        :param amt:  amount of eyetrackers to be connected
        :param sel:  if multiple connections are available, give list index the eyetracker should be located at
        :param quickstart: whether or not to perfor, as described in the quickstart method below
    """
    def __init__(self, amt=1, sel=0, quickstart=True):
        if quickstart:
            self.__eyetracker = self.do_quickstart()
        else:
            #TODO implement functionality for direct communication with multiple eyetrackers
            #I actually do not know whether we'll need this
            raise Exception("Not implemented yet")
        self.__calibrator = tr.ScreenBasedCalibration(self.__eyetracker)


    """
    Gives Information of the currently selected Eyetracker
    """
    def get_eyetracker_info(self):
        print("Address: " + self.__eyetracker.address)
        print("Model: " + self.__eyetracker.model)
        print("Name (It's OK if this is empty): " + self.__eyetracker.device_name)
        print("Serial number: " + self.__eyetracker.serial_number)

    """
    Simple start, when using only one Eyetracker using the Tobii SDK, takes the first eyetracker Tobii finds,
    fastest method if only one eyetracker is connected
    :returns: an eyetracker object as defined in Tobii Pro SDK
    """
    def do_quickstart(self):
        return tr.find_all_eyetrackers()[0]

    """
    Enter calibration mode
    """
    def begin_calibration(self):
        self.__calibrator.enter_calibration_mode()

    """
     This should be called after showing what you want to calibrate at a certain point on screen (e.g. some stuff in Unity)
     :param point: The point at which the user should be looking during calibration
    """
    def calibrate_at_point(self, point):
        print("Collecting data at {0}.".format(point))
        if self.__calibrator.collect_data(point[0], point[1]) != tr.CALIBRATION_STATUS_SUCCESS:
            # Try again if it didn't go well the first time.
            self.__calibrator.collect_data(point[0], point[1])

    """
    Call this only after you called calibrate_at_point at least once for each point you want to calibrate
    Recalibration is possible
        :return: The calibration result
    """
    def apply_calibration(self):
        calibration_result = self.__calibrator.compute_and_apply()
        print(calibration_result)
        return  calibration_result

    def end_calibration(self):
        self.__calibrator.leave_calibration_mode()

    """
    Gets a previously done calibration
        :return: the calibration data as TODO
    """
    def get_active_calibration(self):


        data = self.__eyetracker.retrieve_calibration_data()
        return data

    """
    Method for interacting with the Eyetracker,
        :param callback: A callback function, that gets called every time there is no gaze data, needs to be specific to your project
    """
    def get_gaze_data(self, callback):
        self.__eyetracker.subscribe_to(tr.EYETRACKER_GAZE_DATA, callback, as_dictionary=True)



    """
    Ends a recording and unsubscribes from eyetracker events
        :param callback: A callback function for the gaze data, ideally the one used in the call of get_gaze_data
    """
    def stop_recording(self, callback):
        self.__eyetracker.unsubscribe_from(tr.EYETRACKER_GAZE_DATA, callback)

    """
    Subscribes to userposition events by the eyetracker
        :param callback: a callback function to store or process the data
    """
    def userposition(self, callback):
        self.__eyetracker.subscribe_to(tr.EYETRACKER_USER_POSITION_GUIDE, callback)

    @staticmethod
    def userpositiondefaultcallback(userposition):
        if userposition.left_eye.validity and userposition.rigt_eye.validity:
            print("Position is correct")
            return True
        else:
            print("position is incorrect")
            return False

    """
        Save calibration data to file after succesful calibration
        :param path: the path to save it to
    """
    def save_calibration_data(self, path):
        with open(path, "wb") as f:
            calibration_data = self.get_active_calibration()

            # None is returned on empty calibration.

            if calibration_data is not None:

                print("Saving calibration to file for eye tracker with serial number {0}.".format(
                    self.__eyetracker.serial_number))
                f.write(self.__eyetracker.retrieve_calibration_data())
            else:

                print("No calibration available for eye tracker with serial number {0}.".format(self.__eyetracker.serial_number))


    """
        Load calibration data from previously saved file
        :param path: the path to take it from
    """
    def load_calibration_data(self, path):
        with open(path, "rb") as f:
            calibration_data = f.read()
            #Don't apply empty calibrations.
            if len(calibration_data) > 0:
                print("Applying calibration on eye tracker with serial number {0}.".format(self.__eyetracker.serial_number))
                self.__eyetracker.apply_calibration_data(calibration_data)

    """
        Subscribes to Eyetracker error data.
        RAISES an  Exception should an error occur
    """
    def subscribe_to_errors(self):
        # callback for use in the subscription
        def stream_error_callback(notification):
            # if any error happens, raise it
            raise Exception(("Error {0} received, please restart").format(notification))

        # subscribe to error cases
        self.__eyetracker.subscribe_to(tr.EYETRACKER_STREAM_ERRORS, stream_error_callback)
        self.__eyetracker.subscribe_to(tr.EYETRACKER_NOTIFICATION_DEVICE_FAULTS, stream_error_callback)



if __name__ == "__main__":
    yee = []
    def gaze_data_callback_debug(gaze_data):
         #Print gaze points of left and right eye
        print("Left eye: ({gaze_left_eye}) \t Right eye: ({gaze_right_eye})".format(
            gaze_left_eye=gaze_data['left_gaze_point_on_display_area'],
            gaze_right_eye=gaze_data['right_gaze_point_on_display_area']))
        yee.append(gaze_data)

    inter = EyetrackerInterface()
    inter.get_eyetracker_info()
    #print(inter.get_active_calibration())
    #inter.debug_method()

    inter.get_gaze_data(callback=gaze_data_callback_debug)
    i=0
    while(True):
        i+=1
        if len(yee) >1:
          #  print(yee[1]['device_time_stamp'] - yee[0]['device_time_stamp'])
            yee.pop(0)

        #print("doing stuff")
