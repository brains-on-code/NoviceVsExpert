from EyetrackerUtils.base_functionalities.fusion_base import EyetrackerInterface
from threading import Thread, Condition
import csv

class Logger():

    def __init__(self, filepath: str):
        """
            Creates an instance of this class
            :param filepath: Where to save the log
        """
        self.__filepath = filepath
        # which aspects of the eyetracker to log
        self.__dict_keys = []
        # the eyetracker object
        self.__eyetracker = EyetrackerInterface()

        self.cond = Condition()

    def add_key_to_log(self, key: str):
        """adds a key to self.__dict_keys
        :param key: the key to add
        """
        self.__dict_keys.append(key)

    def remove_key_from_log(self, key):
        """
            Removes a key from self.__dict_keys
            Possible Parameters:

            :param key: the key to remove
        """
        self.__dict_keys.remove(key)

    def start_recording(self):
        """
            Starts a recording. You should have added keys to self.add_key_to_log_previously
        """
        # throw an Error if the Eyetracker Object has one
        self.__eyetracker.subscribe_to_errors()
        # start the logger thread
        self.logging_thread = Thread(target=self.thread_log, name='logging_thread')
        self.logging_thread.start()

    def thread_log(self):
        """
            Subsrcribes to gaze_data and keeps the csv file open
            'left_gaze_point_in_user_coordinate_system' --> gives a gaze point in 3D space for the right eye
            'right_gaze_point_in_user_coordinate_system' --> gives a gaze point in 3D Space for the left eye
            'left_gaze_origin_in_user_coordinate_system' --> gives the position of the eye in 3D space
                (for grid reference see Tobii SDK documentation). Also possible with right
            'left_gaze_point_on_display_area' --> gives a gaze point on the display plane for the left eye. Also possible with right
            'system_time_stamp' --> The system's timestamp at the point of the eyetracking
            WARNING: Tobii's timestamping is weird. Check their documentation to see and use the tobii_research.get_system_time_stamp method for synchonization
            'left_pupil_diameter' --> Gives the diameter of the left pupil. Also possible with right
        """
        with self.cond:
            with open(self.__filepath, 'w',newline='') as csvfile:
                logger = csv.writer(csvfile, delimiter= ';')

                def log(gaze_data):
                    log_list = []
                    for val in self.__dict_keys:
                        log_list.append(gaze_data[val])
                    logger.writerow(log_list)

                self.__eyetracker.get_gaze_data(log)
                self.cond.wait()
                self.__eyetracker.stop_recording(log)

    def stop_recording(self):
        """
            Notifies the thread_log to stop recording
        """
        with self.cond:
            self.cond.notifyAll()


if __name__ == "__main__":
    import time
    import tobii_research as tr

    tst = tr.get_system_time_stamp()
    print(tst)
    log = Logger("../test.csv")
    log.add_key_to_log('left_gaze_point_in_user_coordinate_system')
    log.add_key_to_log('right_gaze_point_in_user_coordinate_system')
    log.start_recording()
    print('yee')
    time.sleep(5)
    log.stop_recording()


