from EyetrackerUtils.i_vt_filter.event import Event


class Gap(Event):
    __dur = -1

    def __init__(self, duration):
        super().__init__(duration)

    @staticmethod
    def get_type():
        return 'gap'
