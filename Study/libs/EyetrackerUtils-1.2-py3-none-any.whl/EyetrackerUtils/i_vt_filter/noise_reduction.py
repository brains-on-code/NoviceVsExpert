import math


class noise_reduction:

    def __init__(self, mode: str = 'mv_avg'):
        """
            Returns an instance of this class
            :param mode: Which noise reduction mode to use
                        Currently only supports moving average
                        TODO: add more
        """
        self.mode = mode

    def reduce_noise(self, data_set: list, window: int =3) -> list:
        """
        Select noise reduction method according to self.mode
        :param data_set: the dataset to use this one
        :param window: Sliding window in samples, needs to be uneven for moving average filter, see Tobii Paper
        :return: A modified list of FixationData
        """
        if self.mode == 'mv_avg':
            return self.__moving_average(data_set, window)
        else:
            raise NotImplementedError(f"Got {self.mode} expected 'mv_avg'")

    def __moving_average(self, dataset: list, window: int) -> list:
        """
            Method performing the moving average filter
            :param dataset: the dataset to work with, expects list elements to be of type FixationData, or at least mirror
                            its contents
            :param window: the window length, in samples, to work with

        """
        # if our window is even --> cancel
        if window % 2 == 0:
            raise Exception("Not symmetrical, window needs to be uneven")
        # setup output
        output = []
        # for sample in dataset
        for index in range(len(dataset)):
            # split  dataset into portionsized windows
            data, win = self.__select_window(dataset, window, index)
            #  form average of one window portion
            dataset[index].gazepoint_avg = (self.__moving_average_one(data, win))
            # append this to output
            output.append(dataset[index])
        return output

    def __select_window(self, dataset, window, index):

        """
        Creates a windowing function
        :param dataset: the whole dataset to use
        :param window: window size
        :param index: position in dataset
        :return: a list as close to window length as possible, the window length used
        """
        output = []
        # we need at least 3 samples
        if window < 3:
            return [dataset[index]], 3
        # if there is not enough space, return just the dataset
        if (index < window or index + window >= len(dataset)) and window == 3:
            return [dataset[index]], window
        # if we are too large reduce size by two
        elif (index < window or index + window >= len(dataset)) and window > 3:
            return self.__select_window(dataset, window-2, index)
        else:
            # create the windowed function
            helper = window -1

            helper = int(helper / 2)
            # take lesser bount
            for ind in range(helper, -1, -1):
                debug = index-ind
                output.append(dataset[debug])
            # create upper bound
            for ind in range(1,helper+1):
                debug2 = index+ind
                output.append(dataset[debug2])
            # check for gaps
            for sample in output:
                # if we have a gap
                if sample.gap_check():
                    # we need to go lower
                    return self.__select_window(dataset, window-2, index)
        # return our results
        return output, window
        """
        TODO: This is better integrate this to improve here
       
        """

    def __moving_average_one(self, datasamples: list, window: int) -> tuple:
        """
        Use a moving average filter.
        :param datasamples: the dataset  to use
        :param window: window length to use
        :return: the averaged position values
        """
        if len(datasamples) == 1:
            return datasamples[0].gazepoint_avg
        else:
            # create lists for the first second and third positions in the point
            first = []
            second = []
            third = []
            # for all samples
            for sample in datasamples:
                # if they are a gap
                if sample.gap_check():
                    continue

                # For all e coordinates get the average
                first.append(sample.gazepoint_avg[0])
                second.append(sample.gazepoint_avg[1])
                third.append((sample.gazepoint_avg[2]))
            # if we have length 0
            if len(first) == 0:
                # we can't compute anything
                return math.nan
            # else return the arguments
            return sum(first) / window, sum(second) / window, sum(third) / window

    def __moving_average_one_2d(self, datasamples, window):
        """
            2D equivalent of the above 3d method
            :param datasamples: the set of samples to use for averaging
            :param window: the window length to expect
        """
        if len(datasamples) == 1:
            return datasamples[0].gaze2d_avg
        else:
            first = []
            second = []

            for sample in datasamples:

                if sample.gap_check():
                    continue
                first.append(sample.gaze2d_avg[0])
                second.append(sample.gaze2d_avg[1])

            if len(first) == 0:
                return math.nan
            return (1/window) * sum(first), (1/window) * sum(second)


