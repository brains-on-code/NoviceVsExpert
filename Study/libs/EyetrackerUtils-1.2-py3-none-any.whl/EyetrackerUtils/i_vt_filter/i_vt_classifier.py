from EyetrackerUtils.i_vt_filter.gap import Gap
from EyetrackerUtils.i_vt_filter.saccade import saccade
from EyetrackerUtils.i_vt_filter.fixation import fixation
from EyetrackerUtils.i_vt_filter.event import Event
from EyetrackerUtils.i_vt_filter.fixation_data import FixationData


class IVTClassifier:

    def __init__(self, threshhold: float = 30):
        """
        Creates an instance of ivtclassifier
        :param threshhold: The maximum angular velocity between two gazes to still belong to the same fixation
        """
        self.__threshhold = threshhold

    def __check_for_fixation(self, sample: FixationData):
        """
        Simple method that checks whether a given sample belongs to a fixation or not.
        If yes, a flag is set in the data struct.
        :param sample: a data sample of type fixation_data

        """
        if sample.gap_check():
            return
        elif sample.velocity < self.__threshhold:
            sample.fixation = True

    def classify_dataset(self, dataset: list) -> list:
        """
            This function classifies every sample in the dataset to either be a saccade, gap or fixation
            :param dataset: a list of type fixation_data
            :returns: a list of events that are either gap, fixation or saccade
        """
        output = []
        current_group = 'None'
        group_first = -1

        # For element in the data set
        h = len(dataset)
        for index in range(len(dataset)):
            if index == len(dataset)-1:

                something = 42
            sample = dataset[index]
            self.__check_for_fixation(sample) # set the fixation flag

            # Check the group of the current sample
            if sample.gap_check():  # Is the sample a gap
                if current_group != 'gap':

                    if index != 0:
                        dataset[index-1].last_in_group = True
                        output.append(self.__finish_group(group_first, index-1, dataset, mode=current_group))
                    dataset[index].first_in_group = True
                    group_first = index
                    current_group = 'gap'
                if index == len(dataset)-1:
                    dataset[index].last_in_group = True
                    output.append(self.__finish_group(group_first, index, dataset, mode=current_group))
            elif sample.fixation:
                if current_group != 'fixation':
                    if index != 0:
                        dataset[index-1].last_in_group = True
                        output.append(self.__finish_group(group_first, index-1, dataset, mode=current_group))
                    dataset[index].first_in_group = True
                    group_first = index
                    current_group = 'fixation'
                if index == len(dataset)-1:
                        dataset[index].last_in_group = True
                        output.append(self.__finish_group(group_first, index, dataset, mode=current_group))
            else:
                if current_group != 'saccade':
                    if index != 0:
                        dataset[index - 1].last_in_group = True
                        output.append(self.__finish_group(group_first, index - 1, dataset, mode=current_group))
                    dataset[index].first_in_group = True
                    group_first = index
                    current_group = 'saccade'
                if index == len(dataset)-1:
                        dataset[index].last_in_group = True
                        output.append(self.__finish_group(group_first, index, dataset, mode=current_group))
                elif current_group == "None":
                    if index == len(dataset)-1:
                        dataset[index].last_in_group = True
                        output.append(self.__finish_group(group_first, index, dataset, mode=current_group))
        return output
    """
        if sample.gap_check():  # Is the sample a gap
            currentgroup, group_first = helper("gap", current_group, outpuut, index, dataset, goup_first)
        elif sample.fixation:
            currentgroup, group_first = helper("fixation", current_group, outpuut, index, dataset, goup_first)
        else:
            currentgroup, group_first = helper("saccade", current_group, outpuut, index, dataset, goup_first)
    
    def helper(self, type, current_group, output, index, dataset, group_first):
        if current_group != type:
            if index != 0:
                dataset[index - 1].last_in_group = True
                output.append(self.__finish_group(group_first, index - 1, dataset, mode=current_group))
            dataset[index].first_in_group = True
            group_first = index
            current_group = type
            if index == len(dataset) - 1:
                dataset[index].last_in_group = True
                output.append(self.__finish_group(group_first, index, dataset, mode=current_group))
        return current_group, group_first
    """
    def __finish_group(self,first_index: int, last_index: int, dataset: list, mode: str) -> Event:
        """
            Wraps up a group of Fixation_data to a given group
            :param first_index: The first index of the group in dataset
            :param last_index: The last index of the group in dataset
            :param dataset: A list of FixationData, preprocessed by earlier methods
            :param mode: The group type, as of now can be either gap saccade or fixation
            :return: An Event of type :mode:
        """
        time = dataset[first_index].get_time()
        duration = dataset[last_index].get_time_diff(time)
        if mode == 'gap':
            return Gap(duration=duration)
        elif mode == 'saccade':
            return saccade(duration=duration)
        else:
            positions = []
            displaypos = []
            for index in range(first_index, last_index+1):
                positions.append(dataset[index].gazepoint_avg)
                displaypos.append(dataset[index].gaze2d_avg)
            return fixation(duration, self.__average_positions(positions), self.__average_positions_2d(displaypos), (first_index, last_index))

    def __average_positions(self, positions: list) -> tuple:
        """
            Averages the positions from :positions:
            :positions: A list of 3D points (see Tobii SDK documentation for specifics, like grid,...)
            :returns: A tuple of the averaged positions in 3D-space
        """
        first = []
        second = []
        third = []
        for index in range(len(positions)):
            first.append(positions[index][0])
            second.append(positions[index][1])
            third.append(positions[index][2])
        return sum(first)/len(first), sum(second)/len(second), sum(third)/len(third)

    def __average_positions_2d(self, positions: list) -> tuple:
        """
            Averages the positions from :positions:
            :positions: A list of 2D points, located on the display plane(see Tobii SDK documentation)
            :return: a tuple of the averaged positions, located on the display plane
        """
        first = []
        second = []

        for index in range(len(positions)):
            first.append(positions[index][0])
            second.append(positions[index][1])

        return sum(first) / len(first), sum(second) / len(second)