from EyetrackerUtils.i_vt_filter.gap_fill_in import gapfiller
from EyetrackerUtils.i_vt_filter.eye_selection import eye_selector
from EyetrackerUtils.i_vt_filter.noise_reduction import noise_reduction
from EyetrackerUtils.i_vt_filter.velocity_calculator import VelocityCalculator
from EyetrackerUtils.i_vt_filter.i_vt_classifier import IVTClassifier
from EyetrackerUtils.i_vt_filter.fixation import fixation
from EyetrackerUtils.i_vt_filter.fixation_data import FixationData
import numpy as np
"""
This class is an implementation of the algorithm found in the following paper:
http://www.vinis.co.kr/ivt_filter.pdf
"""

class IVTFilter:

    def __init__(self, merge_adjacent_fixations:bool = True, max_time_between: float = 75, max_angle_between: float =0.5,
                 discard_shorts: bool = True, minimum_fixation_duration: float = 60):
        """
            Creates an instance of this class
            :param merge_adjacent_fixations: If True  adjacent fixations are merged if the time difference between them
                                             is less than max_time_between
            :param max_time_between: maximum time between two fixations that can be merged in ms. This can be ignored if
                                    merge_adjacent_fixations is set to False
            :param max_angle_between: maximum angle between two fixations that can be merged This can be ignored
                                        if merge_adjacent_fixations is set to False
            :param discard_shorts: Whether or not to discard fixations shorter than minimum_fixation_duration
            :param minimum_fixation_duration: minimum value (in ms) for a fixation to not be discarded

        """
        self.__merge_adjacent_fixations = merge_adjacent_fixations
        self.__max_time_between = max_time_between
        self.__max_angle_between = max_angle_between
        self.__discard_shorts = discard_shorts
        self.__minimum_fixation_duration = minimum_fixation_duration

    def filter_data(self, dataset: list, max_gap_length: int =75, eye_selection_mode='average', noise_reduction_mode='mv_avg',
                    noise_reduction_window=3, sfreq=250, velocity_window=20, classification_threshhold=30) -> list:
        """
        Takes data from the eyetracker as input and returns a list of saccades, gaps and fixations.
        :param dataset: the dataset to use
        :param max_gap_length: the maximum length a gap can have in microseconds
        :param eye_selection_mode:How to deal with the fact that we have two eyes. Currently supports 'average',
                                    'left' and 'right'
                                    With 'average' avereging between left and right eye and 'left' or  'right just taking
                                    one eye into account. The Tobii paper recommends 'average'.
        :param noise_reduction_mode: Which algorithm to use for noise reduction. Currently only supports 'mv_avg'.
                                    Feel free to implement your own
        :param noise_reduction_window: How many samples the moving average filter should take into account.
        :param sfreq: Eyetracker sampling frequency (Pro Fusion has 250 Hz)
        :param velocity_window: From how many position samples to calculate the volcity
        :param classification_threshhold: Maximal velocity for a sample to be classified as a fixation
        :return: A list of  class Event
        """

        # Create gapfiller object to interpolate missing data or create gaps.
        gapfill = gapfiller(mgl=max_gap_length)
        fix_data = gapfill.check_dataset(dataset)

        # Create eye selector object too select how to mesh data form two eyes into one.
        eyes = eye_selector(eye_selection_mode)
        fix_data = eyes.select_eyes(fix_data)

        # Create noise reduction object to reduce noise. duh
        nres = noise_reduction(noise_reduction_mode)
        fix_data = nres.reduce_noise(fix_data, noise_reduction_window)

        # Create VelocityCalculator object to calculate angular velocity of eye movement.
        vel_calc = VelocityCalculator(sfreq)
        fix_data = vel_calc.calculate_velocities(fix_data, velocity_window)

        # Create IVTClassifier object to classify into saccades, gaps and fixations.
        classifier = IVTClassifier(classification_threshhold)
        events = classifier.classify_dataset(fix_data)
        if self.__merge_adjacent_fixations:
            events = self.__merge_fixations(events, fix_data)
        if self.__discard_shorts:
            events = self.__discard_fixations(events)
        return events

    def __merge_fixations(self, events:list, original_data:list) -> list:
        """
        Determines whether two fixation should be merged into one if close to each other.
        :param events: a list of events
        :param original_data: the list containing the gaze samples of class fixation_data
        :return: a list of events
        """
        last_fixation_ended_at = -1
        last_fix_index = -1
        last_fix_output = -1
        output = []

        # for event in events
        for index in range(len(events)):
            event = events[index]

            # if the event is a fixation
            if event.get_type() == 'fixation':
                # If the fixation isn't the first
                if last_fix_index != -1:
                    last_fix_end = original_data[last_fixation_ended_at].get_time()
                    this_fix_begin = event.get_index_pos()[0]
                    time_diff = original_data[this_fix_begin].get_time_diff(last_fix_end)

                    # If time difference between the last and this fixation is less than some magic number
                    if time_diff < self.__max_time_between:
                        # Compute the average origin position of the two fixations
                        eye = self.__get_average_eye_pos(original_data[last_fixation_ended_at].gazeorigin_avg,
                                                         original_data[this_fix_begin].gazeorigin_avg)
                        # Compute the angle between the two positions
                        angle = self.__calculate_visual_angle(original_data[last_fixation_ended_at].gazepoint_avg,
                                                              original_data[this_fix_begin].gazepoint_avg,
                                                              eye
                                                              )

                        # If the angle is less than some other magic number
                        if angle < self.__max_angle_between:
                            # Merge commences...

                            fix1 = events[last_fix_index]
                            fix1begin = original_data[fix1.get_index_pos[0]].get_time()
                            dur = original_data[event.get_index_pos[1]].get_time_diff(fix1begin)
                            pos1 = fix1.get_position()
                            pos2 = event.get_position()
                            pos = self.__get_average_eye_pos(pos1, pos2)
                            pos1 = fix1.get_position_on_display()
                            pos2 = event.get_position_on_display()
                            dis_pos = self.__get_average_eye_pos_2d(pos1, pos2)
                            newfix = fixation(dur, pos, dis_pos, (fix1.get_index_pos[0], event.get_index_pos[1]))
                            helper = []
                            for i in range(last_fix_output):
                                helper.append(output[i])
                            helper.append(newfix)
                            output = helper
                        else:
                            output.append(event)
                    else:
                        output.append(event)
                else:
                    output.append(event)
                last_fixation_ended_at = event.get_index_pos()[1]
                last_fix_index = index
                last_fix_output = len(output)
            else:
                output.append(event)
        return output

    @staticmethod
    def __get_average_eye_pos(pos1: tuple, pos2: tuple) -> tuple:
        """
            Averages two positions in 3D Space. For details on the grid see Tobii SDK documentation
            :param pos1: Point in 3D space to be averaged
            :param pos2: Point in 3D space to be averaged
            :return: the result of averaging both points
        """

        return (pos1[0]+pos2[0])/2, (pos1[1]+pos2[1])/2, (pos1[2]+pos2[2])/2

    @staticmethod
    def __get_average_eye_pos_2d(pos1, pos2):
        """
                 Averages two positions in 2D Space. For details on the grid see Tobii SDK documentation
                 :param pos1: Point in 2D space to be averaged
                 :param pos2: Point in 2D space to be averaged
                 :return: the result of averaging both points
             """
        return (pos1[0] + pos2[0]) / 2, (pos1[1] + pos2[1]) / 2

    def __calculate_visual_angle(self, first: FixationData, second: FixationData, eye: tuple) -> float:
        """
            Calculates the visual angle between two gaze pojnts in 3D space
            :param first: One of the two positions
            :param second: The other position
            :param eye: The gazeorigin, or the eye, from which the gaze came from
        """

        f_pos = first.gazepoint_avg
        s_pos = second.gazepoint_avg

        v1 = np.array([f_pos[0] - eye[0], f_pos[1] - eye[1], f_pos[2] - eye[2]])
        v2 = np.array([s_pos[0] - eye[0], s_pos[1] - eye[1], s_pos[2] - eye[2]])

        angle = self.__angle_between(v1, v2)
        return angle

    @staticmethod
    def __unit_vector(vector):
        """ Returns the unit vector of the vector.
            :param vector: an np array of numbers
            """
        return vector / np.linalg.norm(vector)

    def __angle_between(self, v1, v2) -> float:
        """
            calculates the angle between two vectors
            :param v1: An np array of numbers
            :param v2: A second np array of numbers
        """
        v1_u = self.__unit_vector(v1)
        v2_u = self.__unit_vector(v2)
        return np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0))

    def __discard_fixations(self, events:list)-> list:
        """
            Removes fixations that are shorter than self.__minimum_fixation_duration, which is set in the init
            :param events: A list of class Event
            :returns: A list of class Event sans short fixations
        """
        output = []
        for event in events:
            if event.get_type() == 'fixation':
                dur = event.get_duration()
                if dur >= self.__minimum_fixation_duration:
                    output.append(event)
            else:
                output.append(event)
        return output


if __name__ == "__main__":
    from EyetrackerUtils.base_functionalities.fusion_base import EyetrackerInterface
    import time
    eyetracker = EyetrackerInterface()
    data = []
    print("1")
    def callback(gaze_data):
        data.append(gaze_data)

    eyetracker.get_gaze_data(callback)
    print("collecting data")
    time.sleep(5)
    eyetracker.finish_gaze_data(callback)
    print("Stopped collecting")
    test = IVTFilter()
    res = test.filter_data(data)
    print(res)
    helper = 2
    print("Done")