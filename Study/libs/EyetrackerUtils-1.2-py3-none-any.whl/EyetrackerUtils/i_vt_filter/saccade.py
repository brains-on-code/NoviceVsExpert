from EyetrackerUtils.i_vt_filter.event import Event


class saccade(Event):

    def __init__(self, duration):
        super().__init__(duration)


    @staticmethod
    def get_type():
        return 'saccade'