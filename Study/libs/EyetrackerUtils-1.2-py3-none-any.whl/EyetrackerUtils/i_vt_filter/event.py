
class Event():

    def __init__(self, duration):
        self.__duration = duration

    @staticmethod
    def get_type():
        raise NotImplementedError

    def get_duration(self):
        return self.__duration
