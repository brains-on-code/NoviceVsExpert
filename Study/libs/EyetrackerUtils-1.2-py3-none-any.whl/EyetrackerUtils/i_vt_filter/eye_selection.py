class eye_selector:

    def __init__(self, mode:str ='average'):
        """
            Returns an instance of this class
            :param mode: how to select eyes
        """
        self.mode = mode

    def select_eyes(self, dataset: list) -> list:
        """
            Method selection
            :param dataset: a list of FixationData
        """
        if self.mode == 'average':
            return self.__average_eyes(dataset)
        elif self.mode == 'left' or self.mode == 'right':
            return self.__one_sided(dataset)
        else:
            raise NotImplementedError(f"Got {self.mode}, but expected 'average', 'right' or 'left'")

    def __one_sided(self, dataset: list) -> list:
        """
        For dealing with only one eye.
        :param dataset: a list of type FixationData
        :return: the modified list
        """
        # TODO: This method has bugs
        for gaze_data in dataset:

            gaze_data.gazepoint_avg = gaze_data.get_side_gaze(self.mode)
            gaze_data.gazeorigin_avg = gaze_data.get_side_gazeorigin(self.mode)
        return dataset

    def __average_eyes(self, dataset: list) -> list:
        """
            Averages between left and right eye for single gazepoint (2D and 3D)and gazepoint origin.
            This is done by setting the gazepointavg attribute to the average
            :param dataset: a list of type FixationData
            :return: the modified list
        """
        skip_index = 0
        non_skip_index = 0
        output = []
        for gaze_data in dataset:
            # If this is a gap
            if gaze_data.gap_check():
                skip_index += 1
                # Append to output and examine next sample.
                output.append(gaze_data)
                continue
            non_skip_index+=1

            # Compute gaze position in 3D coordinates
            left = gaze_data.get_side_gaze('left')
            right = gaze_data.get_side_gaze('right')
            gaze_data.gazepoint_avg = ((left[0]+right[0])/2, (left[1]+right[1])/2, (left[2]+right[2])/2)

            # Compute average for gaze origin in 3D
            left = gaze_data.get_side_gazeorigin('left')
            right = gaze_data.get_side_gazeorigin('right')
            origin = ((left[0]+right[0])/2, (left[1]+right[1])/2, (left[2]+right[2])/2)
            gaze_data.gazeorigin_avg = origin

            # Compute Average Gaze on the monitor
            left, right = gaze_data.get_2d_gaze()
            gaze_data.gaze2d_avg = ((left[0]+right[0])/2, (left[1]+right[1])/2)

            output.append(gaze_data)
        #print("Skipped: " + str(skip_index) )
        #print("Computed: "+ str(non_skip_index))
        return output