from EyetrackerUtils.i_vt_filter.event import  Event

class fixation(Event):
    __duration = -1
    __position = -1
    __2d_pos = ()
    __index_pos = ()

    def __init__(self, dur, pos, dis_pos, index_pos):
        """
            Returns an instance of this class
            :param dur: Fixation Duration
            :param pos: Position in 3D space
            :param dis_pos: Position on display plane (2D space)
            :param index_pos: position in the original list. Used for computation in merging,...
        """
        super().__init__(dur)
        self.__position = pos
        self.__2d_pos = dis_pos
        self.__index_pos = index_pos


    def get_position(self):
        return self.__position

    def get_index_pos(self):
        return self.__index_pos

    def get_position_on_display(self):
        return self.__2d_pos

    @staticmethod
    def get_type():
        return 'fixation'
