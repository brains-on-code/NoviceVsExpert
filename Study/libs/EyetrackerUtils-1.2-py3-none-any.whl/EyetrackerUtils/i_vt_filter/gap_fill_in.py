from EyetrackerUtils.i_vt_filter.fixation_data import FixationData


class gapfiller:
    """
    For more information see Tobii paper section 3.1
    """

    max_gap_length = 0
    __time_last_valid = 0  # Timestamp in micro s of the last valid sample
    __invalids = []  # Temporary storage for gap samples
    __time_last_invalid = 0  # Timestamp in micro s of the last invalid sample
    __has_gap = False  # Are we currently in a gap
    __first_invalid_of_gap = 0  # Timestamp of the first invalid sample in a gap
    __last_valid = None  # Gaze data object of the last valid

    def __init__(self, mgl: float=75):
        """
        :param mgl: maximal gap length in milli seconds. If a gap is longet than this its a gap, otherwise it is interpolated.
        """
        self.max_gap_length = mgl*1000  # Change unit to micro seconds

    def check_dataset(self, dataset: list) -> list:
        """
        Uses check_gaze_data on the whole dataset and converts them to FixationData. If a sample is a gap, it is either
        intepolated or the is_gap flag is set to True. Interpolation ist done according to the Tobii Paper
        :param dataset: the dataset used, expects a list of dicts as created by the Tobii Pro SDK
        :return: a list of type FixationData
        """
        output = []
        for sample in dataset:
            res = self.check_gaze_data(sample)
            if len(res) != 0:
                for mini_sample in res:
                    output.append(mini_sample)
        return output

    def check_gaze_data(self, gaze_data: dict) -> list:
        """
        Checks whether gaze data is gap or not and interpolated if needed.
        :param gaze_data: a dict object as produced by Tobii Pro SDK gaze data
        :return: the transcribed object as FixationData in a List or a List of Fixation Data in case of a Gap or
                interpolation. Returns empty list when unsure and waiting whether to interpolate or it is a true gap
        """
        # if the current sample is valid
        if self.is_valid(gaze_data):
            # if the last few samples were a gap
            if self.__has_gap:
                # check gap length
                gap_duration = gaze_data['system_time_stamp'] - self.__first_invalid_of_gap
                # if gap was too long
                if gap_duration > self.max_gap_length:
                    # since this is no Gap sample, set flag for next sample
                    self.__has_gap = False
                    output = []
                    # gap was too long --> All Samples in this group are gaps
                    for sample in self.__invalids:
                        output.append(FixationData(sample['left_gaze_point_in_user_coordinate_system'],
                                                   sample['right_gaze_point_in_user_coordinate_system'],
                                                   sample['left_gaze_origin_in_user_coordinate_system'],
                                                   sample['right_gaze_origin_in_user_coordinate_system'],
                                                   sample['left_gaze_point_on_display_area'],
                                                   sample['right_gaze_point_on_display_area'],
                                                   sample['system_time_stamp'],
                                                   True)
                                      )

                    # append current valid sample
                    output.append(FixationData(gaze_data['left_gaze_point_in_user_coordinate_system'],
                                               gaze_data['right_gaze_point_in_user_coordinate_system'],
                                               gaze_data['left_gaze_origin_in_user_coordinate_system'],
                                               gaze_data['right_gaze_origin_in_user_coordinate_system'],
                                               gaze_data['left_gaze_point_on_display_area'],
                                               gaze_data['right_gaze_point_on_display_area'],
                                               gaze_data['system_time_stamp'],
                                               False
                                               )
                                  )
                    # set up for next gap
                    self.__invalids = []
                    self.__last_valid = gaze_data
                    self.__time_last_valid = gaze_data['system_time_stamp']
                    return output
                # if it was not too long
                else:
                    # interpolate the samples
                    interpolated = self.__interpolate_gap(gaze_data)
                    # set up for next gap
                    self.__invalids = []
                    output = []
                    self.__last_valid = gaze_data
                    self.__time_last_valid = gaze_data['system_time_stamp']

                    # generate output
                    for sample in interpolated:
                        # Did interpolation succeed?
                        if self.is_valid(interpolated[0]):
                            # if yes all is well
                            output.append(FixationData(sample['left_gaze_point_in_user_coordinate_system'],
                                                   sample['right_gaze_point_in_user_coordinate_system'],
                                                   sample['left_gaze_origin_in_user_coordinate_system'],
                                                   sample['right_gaze_origin_in_user_coordinate_system'],
                                                   sample['left_gaze_point_on_display_area'],
                                                   sample['right_gaze_point_on_display_area'],
                                                   sample['system_time_stamp'],
                                                   False)
                                        )
                            output.append(FixationData(gaze_data['left_gaze_point_in_user_coordinate_system'],
                                               gaze_data['right_gaze_point_in_user_coordinate_system'],
                                               gaze_data['left_gaze_origin_in_user_coordinate_system'],
                                               gaze_data['right_gaze_origin_in_user_coordinate_system'],
                                               gaze_data['left_gaze_point_on_display_area'],
                                               gaze_data['right_gaze_point_on_display_area'],
                                               gaze_data['system_time_stamp'],
                                               False
                                               ))
                            return output
                        else: # if no we need to set the samples as gap anyways
                            output.append(FixationData(sample['left_gaze_point_in_user_coordinate_system'],
                                                       sample['right_gaze_point_in_user_coordinate_system'],
                                                       sample['left_gaze_origin_in_user_coordinate_system'],
                                                       sample['right_gaze_origin_in_user_coordinate_system'],
                                                       sample['left_gaze_point_on_display_area'],
                                                       sample['right_gaze_point_on_display_area'],
                                                       sample['system_time_stamp'],
                                                       True)
                                          )
                            # our last sample is not a gap
                            output.append(FixationData(gaze_data['left_gaze_point_in_user_coordinate_system'],
                                                      gaze_data['right_gaze_point_in_user_coordinate_system'],
                                                      gaze_data['left_gaze_origin_in_user_coordinate_system'],
                                                      gaze_data['right_gaze_origin_in_user_coordinate_system'],
                                                      gaze_data['left_gaze_point_on_display_area'],
                                                      gaze_data['right_gaze_point_on_display_area'],
                                                      gaze_data['system_time_stamp'],
                                                      False
                                                      ))
                            return output
            # add current sample and set time since we are not in gap
            self.__last_valid = gaze_data
            self.__time_last_valid = gaze_data['system_time_stamp']
            return [FixationData(gaze_data['left_gaze_point_in_user_coordinate_system'],
                                 gaze_data['right_gaze_point_in_user_coordinate_system'],
                                 gaze_data['left_gaze_origin_in_user_coordinate_system'],
                                 gaze_data['right_gaze_origin_in_user_coordinate_system'],
                                 gaze_data['left_gaze_point_on_display_area'],
                                 gaze_data['right_gaze_point_on_display_area'],
                                 gaze_data['system_time_stamp'],
                                 False)
                    ]
        # in case we are invalid
        else:
            # if we are in a gap
            if self.__has_gap:
                # append current sample
                self.__time_last_invalid = gaze_data['system_time_stamp']
                self.__invalids.append(gaze_data)
                # wait for next valid sample
                return []
            else:
                # if we are not in a gap  --> set flag
                self.__has_gap = True
                self.__first_invalid_of_gap = gaze_data['system_time_stamp']
                self.__invalids.append(gaze_data)
                return []



    @staticmethod
    def is_valid(gaze_data: dict) -> bool:
        """
        Checks if gaze_data returned valid.
        :param gaze_data: a dict as produced by Tobii Pro SDK's get gaze data method
        :return: whether the sample is valid on both eyes
                True if both eyes are valid
                False else
        """
        #print(gaze_data['left_gaze_point_validity'])
        return gaze_data['left_gaze_point_validity'] == 1 and gaze_data['right_gaze_point_validity'] == 1

    def __interpolate_gap(self, first_valid: dict) -> list:
        """
        Interpolates data as implemented in the paper of tobii.
        :param first_valid: The first valid sample after a gap
        :return: a list of dicts
        """
        # If we started with a gap
        if self.__last_valid is None:

            # Return the gapped list --> Interpolation is then considdered to have failed
            return self.__invalids
        else:
            # get time of the first valid sample after the gap
            t1valid = first_valid['system_time_stamp']
            interpolated = []
            # for every invalid
            for sample in self.__invalids:
                # get its timestamp
                ts_rep = sample['system_time_stamp']
                # adjust scaling parameter
                scaling = (ts_rep - t1valid) / (self.__time_last_valid - t1valid)
                # TODO Make this formular less shit. HOW????
                # apply formula from Tobii Paper
                sample['left_gaze_point_in_user_coordinate_system'] =\
                    (scaling * first_valid['left_gaze_point_in_user_coordinate_system'][0] + self.__last_valid['left_gaze_point_in_user_coordinate_system'][0],
                     scaling * first_valid['left_gaze_point_in_user_coordinate_system'][1] +
                     self.__last_valid['left_gaze_point_in_user_coordinate_system'][1],
                     scaling * first_valid['left_gaze_point_in_user_coordinate_system'][2] +
                     self.__last_valid['left_gaze_point_in_user_coordinate_system'][2])
                sample['right_gaze_point_in_user_coordinate_system'] = (scaling * first_valid['right_gaze_point_in_user_coordinate_system'][0] + self.__last_valid['right_gaze_point_in_user_coordinate_system'][0],
                                                                        scaling * first_valid[
                                                                            'right_gaze_point_in_user_coordinate_system'][
                                                                            1] + self.__last_valid[
                                                                            'right_gaze_point_in_user_coordinate_system'][1],
                                                                        scaling * first_valid[
                                                                            'right_gaze_point_in_user_coordinate_system'][
                                                                            2] + self.__last_valid[
                                                                            'right_gaze_point_in_user_coordinate_system'][2])
                sample['left_gaze_point_on_display_area'] = \
                    (scaling * first_valid['left_gaze_point_on_display_area'][0] +
                     self.__last_valid['left_gaze_point_on_display_area'][0],
                     scaling * first_valid['left_gaze_point_on_display_area'][1] +
                     self.__last_valid['left_gaze_point_on_display_area'][1])
                sample['right_gaze_point_on_display_area'] = (
                    scaling * first_valid['right_gaze_point_on_display_area'][0] +
                    self.__last_valid['right_gaze_point_on_display_area'][0],
                    scaling * first_valid['right_gaze_point_on_display_area'][1]
                    + self.__last_valid['right_gaze_point_on_display_area'][1])

                interpolated.append(sample)
            #interpolated.append(first_valid)
        return interpolated