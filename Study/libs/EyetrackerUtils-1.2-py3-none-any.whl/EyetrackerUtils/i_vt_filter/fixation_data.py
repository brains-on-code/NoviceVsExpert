import math


class FixationData:
    """
    Data structure to handle data form the ivt filter.
    Avg values are filled in during computation and are there for the final steps of the program. In case of value porblems
    check the eye selector
    """
    __gazepoint_l = (0,0,0)
    __gazepoint_r = (0, 0, 0)
    gazepoint_avg = (0, 0, 0)
    __gazeorigin_l = ()
    __gazeorigin_r = ()
    gazeorigin_avg = ()
    __gaze2d_l = ()
    __gaze2d_r = ()
    gaze2d_avg =()

    # whether or not the sample is a fixation. Filled in at the end of the process
    fixation = False
    __is_gap = False
    __timestamp = -1

    # computed velocity for this sample
    velocity = math.nan

    # This is a solution, that's only in here, until I think of sth better
    first_in_group: False
    last_in_group: False

    def __init__(self, gazepoint_l, gazepoint_r,gazeorigin_l, gazeorigin_r, gazepoint_display_l, gazepoint_display_r, timestamp, is_gap):
        """
            Returns an instance of this class
            :param gazepoint_l: left-side gazepoint in 3D
            :param gazepoint_r: right-side gazepoint in 3D
            :param gazeorigin_l: left-side gazeorigin (where the gaze comes from, so basically left eye's position)
            :param gazeorigin_r: right-side gazeorigin
            :param gazepoint_display_l: left-side gazepoint on the display plane --> 2D
             :param gazepoint_display_r: right-side gazepoint on the display plane --> 2D
             :param timestamp: timestamp of the sample's creation
             :param is_gap: whether or not the sample is a gap
                            True if it is
                            False if not
        """

        self.__gazepoint_l = gazepoint_l
        self.__gazepoint_r = gazepoint_r
        self.__timestamp = timestamp
        self.__is_gap = is_gap
        self.__gazeorigin_l = gazeorigin_l
        self.__gazeorigin_r = gazeorigin_r
        self.__gaze2d_l = gazepoint_display_l
        self.__gaze2d_r = gazepoint_display_r

    def get_2d_gaze(self):
        return self.__gaze2d_l, self.__gaze2d_r

    def get_side_gaze(self, side):
        if side == 'left':
            return self.__gazepoint_l
        elif side == 'right':
            return self.__gazepoint_r
        else:
            raise AttributeError

    def get_side_gazeorigin(self, side):
        if side == 'left':
            return self.__gazeorigin_l
        elif side == 'right':
            return self.__gazeorigin_r
        else:
            raise AttributeError

    def get_time(self):
        return self.__timestamp

    def get_time_diff(self, time):
        return abs(time - self.__timestamp)

    def gap_check(self):
        return self.__is_gap
