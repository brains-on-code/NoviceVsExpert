import numpy as np
from EyetrackerUtils.i_vt_filter.fixation_data import FixationData

class VelocityCalculator:

    def __init__(self, sfreq: int =250):
        """
            Creates an instance of this class
            :param sfreq: Eyetracker sampling frequency
        """
        # How many samples are computed per ms
        self.sfreq_amt = 1000 / sfreq
        self.sfreq = sfreq

    def calculate_velocities(self, dataset:list, window_length:float =20) -> list:
        """
            Calculates the angular velocity of a given sample
            :param dataset: the dataset containing the samples
            :param window_length: what timeframe (in ms) to consider for sample selection
            :return: the modified dataset
        """
        # compute the samples computed during the given windowlength, +1 since we need at least 2 samples
        n_samples = window_length // self.sfreq_amt + 1
        output = []
        # for sample in dataset
        for value in range(len(dataset) - 1):
            # we select a window again, taking into account dataset edges
            window = self.__select_window(dataset, n_samples, value)
            sample_list = []

            for sample in window:
                # we take the samples belonging to our window
                first = dataset[sample]

                second = dataset[sample + 1]
                # is one of those a gap?
                if first.gap_check() or second.gap_check():
                    # then skip
                    continue

                # else append the velocity
                sample_list.append(self.calculate_velocity(first, second))
            if len(sample_list) != 0:
                # average of all velocities to reduce measurement inaccuracies --> suggested by Tobii
                dataset[value].velocity = (sum(sample_list)/len(sample_list))
            output.append(dataset[value])
        return output

    def __select_window(self, dataset, samples, sid):
        """
            Select a fitting window for your data
            :param dataset: the dataset to use
            :param samples: the amount of samples needed
            :param sid: the sample id around which is opperated
        """
        # if we need an even amount of samples
        if samples % 2 != 1:
            # if samples are minimal
            if samples == 2:
                # if we are on the dataset's right edge
                if sid == len(dataset)-1:
                    # we neeed to go left to average
                    return [sid-1, sid]
                # this is also true for the second last entry, it throws errors otherwise
                elif sid == len(dataset)-2:
                    return [sid-1, sid]
                else:

                    return [sid, sid+1]
            else:
                # else compute the length we need to take left and right
                llength = int(samples / 2)
                # check for enough space on the left and adapt if we meet an edge
                if sid + llength >= len(dataset)-2:
                    return self.__select_window(dataset, samples-1, sid)
                # check for enough space on the right and adapt if we meet an edge
                elif sid - llength - 1 < 0:
                    return self.__select_window(dataset, samples-1, sid)
                else:
                    # give a list of the correct entries
                    # substract one on the left, since we need to take sid into account
                    return list(range(sid - llength - 1, sid+llength+1))
        else:
            # if we are uneven cpmpute left and right elngth again
            llength = int((samples - 1) / 2)
            # check sides
            if sid + llength >= len(dataset) - 2:
                return self.__select_window(dataset, samples - 1, sid)
            elif sid - llength < 0:
                return self.__select_window(dataset, samples - 1, sid)
            # and compute the according indices
            else:

                return list(range(sid - llength, sid+llength+1))

    def calculate_velocity(self, first: FixationData, second : FixationData) -> float:
        """
            Calculates the velocity between to given data samples
        """
        # get gaveorigin, gazepoint and time values
        eye = first.gazeorigin_avg
        f_pos = first.gazepoint_avg
        s_pos = second.gazepoint_avg
        f_time = first.get_time()
        s_time = second.get_time()

        # compute velocity by forumla from the Tobii paper (link see ivt_filter.py)
        v1 = np.array([f_pos[0] - eye[0], f_pos[1] - eye[1], f_pos[2] - eye[2]])
        v2 = np.array([s_pos[0] - eye[0], s_pos[1] - eye[1], s_pos[2] - eye[2]])

        # compute angle between both vectors
        angle = self.__angle_between(v1, v2)
        # divide by time difference to compute angular velocity
        result = angle / (s_time - f_time)
        return result

    @staticmethod
    def __unit_vector(vector):
        """ Returns the unit vector of the vector.  """
        if np.linalg.norm(vector) == 0:
           return vector
        return vector / np.linalg.norm(vector)

    def __angle_between(self, v1, v2):
        """
            Computes the angles between two given vectors
            :param v1: a numpy array containing numbers
            :param v2: a numpy array containing numbers of same length as v1
            :return: The angle between both vectors
        """
        # debug statement please ignore
        if np.linalg.norm(v1)== 0:
            h = 1
        elif np.linalg.norm(v2) == 0:
            h=0
        v1_u = self.__unit_vector(v1)
        v2_u = self.__unit_vector(v2)
        return np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0)) #TODO is this clip necessary?
